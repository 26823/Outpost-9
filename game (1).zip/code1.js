gdjs.MainMenuCode = {};
gdjs.MainMenuCode.localVariables = [];
gdjs.MainMenuCode.idToCallbackMap = new Map();
gdjs.MainMenuCode.GDMenuObjects1= [];
gdjs.MainMenuCode.GDMenuObjects2= [];
gdjs.MainMenuCode.GDResumeObjects1= [];
gdjs.MainMenuCode.GDResumeObjects2= [];
gdjs.MainMenuCode.GDSettingsObjects1= [];
gdjs.MainMenuCode.GDSettingsObjects2= [];
gdjs.MainMenuCode.GDQuitObjects1= [];
gdjs.MainMenuCode.GDQuitObjects2= [];
gdjs.MainMenuCode.GDMenuslideObjects1= [];
gdjs.MainMenuCode.GDMenuslideObjects2= [];
gdjs.MainMenuCode.GDMusicObjects1= [];
gdjs.MainMenuCode.GDMusicObjects2= [];
gdjs.MainMenuCode.GDSoundObjects1= [];
gdjs.MainMenuCode.GDSoundObjects2= [];
gdjs.MainMenuCode.GDSettingsTitleObjects1= [];
gdjs.MainMenuCode.GDSettingsTitleObjects2= [];
gdjs.MainMenuCode.GDsoundObjects1= [];
gdjs.MainMenuCode.GDsoundObjects2= [];
gdjs.MainMenuCode.GDmusicObjects1= [];
gdjs.MainMenuCode.GDmusicObjects2= [];
gdjs.MainMenuCode.GDBackObjects1= [];
gdjs.MainMenuCode.GDBackObjects2= [];
gdjs.MainMenuCode.GDSettingsslideObjects1= [];
gdjs.MainMenuCode.GDSettingsslideObjects2= [];
gdjs.MainMenuCode.GDTransitionObjects1= [];
gdjs.MainMenuCode.GDTransitionObjects2= [];
gdjs.MainMenuCode.GDSaveObjects1= [];
gdjs.MainMenuCode.GDSaveObjects2= [];
gdjs.MainMenuCode.GDSavedeleteObjects1= [];
gdjs.MainMenuCode.GDSavedeleteObjects2= [];


gdjs.MainMenuCode.asyncCallback25017468 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainMenuCode.localVariables);
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}
gdjs.MainMenuCode.localVariables.length = 0;
}
gdjs.MainMenuCode.idToCallbackMap.set(25017468, gdjs.MainMenuCode.asyncCallback25017468);
gdjs.MainMenuCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainMenuCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainMenuCode.asyncCallback25017468(runtimeScene, asyncObjectsList)), 25017468, asyncObjectsList);
}
}

}


};gdjs.MainMenuCode.asyncCallback25019724 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainMenuCode.localVariables);
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}
gdjs.MainMenuCode.localVariables.length = 0;
}
gdjs.MainMenuCode.idToCallbackMap.set(25019724, gdjs.MainMenuCode.asyncCallback25019724);
gdjs.MainMenuCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainMenuCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(5), (runtimeScene) => (gdjs.MainMenuCode.asyncCallback25019724(runtimeScene, asyncObjectsList)), 25019724, asyncObjectsList);
}
}

}


};gdjs.MainMenuCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Menuslide"), gdjs.MainMenuCode.GDMenuslideObjects1);
gdjs.copyArray(runtimeScene.getObjects("Settingsslide"), gdjs.MainMenuCode.GDSettingsslideObjects1);
{for(var i = 0, len = gdjs.MainMenuCode.GDMenuslideObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDMenuslideObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.MainMenuCode.GDSettingsslideObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDSettingsslideObjects1[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Settings"), gdjs.MainMenuCode.GDSettingsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainMenuCode.GDSettingsObjects1.length;i<l;++i) {
    if ( gdjs.MainMenuCode.GDSettingsObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.MainMenuCode.GDSettingsObjects1[k] = gdjs.MainMenuCode.GDSettingsObjects1[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDSettingsObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Settingsslide"), gdjs.MainMenuCode.GDSettingsslideObjects1);
{gdjs.evtTools.tween.tweenCamera2(runtimeScene, "CameraMove", (( gdjs.MainMenuCode.GDSettingsslideObjects1.length === 0 ) ? 0 :gdjs.MainMenuCode.GDSettingsslideObjects1[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", "easeInOutQuad", 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.MainMenuCode.GDBackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainMenuCode.GDBackObjects1.length;i<l;++i) {
    if ( gdjs.MainMenuCode.GDBackObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.MainMenuCode.GDBackObjects1[k] = gdjs.MainMenuCode.GDBackObjects1[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDBackObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Menuslide"), gdjs.MainMenuCode.GDMenuslideObjects1);
{gdjs.evtTools.tween.tweenCamera2(runtimeScene, "CameraMove", (( gdjs.MainMenuCode.GDMenuslideObjects1.length === 0 ) ? 0 :gdjs.MainMenuCode.GDMenuslideObjects1[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", "easeInOutQuad", 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Resume"), gdjs.MainMenuCode.GDResumeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainMenuCode.GDResumeObjects1.length;i<l;++i) {
    if ( gdjs.MainMenuCode.GDResumeObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.MainMenuCode.GDResumeObjects1[k] = gdjs.MainMenuCode.GDResumeObjects1[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDResumeObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Transition"), gdjs.MainMenuCode.GDTransitionObjects1);
{for(var i = 0, len = gdjs.MainMenuCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDTransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 1, "Circular", "Forward", 0, null);
}
}

{ //Subevents
gdjs.MainMenuCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Quit"), gdjs.MainMenuCode.GDQuitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainMenuCode.GDQuitObjects1.length;i<l;++i) {
    if ( gdjs.MainMenuCode.GDQuitObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.MainMenuCode.GDQuitObjects1[k] = gdjs.MainMenuCode.GDQuitObjects1[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDQuitObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.saveState.createGameSaveStateInStorage(runtimeScene, "Space Game Save", "default");
}

{ //Subevents
gdjs.MainMenuCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Save"), gdjs.MainMenuCode.GDSaveObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainMenuCode.GDSaveObjects1.length;i<l;++i) {
    if ( gdjs.MainMenuCode.GDSaveObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.MainMenuCode.GDSaveObjects1[k] = gdjs.MainMenuCode.GDSaveObjects1[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDSaveObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.saveState.createGameSaveStateInStorage(runtimeScene, "Space Game Save", "default");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("sound"), gdjs.MainMenuCode.GDsoundObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainMenuCode.GDsoundObjects1.length;i<l;++i) {
    if ( gdjs.MainMenuCode.GDsoundObjects1[i].IsBeingDragged(null) ) {
        isConditionTrue_0 = true;
        gdjs.MainMenuCode.GDsoundObjects1[k] = gdjs.MainMenuCode.GDsoundObjects1[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDsoundObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainMenuCode.GDsoundObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(7).getChild("sound").setNumber((( gdjs.MainMenuCode.GDsoundObjects1.length === 0 ) ? 0 :gdjs.MainMenuCode.GDsoundObjects1[0].Value(null)));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("music"), gdjs.MainMenuCode.GDmusicObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainMenuCode.GDmusicObjects1.length;i<l;++i) {
    if ( gdjs.MainMenuCode.GDmusicObjects1[i].IsBeingDragged(null) ) {
        isConditionTrue_0 = true;
        gdjs.MainMenuCode.GDmusicObjects1[k] = gdjs.MainMenuCode.GDmusicObjects1[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDmusicObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainMenuCode.GDmusicObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(7).getChild("music").setNumber((( gdjs.MainMenuCode.GDmusicObjects1.length === 0 ) ? 0 :gdjs.MainMenuCode.GDmusicObjects1[0].Value(null)));
}
{gdjs.evtTools.sound.setMusicOnChannelVolume(runtimeScene, 1, runtimeScene.getGame().getVariables().getFromIndex(7).getChild("music").getAsNumber());
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.saveState.hasSaveJustSucceeded(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Savedelete"), gdjs.MainMenuCode.GDSavedeleteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainMenuCode.GDSavedeleteObjects1.length;i<l;++i) {
    if ( gdjs.MainMenuCode.GDSavedeleteObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.MainMenuCode.GDSavedeleteObjects1[k] = gdjs.MainMenuCode.GDSavedeleteObjects1[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDSavedeleteObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.saveState.deleteSaveFromStorage(runtimeScene, "Space Game Save");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.saveState.hasDeleteJustSucceeded(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}
}

}


};

gdjs.MainMenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MainMenuCode.GDMenuObjects1.length = 0;
gdjs.MainMenuCode.GDMenuObjects2.length = 0;
gdjs.MainMenuCode.GDResumeObjects1.length = 0;
gdjs.MainMenuCode.GDResumeObjects2.length = 0;
gdjs.MainMenuCode.GDSettingsObjects1.length = 0;
gdjs.MainMenuCode.GDSettingsObjects2.length = 0;
gdjs.MainMenuCode.GDQuitObjects1.length = 0;
gdjs.MainMenuCode.GDQuitObjects2.length = 0;
gdjs.MainMenuCode.GDMenuslideObjects1.length = 0;
gdjs.MainMenuCode.GDMenuslideObjects2.length = 0;
gdjs.MainMenuCode.GDMusicObjects1.length = 0;
gdjs.MainMenuCode.GDMusicObjects2.length = 0;
gdjs.MainMenuCode.GDSoundObjects1.length = 0;
gdjs.MainMenuCode.GDSoundObjects2.length = 0;
gdjs.MainMenuCode.GDSettingsTitleObjects1.length = 0;
gdjs.MainMenuCode.GDSettingsTitleObjects2.length = 0;
gdjs.MainMenuCode.GDsoundObjects1.length = 0;
gdjs.MainMenuCode.GDsoundObjects2.length = 0;
gdjs.MainMenuCode.GDmusicObjects1.length = 0;
gdjs.MainMenuCode.GDmusicObjects2.length = 0;
gdjs.MainMenuCode.GDBackObjects1.length = 0;
gdjs.MainMenuCode.GDBackObjects2.length = 0;
gdjs.MainMenuCode.GDSettingsslideObjects1.length = 0;
gdjs.MainMenuCode.GDSettingsslideObjects2.length = 0;
gdjs.MainMenuCode.GDTransitionObjects1.length = 0;
gdjs.MainMenuCode.GDTransitionObjects2.length = 0;
gdjs.MainMenuCode.GDSaveObjects1.length = 0;
gdjs.MainMenuCode.GDSaveObjects2.length = 0;
gdjs.MainMenuCode.GDSavedeleteObjects1.length = 0;
gdjs.MainMenuCode.GDSavedeleteObjects2.length = 0;

gdjs.MainMenuCode.eventsList2(runtimeScene);
gdjs.MainMenuCode.GDMenuObjects1.length = 0;
gdjs.MainMenuCode.GDMenuObjects2.length = 0;
gdjs.MainMenuCode.GDResumeObjects1.length = 0;
gdjs.MainMenuCode.GDResumeObjects2.length = 0;
gdjs.MainMenuCode.GDSettingsObjects1.length = 0;
gdjs.MainMenuCode.GDSettingsObjects2.length = 0;
gdjs.MainMenuCode.GDQuitObjects1.length = 0;
gdjs.MainMenuCode.GDQuitObjects2.length = 0;
gdjs.MainMenuCode.GDMenuslideObjects1.length = 0;
gdjs.MainMenuCode.GDMenuslideObjects2.length = 0;
gdjs.MainMenuCode.GDMusicObjects1.length = 0;
gdjs.MainMenuCode.GDMusicObjects2.length = 0;
gdjs.MainMenuCode.GDSoundObjects1.length = 0;
gdjs.MainMenuCode.GDSoundObjects2.length = 0;
gdjs.MainMenuCode.GDSettingsTitleObjects1.length = 0;
gdjs.MainMenuCode.GDSettingsTitleObjects2.length = 0;
gdjs.MainMenuCode.GDsoundObjects1.length = 0;
gdjs.MainMenuCode.GDsoundObjects2.length = 0;
gdjs.MainMenuCode.GDmusicObjects1.length = 0;
gdjs.MainMenuCode.GDmusicObjects2.length = 0;
gdjs.MainMenuCode.GDBackObjects1.length = 0;
gdjs.MainMenuCode.GDBackObjects2.length = 0;
gdjs.MainMenuCode.GDSettingsslideObjects1.length = 0;
gdjs.MainMenuCode.GDSettingsslideObjects2.length = 0;
gdjs.MainMenuCode.GDTransitionObjects1.length = 0;
gdjs.MainMenuCode.GDTransitionObjects2.length = 0;
gdjs.MainMenuCode.GDSaveObjects1.length = 0;
gdjs.MainMenuCode.GDSaveObjects2.length = 0;
gdjs.MainMenuCode.GDSavedeleteObjects1.length = 0;
gdjs.MainMenuCode.GDSavedeleteObjects2.length = 0;


return;

}

gdjs['MainMenuCode'] = gdjs.MainMenuCode;
