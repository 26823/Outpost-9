gdjs.gameCode = {};
gdjs.gameCode.localVariables = [];
gdjs.gameCode.idToCallbackMap = new Map();
gdjs.gameCode.GDBaseObjects3_1final = [];

gdjs.gameCode.GDBigEnemyObjects1_1final = [];

gdjs.gameCode.GDBigEnemyObjects2_1final = [];

gdjs.gameCode.GDBigEnemyObjects3_1final = [];

gdjs.gameCode.GDEnemyObjects1_1final = [];

gdjs.gameCode.GDEnemyObjects3_1final = [];

gdjs.gameCode.GDPlayerObjects1_1final = [];

gdjs.gameCode.GDSniperEnemyObjects3_1final = [];

gdjs.gameCode.GDpeople1Objects3_1final = [];

gdjs.gameCode.GDschotEnemyObjects3_1final = [];

gdjs.gameCode.GDsmallEnemyObjects1_1final = [];

gdjs.gameCode.GDsmallEnemyObjects3_1final = [];

gdjs.gameCode.forEachIndex2 = 0;

gdjs.gameCode.forEachIndex3 = 0;

gdjs.gameCode.forEachObjects2 = [];

gdjs.gameCode.forEachObjects3 = [];

gdjs.gameCode.forEachTemporary2 = null;

gdjs.gameCode.forEachTemporary3 = null;

gdjs.gameCode.forEachTotalCount2 = 0;

gdjs.gameCode.forEachTotalCount3 = 0;

gdjs.gameCode.GDPlayerObjects1= [];
gdjs.gameCode.GDPlayerObjects2= [];
gdjs.gameCode.GDPlayerObjects3= [];
gdjs.gameCode.GDPlayerObjects4= [];
gdjs.gameCode.GDMoveJoystickObjects1= [];
gdjs.gameCode.GDMoveJoystickObjects2= [];
gdjs.gameCode.GDMoveJoystickObjects3= [];
gdjs.gameCode.GDMoveJoystickObjects4= [];
gdjs.gameCode.GDRepeatingBackgroundObjects1= [];
gdjs.gameCode.GDRepeatingBackgroundObjects2= [];
gdjs.gameCode.GDRepeatingBackgroundObjects3= [];
gdjs.gameCode.GDRepeatingBackgroundObjects4= [];
gdjs.gameCode.GDEnemyObjects1= [];
gdjs.gameCode.GDEnemyObjects2= [];
gdjs.gameCode.GDEnemyObjects3= [];
gdjs.gameCode.GDEnemyObjects4= [];
gdjs.gameCode.GDPlayerBulletObjects1= [];
gdjs.gameCode.GDPlayerBulletObjects2= [];
gdjs.gameCode.GDPlayerBulletObjects3= [];
gdjs.gameCode.GDPlayerBulletObjects4= [];
gdjs.gameCode.GDAimJoystickObjects1= [];
gdjs.gameCode.GDAimJoystickObjects2= [];
gdjs.gameCode.GDAimJoystickObjects3= [];
gdjs.gameCode.GDAimJoystickObjects4= [];
gdjs.gameCode.GDDebrisParticleObjects1= [];
gdjs.gameCode.GDDebrisParticleObjects2= [];
gdjs.gameCode.GDDebrisParticleObjects3= [];
gdjs.gameCode.GDDebrisParticleObjects4= [];
gdjs.gameCode.GDLargeDebrisParticleObjects1= [];
gdjs.gameCode.GDLargeDebrisParticleObjects2= [];
gdjs.gameCode.GDLargeDebrisParticleObjects3= [];
gdjs.gameCode.GDLargeDebrisParticleObjects4= [];
gdjs.gameCode.GDHeartScrollBarObjects1= [];
gdjs.gameCode.GDHeartScrollBarObjects2= [];
gdjs.gameCode.GDHeartScrollBarObjects3= [];
gdjs.gameCode.GDHeartScrollBarObjects4= [];
gdjs.gameCode.GDThickPixelRoundBulletAmmoObjects1= [];
gdjs.gameCode.GDThickPixelRoundBulletAmmoObjects2= [];
gdjs.gameCode.GDThickPixelRoundBulletAmmoObjects3= [];
gdjs.gameCode.GDThickPixelRoundBulletAmmoObjects4= [];
gdjs.gameCode.GDbulletObjects1= [];
gdjs.gameCode.GDbulletObjects2= [];
gdjs.gameCode.GDbulletObjects3= [];
gdjs.gameCode.GDbulletObjects4= [];
gdjs.gameCode.GDMenuObjects1= [];
gdjs.gameCode.GDMenuObjects2= [];
gdjs.gameCode.GDMenuObjects3= [];
gdjs.gameCode.GDMenuObjects4= [];
gdjs.gameCode.GDsmallEnemyObjects1= [];
gdjs.gameCode.GDsmallEnemyObjects2= [];
gdjs.gameCode.GDsmallEnemyObjects3= [];
gdjs.gameCode.GDsmallEnemyObjects4= [];
gdjs.gameCode.GDBigEnemyObjects1= [];
gdjs.gameCode.GDBigEnemyObjects2= [];
gdjs.gameCode.GDBigEnemyObjects3= [];
gdjs.gameCode.GDBigEnemyObjects4= [];
gdjs.gameCode.GDbullet2Objects1= [];
gdjs.gameCode.GDbullet2Objects2= [];
gdjs.gameCode.GDbullet2Objects3= [];
gdjs.gameCode.GDbullet2Objects4= [];
gdjs.gameCode.GDSniperEnemyObjects1= [];
gdjs.gameCode.GDSniperEnemyObjects2= [];
gdjs.gameCode.GDSniperEnemyObjects3= [];
gdjs.gameCode.GDSniperEnemyObjects4= [];
gdjs.gameCode.GDbullet3Objects1= [];
gdjs.gameCode.GDbullet3Objects2= [];
gdjs.gameCode.GDbullet3Objects3= [];
gdjs.gameCode.GDbullet3Objects4= [];
gdjs.gameCode.GDbrandObjects1= [];
gdjs.gameCode.GDbrandObjects2= [];
gdjs.gameCode.GDbrandObjects3= [];
gdjs.gameCode.GDbrandObjects4= [];
gdjs.gameCode.GDMoney_9595Bag_9595PixelObjects1= [];
gdjs.gameCode.GDMoney_9595Bag_9595PixelObjects2= [];
gdjs.gameCode.GDMoney_9595Bag_9595PixelObjects3= [];
gdjs.gameCode.GDMoney_9595Bag_9595PixelObjects4= [];
gdjs.gameCode.GDschotEnemyObjects1= [];
gdjs.gameCode.GDschotEnemyObjects2= [];
gdjs.gameCode.GDschotEnemyObjects3= [];
gdjs.gameCode.GDschotEnemyObjects4= [];
gdjs.gameCode.GDbullet4Objects1= [];
gdjs.gameCode.GDbullet4Objects2= [];
gdjs.gameCode.GDbullet4Objects3= [];
gdjs.gameCode.GDbullet4Objects4= [];
gdjs.gameCode.GDHealthUPObjects1= [];
gdjs.gameCode.GDHealthUPObjects2= [];
gdjs.gameCode.GDHealthUPObjects3= [];
gdjs.gameCode.GDHealthUPObjects4= [];
gdjs.gameCode.GDArmorUPObjects1= [];
gdjs.gameCode.GDArmorUPObjects2= [];
gdjs.gameCode.GDArmorUPObjects3= [];
gdjs.gameCode.GDArmorUPObjects4= [];
gdjs.gameCode.GDShopObjects1= [];
gdjs.gameCode.GDShopObjects2= [];
gdjs.gameCode.GDShopObjects3= [];
gdjs.gameCode.GDShopObjects4= [];
gdjs.gameCode.GDExplosionObjects1= [];
gdjs.gameCode.GDExplosionObjects2= [];
gdjs.gameCode.GDExplosionObjects3= [];
gdjs.gameCode.GDExplosionObjects4= [];
gdjs.gameCode.GDCoinObjects1= [];
gdjs.gameCode.GDCoinObjects2= [];
gdjs.gameCode.GDCoinObjects3= [];
gdjs.gameCode.GDCoinObjects4= [];
gdjs.gameCode.GDpijlObjects1= [];
gdjs.gameCode.GDpijlObjects2= [];
gdjs.gameCode.GDpijlObjects3= [];
gdjs.gameCode.GDpijlObjects4= [];
gdjs.gameCode.GDpeople1Objects1= [];
gdjs.gameCode.GDpeople1Objects2= [];
gdjs.gameCode.GDpeople1Objects3= [];
gdjs.gameCode.GDpeople1Objects4= [];
gdjs.gameCode.GDpijl2Objects1= [];
gdjs.gameCode.GDpijl2Objects2= [];
gdjs.gameCode.GDpijl2Objects3= [];
gdjs.gameCode.GDpijl2Objects4= [];
gdjs.gameCode.GDknopObjects1= [];
gdjs.gameCode.GDknopObjects2= [];
gdjs.gameCode.GDknopObjects3= [];
gdjs.gameCode.GDknopObjects4= [];
gdjs.gameCode.GDMetalRedBarObjects1= [];
gdjs.gameCode.GDMetalRedBarObjects2= [];
gdjs.gameCode.GDMetalRedBarObjects3= [];
gdjs.gameCode.GDMetalRedBarObjects4= [];
gdjs.gameCode.GDBaseTextObjects1= [];
gdjs.gameCode.GDBaseTextObjects2= [];
gdjs.gameCode.GDBaseTextObjects3= [];
gdjs.gameCode.GDBaseTextObjects4= [];
gdjs.gameCode.GDBaseObjects1= [];
gdjs.gameCode.GDBaseObjects2= [];
gdjs.gameCode.GDBaseObjects3= [];
gdjs.gameCode.GDBaseObjects4= [];
gdjs.gameCode.GDpijl3Objects1= [];
gdjs.gameCode.GDpijl3Objects2= [];
gdjs.gameCode.GDpijl3Objects3= [];
gdjs.gameCode.GDpijl3Objects4= [];
gdjs.gameCode.GDExplosion2Objects1= [];
gdjs.gameCode.GDExplosion2Objects2= [];
gdjs.gameCode.GDExplosion2Objects3= [];
gdjs.gameCode.GDExplosion2Objects4= [];
gdjs.gameCode.GDSparksObjects1= [];
gdjs.gameCode.GDSparksObjects2= [];
gdjs.gameCode.GDSparksObjects3= [];
gdjs.gameCode.GDSparksObjects4= [];
gdjs.gameCode.GDCoin4Objects1= [];
gdjs.gameCode.GDCoin4Objects2= [];
gdjs.gameCode.GDCoin4Objects3= [];
gdjs.gameCode.GDCoin4Objects4= [];
gdjs.gameCode.GDCoin3Objects1= [];
gdjs.gameCode.GDCoin3Objects2= [];
gdjs.gameCode.GDCoin3Objects3= [];
gdjs.gameCode.GDCoin3Objects4= [];
gdjs.gameCode.GDCoin2Objects1= [];
gdjs.gameCode.GDCoin2Objects2= [];
gdjs.gameCode.GDCoin2Objects3= [];
gdjs.gameCode.GDCoin2Objects4= [];
gdjs.gameCode.GDSmokeObjects1= [];
gdjs.gameCode.GDSmokeObjects2= [];
gdjs.gameCode.GDSmokeObjects3= [];
gdjs.gameCode.GDSmokeObjects4= [];


gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBaseObjects1Objects = Hashtable.newFrom({"Base": gdjs.gameCode.GDBaseObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpijlObjects3Objects = Hashtable.newFrom({"pijl": gdjs.gameCode.GDpijlObjects3});
gdjs.gameCode.eventsList0 = function(runtimeScene) {

};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpijl3Objects3Objects = Hashtable.newFrom({"pijl3": gdjs.gameCode.GDpijl3Objects3});
gdjs.gameCode.eventsList1 = function(runtimeScene) {

};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpijl2Objects3Objects = Hashtable.newFrom({"pijl2": gdjs.gameCode.GDpijl2Objects3});
gdjs.gameCode.eventsList2 = function(runtimeScene) {

};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpijlObjects3Objects = Hashtable.newFrom({"pijl": gdjs.gameCode.GDpijlObjects3});
gdjs.gameCode.eventsList3 = function(runtimeScene) {

};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpijlObjects3Objects = Hashtable.newFrom({"pijl": gdjs.gameCode.GDpijlObjects3});
gdjs.gameCode.eventsList4 = function(runtimeScene) {

};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpijlObjects3Objects = Hashtable.newFrom({"pijl": gdjs.gameCode.GDpijlObjects3});
gdjs.gameCode.eventsList5 = function(runtimeScene) {

};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpijlObjects2Objects = Hashtable.newFrom({"pijl": gdjs.gameCode.GDpijlObjects2});
gdjs.gameCode.eventsList6 = function(runtimeScene) {

};gdjs.gameCode.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.gameCode.GDEnemyObjects2);

for (gdjs.gameCode.forEachIndex3 = 0;gdjs.gameCode.forEachIndex3 < gdjs.gameCode.GDEnemyObjects2.length;++gdjs.gameCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects3);
gdjs.copyArray(gdjs.gameCode.GDpijlObjects1, gdjs.gameCode.GDpijlObjects3);

gdjs.gameCode.GDEnemyObjects3.length = 0;


gdjs.gameCode.forEachTemporary3 = gdjs.gameCode.GDEnemyObjects2[gdjs.gameCode.forEachIndex3];
gdjs.gameCode.GDEnemyObjects3.push(gdjs.gameCode.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.gameCode.GDEnemyObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.gameCode.GDEnemyObjects3, gdjs.gameCode.GDEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDEnemyObjects4[i].getAABBRight() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDEnemyObjects4[k] = gdjs.gameCode.GDEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDEnemyObjects3_1final.indexOf(gdjs.gameCode.GDEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDEnemyObjects3_1final.push(gdjs.gameCode.GDEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDEnemyObjects3, gdjs.gameCode.GDEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDEnemyObjects4[i].getAABBLeft() > gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDEnemyObjects4[k] = gdjs.gameCode.GDEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDEnemyObjects3_1final.indexOf(gdjs.gameCode.GDEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDEnemyObjects3_1final.push(gdjs.gameCode.GDEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDEnemyObjects3, gdjs.gameCode.GDEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDEnemyObjects4[i].getAABBBottom() < gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraHeight(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDEnemyObjects4[k] = gdjs.gameCode.GDEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDEnemyObjects3_1final.indexOf(gdjs.gameCode.GDEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDEnemyObjects3_1final.push(gdjs.gameCode.GDEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDEnemyObjects3, gdjs.gameCode.GDEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDEnemyObjects4[i].getAABBTop() > gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraHeight(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDEnemyObjects4[k] = gdjs.gameCode.GDEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDEnemyObjects3_1final.indexOf(gdjs.gameCode.GDEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDEnemyObjects3_1final.push(gdjs.gameCode.GDEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDEnemyObjects3_1final, gdjs.gameCode.GDEnemyObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !(runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() >= 10);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpijlObjects3Objects, 0, 0, "offScreenEnemyIndicator");
}
{for(var i = 0, len = gdjs.gameCode.GDpijlObjects3.length ;i < len;++i) {
    gdjs.gameCode.GDpijlObjects3[i].setAngle(gdjs.evtTools.common.angleBetweenPositions((( gdjs.gameCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects3[0].getPointX("")), (( gdjs.gameCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects3[0].getPointY("")), (( gdjs.gameCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects3[0].getPointX("")), (( gdjs.gameCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects3[0].getPointY(""))));
}
}
{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.gameCode.GDpijlObjects3.length !== 0 ? gdjs.gameCode.GDpijlObjects3[0] : null), (gdjs.gameCode.GDPlayerObjects3.length !== 0 ? gdjs.gameCode.GDPlayerObjects3[0] : null));
}
{for(var i = 0, len = gdjs.gameCode.GDpijlObjects3.length ;i < len;++i) {
    gdjs.gameCode.GDpijlObjects3[i].setX(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 + Math.cos(gdjs.toRad((gdjs.gameCode.GDpijlObjects3[i].getAngle()))) * (gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 - (gdjs.gameCode.GDpijlObjects3[i].getWidth())));
}
}
{for(var i = 0, len = gdjs.gameCode.GDpijlObjects3.length ;i < len;++i) {
    gdjs.gameCode.GDpijlObjects3[i].setY(gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2 + Math.sin(gdjs.toRad((gdjs.gameCode.GDpijlObjects3[i].getAngle()))) * (gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2 - (gdjs.gameCode.GDpijlObjects3[i].getHeight())));
}
}
{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Base"), gdjs.gameCode.GDBaseObjects2);

for (gdjs.gameCode.forEachIndex3 = 0;gdjs.gameCode.forEachIndex3 < gdjs.gameCode.GDBaseObjects2.length;++gdjs.gameCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects3);
gdjs.copyArray(gdjs.gameCode.GDpijl3Objects1, gdjs.gameCode.GDpijl3Objects3);

gdjs.gameCode.GDBaseObjects3.length = 0;


gdjs.gameCode.forEachTemporary3 = gdjs.gameCode.GDBaseObjects2[gdjs.gameCode.forEachIndex3];
gdjs.gameCode.GDBaseObjects3.push(gdjs.gameCode.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.gameCode.GDBaseObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.gameCode.GDBaseObjects3, gdjs.gameCode.GDBaseObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDBaseObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDBaseObjects4[i].getAABBRight() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDBaseObjects4[k] = gdjs.gameCode.GDBaseObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDBaseObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDBaseObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDBaseObjects3_1final.indexOf(gdjs.gameCode.GDBaseObjects4[j]) === -1 )
            gdjs.gameCode.GDBaseObjects3_1final.push(gdjs.gameCode.GDBaseObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDBaseObjects3, gdjs.gameCode.GDBaseObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDBaseObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDBaseObjects4[i].getAABBLeft() > gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDBaseObjects4[k] = gdjs.gameCode.GDBaseObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDBaseObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDBaseObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDBaseObjects3_1final.indexOf(gdjs.gameCode.GDBaseObjects4[j]) === -1 )
            gdjs.gameCode.GDBaseObjects3_1final.push(gdjs.gameCode.GDBaseObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDBaseObjects3, gdjs.gameCode.GDBaseObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDBaseObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDBaseObjects4[i].getAABBBottom() < gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraHeight(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDBaseObjects4[k] = gdjs.gameCode.GDBaseObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDBaseObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDBaseObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDBaseObjects3_1final.indexOf(gdjs.gameCode.GDBaseObjects4[j]) === -1 )
            gdjs.gameCode.GDBaseObjects3_1final.push(gdjs.gameCode.GDBaseObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDBaseObjects3, gdjs.gameCode.GDBaseObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDBaseObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDBaseObjects4[i].getAABBTop() > gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraHeight(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDBaseObjects4[k] = gdjs.gameCode.GDBaseObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDBaseObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDBaseObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDBaseObjects3_1final.indexOf(gdjs.gameCode.GDBaseObjects4[j]) === -1 )
            gdjs.gameCode.GDBaseObjects3_1final.push(gdjs.gameCode.GDBaseObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDBaseObjects3_1final, gdjs.gameCode.GDBaseObjects3);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpijl3Objects3Objects, 0, 0, "offScreenEnemyIndicator");
}
{for(var i = 0, len = gdjs.gameCode.GDpijl3Objects3.length ;i < len;++i) {
    gdjs.gameCode.GDpijl3Objects3[i].setAngle(gdjs.evtTools.common.angleBetweenPositions((( gdjs.gameCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects3[0].getPointX("")), (( gdjs.gameCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects3[0].getPointY("")), (( gdjs.gameCode.GDBaseObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDBaseObjects3[0].getPointX("")), (( gdjs.gameCode.GDBaseObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDBaseObjects3[0].getPointY(""))));
}
}
{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.gameCode.GDpijl3Objects3.length !== 0 ? gdjs.gameCode.GDpijl3Objects3[0] : null), (gdjs.gameCode.GDPlayerObjects3.length !== 0 ? gdjs.gameCode.GDPlayerObjects3[0] : null));
}
{for(var i = 0, len = gdjs.gameCode.GDpijl3Objects3.length ;i < len;++i) {
    gdjs.gameCode.GDpijl3Objects3[i].setX(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 + Math.cos(gdjs.toRad((gdjs.gameCode.GDpijl3Objects3[i].getAngle()))) * (gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 - (gdjs.gameCode.GDpijl3Objects3[i].getWidth())));
}
}
{for(var i = 0, len = gdjs.gameCode.GDpijl3Objects3.length ;i < len;++i) {
    gdjs.gameCode.GDpijl3Objects3[i].setY(gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2 + Math.sin(gdjs.toRad((gdjs.gameCode.GDpijl3Objects3[i].getAngle()))) * (gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2 - (gdjs.gameCode.GDpijl3Objects3[i].getHeight())));
}
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("people1"), gdjs.gameCode.GDpeople1Objects2);

for (gdjs.gameCode.forEachIndex3 = 0;gdjs.gameCode.forEachIndex3 < gdjs.gameCode.GDpeople1Objects2.length;++gdjs.gameCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects3);
gdjs.copyArray(gdjs.gameCode.GDpijlObjects1, gdjs.gameCode.GDpijlObjects3);

gdjs.copyArray(gdjs.gameCode.GDpijl2Objects1, gdjs.gameCode.GDpijl2Objects3);

gdjs.gameCode.GDpeople1Objects3.length = 0;


gdjs.gameCode.forEachTemporary3 = gdjs.gameCode.GDpeople1Objects2[gdjs.gameCode.forEachIndex3];
gdjs.gameCode.GDpeople1Objects3.push(gdjs.gameCode.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.gameCode.GDpeople1Objects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.gameCode.GDpeople1Objects3, gdjs.gameCode.GDpeople1Objects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDpeople1Objects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDpeople1Objects4[i].getAABBRight() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDpeople1Objects4[k] = gdjs.gameCode.GDpeople1Objects4[i];
        ++k;
    }
}
gdjs.gameCode.GDpeople1Objects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDpeople1Objects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDpeople1Objects3_1final.indexOf(gdjs.gameCode.GDpeople1Objects4[j]) === -1 )
            gdjs.gameCode.GDpeople1Objects3_1final.push(gdjs.gameCode.GDpeople1Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDpeople1Objects3, gdjs.gameCode.GDpeople1Objects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDpeople1Objects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDpeople1Objects4[i].getAABBLeft() > gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDpeople1Objects4[k] = gdjs.gameCode.GDpeople1Objects4[i];
        ++k;
    }
}
gdjs.gameCode.GDpeople1Objects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDpeople1Objects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDpeople1Objects3_1final.indexOf(gdjs.gameCode.GDpeople1Objects4[j]) === -1 )
            gdjs.gameCode.GDpeople1Objects3_1final.push(gdjs.gameCode.GDpeople1Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDpeople1Objects3, gdjs.gameCode.GDpeople1Objects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDpeople1Objects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDpeople1Objects4[i].getAABBBottom() < gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraHeight(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDpeople1Objects4[k] = gdjs.gameCode.GDpeople1Objects4[i];
        ++k;
    }
}
gdjs.gameCode.GDpeople1Objects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDpeople1Objects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDpeople1Objects3_1final.indexOf(gdjs.gameCode.GDpeople1Objects4[j]) === -1 )
            gdjs.gameCode.GDpeople1Objects3_1final.push(gdjs.gameCode.GDpeople1Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDpeople1Objects3, gdjs.gameCode.GDpeople1Objects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDpeople1Objects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDpeople1Objects4[i].getAABBTop() > gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraHeight(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDpeople1Objects4[k] = gdjs.gameCode.GDpeople1Objects4[i];
        ++k;
    }
}
gdjs.gameCode.GDpeople1Objects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDpeople1Objects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDpeople1Objects3_1final.indexOf(gdjs.gameCode.GDpeople1Objects4[j]) === -1 )
            gdjs.gameCode.GDpeople1Objects3_1final.push(gdjs.gameCode.GDpeople1Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDpeople1Objects3_1final, gdjs.gameCode.GDpeople1Objects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !(runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() >= 10);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpijl2Objects3Objects, 0, 0, "offScreenEnemyIndicator");
}
{for(var i = 0, len = gdjs.gameCode.GDpijl2Objects3.length ;i < len;++i) {
    gdjs.gameCode.GDpijl2Objects3[i].setAngle(gdjs.evtTools.common.angleBetweenPositions((( gdjs.gameCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects3[0].getPointX("")), (( gdjs.gameCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects3[0].getPointY("")), (( gdjs.gameCode.GDpeople1Objects3.length === 0 ) ? 0 :gdjs.gameCode.GDpeople1Objects3[0].getPointX("")), (( gdjs.gameCode.GDpeople1Objects3.length === 0 ) ? 0 :gdjs.gameCode.GDpeople1Objects3[0].getPointY(""))));
}
}
{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.gameCode.GDpijl2Objects3.length !== 0 ? gdjs.gameCode.GDpijl2Objects3[0] : null), (gdjs.gameCode.GDPlayerObjects3.length !== 0 ? gdjs.gameCode.GDPlayerObjects3[0] : null));
}
{for(var i = 0, len = gdjs.gameCode.GDpijl2Objects3.length ;i < len;++i) {
    gdjs.gameCode.GDpijl2Objects3[i].setX(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 + Math.cos(gdjs.toRad((gdjs.gameCode.GDpijl2Objects3[i].getAngle()))) * (gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 - (( gdjs.gameCode.GDpijlObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDpijlObjects3[0].getWidth())));
}
}
{for(var i = 0, len = gdjs.gameCode.GDpijl2Objects3.length ;i < len;++i) {
    gdjs.gameCode.GDpijl2Objects3[i].setY(gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2 + Math.sin(gdjs.toRad((gdjs.gameCode.GDpijl2Objects3[i].getAngle()))) * (gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2 - (( gdjs.gameCode.GDpijlObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDpijlObjects3[0].getHeight())));
}
}
{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("schotEnemy"), gdjs.gameCode.GDschotEnemyObjects2);

for (gdjs.gameCode.forEachIndex3 = 0;gdjs.gameCode.forEachIndex3 < gdjs.gameCode.GDschotEnemyObjects2.length;++gdjs.gameCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects3);
gdjs.copyArray(gdjs.gameCode.GDpijlObjects1, gdjs.gameCode.GDpijlObjects3);

gdjs.gameCode.GDschotEnemyObjects3.length = 0;


gdjs.gameCode.forEachTemporary3 = gdjs.gameCode.GDschotEnemyObjects2[gdjs.gameCode.forEachIndex3];
gdjs.gameCode.GDschotEnemyObjects3.push(gdjs.gameCode.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.gameCode.GDschotEnemyObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.gameCode.GDschotEnemyObjects3, gdjs.gameCode.GDschotEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDschotEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDschotEnemyObjects4[i].getAABBRight() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDschotEnemyObjects4[k] = gdjs.gameCode.GDschotEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDschotEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDschotEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDschotEnemyObjects3_1final.indexOf(gdjs.gameCode.GDschotEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDschotEnemyObjects3_1final.push(gdjs.gameCode.GDschotEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDschotEnemyObjects3, gdjs.gameCode.GDschotEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDschotEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDschotEnemyObjects4[i].getAABBLeft() > gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDschotEnemyObjects4[k] = gdjs.gameCode.GDschotEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDschotEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDschotEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDschotEnemyObjects3_1final.indexOf(gdjs.gameCode.GDschotEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDschotEnemyObjects3_1final.push(gdjs.gameCode.GDschotEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDschotEnemyObjects3, gdjs.gameCode.GDschotEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDschotEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDschotEnemyObjects4[i].getAABBBottom() < gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraHeight(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDschotEnemyObjects4[k] = gdjs.gameCode.GDschotEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDschotEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDschotEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDschotEnemyObjects3_1final.indexOf(gdjs.gameCode.GDschotEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDschotEnemyObjects3_1final.push(gdjs.gameCode.GDschotEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDschotEnemyObjects3, gdjs.gameCode.GDschotEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDschotEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDschotEnemyObjects4[i].getAABBTop() > gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraHeight(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDschotEnemyObjects4[k] = gdjs.gameCode.GDschotEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDschotEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDschotEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDschotEnemyObjects3_1final.indexOf(gdjs.gameCode.GDschotEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDschotEnemyObjects3_1final.push(gdjs.gameCode.GDschotEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDschotEnemyObjects3_1final, gdjs.gameCode.GDschotEnemyObjects3);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpijlObjects3Objects, 0, 0, "offScreenEnemyIndicator");
}
{for(var i = 0, len = gdjs.gameCode.GDpijlObjects3.length ;i < len;++i) {
    gdjs.gameCode.GDpijlObjects3[i].setAngle(gdjs.evtTools.common.angleBetweenPositions((( gdjs.gameCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects3[0].getPointX("")), (( gdjs.gameCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects3[0].getPointY("")), (( gdjs.gameCode.GDschotEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDschotEnemyObjects3[0].getPointX("")), (( gdjs.gameCode.GDschotEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDschotEnemyObjects3[0].getPointY(""))));
}
}
{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.gameCode.GDpijlObjects3.length !== 0 ? gdjs.gameCode.GDpijlObjects3[0] : null), (gdjs.gameCode.GDPlayerObjects3.length !== 0 ? gdjs.gameCode.GDPlayerObjects3[0] : null));
}
{for(var i = 0, len = gdjs.gameCode.GDpijlObjects3.length ;i < len;++i) {
    gdjs.gameCode.GDpijlObjects3[i].setX(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 + Math.cos(gdjs.toRad((gdjs.gameCode.GDpijlObjects3[i].getAngle()))) * (gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 - (gdjs.gameCode.GDpijlObjects3[i].getWidth())));
}
}
{for(var i = 0, len = gdjs.gameCode.GDpijlObjects3.length ;i < len;++i) {
    gdjs.gameCode.GDpijlObjects3[i].setY(gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2 + Math.sin(gdjs.toRad((gdjs.gameCode.GDpijlObjects3[i].getAngle()))) * (gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2 - (gdjs.gameCode.GDpijlObjects3[i].getHeight())));
}
}
{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("SniperEnemy"), gdjs.gameCode.GDSniperEnemyObjects2);

for (gdjs.gameCode.forEachIndex3 = 0;gdjs.gameCode.forEachIndex3 < gdjs.gameCode.GDSniperEnemyObjects2.length;++gdjs.gameCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects3);
gdjs.copyArray(gdjs.gameCode.GDpijlObjects1, gdjs.gameCode.GDpijlObjects3);

gdjs.gameCode.GDschotEnemyObjects3.length = 0;

gdjs.gameCode.GDSniperEnemyObjects3.length = 0;


gdjs.gameCode.forEachTemporary3 = gdjs.gameCode.GDSniperEnemyObjects2[gdjs.gameCode.forEachIndex3];
gdjs.gameCode.GDSniperEnemyObjects3.push(gdjs.gameCode.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.gameCode.GDSniperEnemyObjects3_1final.length = 0;
gdjs.gameCode.GDschotEnemyObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.gameCode.GDSniperEnemyObjects3, gdjs.gameCode.GDSniperEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDSniperEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDSniperEnemyObjects4[i].getAABBRight() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDSniperEnemyObjects4[k] = gdjs.gameCode.GDSniperEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDSniperEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDSniperEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDSniperEnemyObjects3_1final.indexOf(gdjs.gameCode.GDSniperEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDSniperEnemyObjects3_1final.push(gdjs.gameCode.GDSniperEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDSniperEnemyObjects3, gdjs.gameCode.GDSniperEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDSniperEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDSniperEnemyObjects4[i].getAABBLeft() > gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDSniperEnemyObjects4[k] = gdjs.gameCode.GDSniperEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDSniperEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDSniperEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDSniperEnemyObjects3_1final.indexOf(gdjs.gameCode.GDSniperEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDSniperEnemyObjects3_1final.push(gdjs.gameCode.GDSniperEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDSniperEnemyObjects3, gdjs.gameCode.GDSniperEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDSniperEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDSniperEnemyObjects4[i].getAABBBottom() < gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraHeight(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDSniperEnemyObjects4[k] = gdjs.gameCode.GDSniperEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDSniperEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDSniperEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDSniperEnemyObjects3_1final.indexOf(gdjs.gameCode.GDSniperEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDSniperEnemyObjects3_1final.push(gdjs.gameCode.GDSniperEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("schotEnemy"), gdjs.gameCode.GDschotEnemyObjects4);
for (var i = 0, k = 0, l = gdjs.gameCode.GDschotEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDschotEnemyObjects4[i].getAABBTop() > gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraHeight(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDschotEnemyObjects4[k] = gdjs.gameCode.GDschotEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDschotEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDschotEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDschotEnemyObjects3_1final.indexOf(gdjs.gameCode.GDschotEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDschotEnemyObjects3_1final.push(gdjs.gameCode.GDschotEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDSniperEnemyObjects3_1final, gdjs.gameCode.GDSniperEnemyObjects3);
gdjs.copyArray(gdjs.gameCode.GDschotEnemyObjects3_1final, gdjs.gameCode.GDschotEnemyObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !(runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() >= 10);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpijlObjects3Objects, 0, 0, "offScreenEnemyIndicator");
}
{for(var i = 0, len = gdjs.gameCode.GDpijlObjects3.length ;i < len;++i) {
    gdjs.gameCode.GDpijlObjects3[i].setAngle(gdjs.evtTools.common.angleBetweenPositions((( gdjs.gameCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects3[0].getPointX("")), (( gdjs.gameCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects3[0].getPointY("")), (( gdjs.gameCode.GDSniperEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDSniperEnemyObjects3[0].getPointX("")), (( gdjs.gameCode.GDSniperEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDSniperEnemyObjects3[0].getPointY(""))));
}
}
{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.gameCode.GDpijlObjects3.length !== 0 ? gdjs.gameCode.GDpijlObjects3[0] : null), (gdjs.gameCode.GDPlayerObjects3.length !== 0 ? gdjs.gameCode.GDPlayerObjects3[0] : null));
}
{for(var i = 0, len = gdjs.gameCode.GDpijlObjects3.length ;i < len;++i) {
    gdjs.gameCode.GDpijlObjects3[i].setX(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 + Math.cos(gdjs.toRad((gdjs.gameCode.GDpijlObjects3[i].getAngle()))) * (gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 - (gdjs.gameCode.GDpijlObjects3[i].getWidth())));
}
}
{for(var i = 0, len = gdjs.gameCode.GDpijlObjects3.length ;i < len;++i) {
    gdjs.gameCode.GDpijlObjects3[i].setY(gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2 + Math.sin(gdjs.toRad((gdjs.gameCode.GDpijlObjects3[i].getAngle()))) * (gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2 - (gdjs.gameCode.GDpijlObjects3[i].getHeight())));
}
}
{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("smallEnemy"), gdjs.gameCode.GDsmallEnemyObjects2);

for (gdjs.gameCode.forEachIndex3 = 0;gdjs.gameCode.forEachIndex3 < gdjs.gameCode.GDsmallEnemyObjects2.length;++gdjs.gameCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects3);
gdjs.copyArray(gdjs.gameCode.GDpijlObjects1, gdjs.gameCode.GDpijlObjects3);

gdjs.gameCode.GDsmallEnemyObjects3.length = 0;


gdjs.gameCode.forEachTemporary3 = gdjs.gameCode.GDsmallEnemyObjects2[gdjs.gameCode.forEachIndex3];
gdjs.gameCode.GDsmallEnemyObjects3.push(gdjs.gameCode.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.gameCode.GDsmallEnemyObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.gameCode.GDsmallEnemyObjects3, gdjs.gameCode.GDsmallEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDsmallEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDsmallEnemyObjects4[i].getAABBRight() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDsmallEnemyObjects4[k] = gdjs.gameCode.GDsmallEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDsmallEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDsmallEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDsmallEnemyObjects3_1final.indexOf(gdjs.gameCode.GDsmallEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDsmallEnemyObjects3_1final.push(gdjs.gameCode.GDsmallEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDsmallEnemyObjects3, gdjs.gameCode.GDsmallEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDsmallEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDsmallEnemyObjects4[i].getAABBLeft() > gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDsmallEnemyObjects4[k] = gdjs.gameCode.GDsmallEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDsmallEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDsmallEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDsmallEnemyObjects3_1final.indexOf(gdjs.gameCode.GDsmallEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDsmallEnemyObjects3_1final.push(gdjs.gameCode.GDsmallEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDsmallEnemyObjects3, gdjs.gameCode.GDsmallEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDsmallEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDsmallEnemyObjects4[i].getAABBBottom() < gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraHeight(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDsmallEnemyObjects4[k] = gdjs.gameCode.GDsmallEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDsmallEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDsmallEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDsmallEnemyObjects3_1final.indexOf(gdjs.gameCode.GDsmallEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDsmallEnemyObjects3_1final.push(gdjs.gameCode.GDsmallEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDsmallEnemyObjects3, gdjs.gameCode.GDsmallEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDsmallEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDsmallEnemyObjects4[i].getAABBTop() > gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraHeight(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDsmallEnemyObjects4[k] = gdjs.gameCode.GDsmallEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDsmallEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDsmallEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDsmallEnemyObjects3_1final.indexOf(gdjs.gameCode.GDsmallEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDsmallEnemyObjects3_1final.push(gdjs.gameCode.GDsmallEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDsmallEnemyObjects3_1final, gdjs.gameCode.GDsmallEnemyObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !(runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() >= 10);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpijlObjects3Objects, 0, 0, "offScreenEnemyIndicator");
}
{for(var i = 0, len = gdjs.gameCode.GDpijlObjects3.length ;i < len;++i) {
    gdjs.gameCode.GDpijlObjects3[i].setAngle(gdjs.evtTools.common.angleBetweenPositions((( gdjs.gameCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects3[0].getPointX("")), (( gdjs.gameCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects3[0].getPointY("")), (( gdjs.gameCode.GDsmallEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDsmallEnemyObjects3[0].getPointX("")), (( gdjs.gameCode.GDsmallEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDsmallEnemyObjects3[0].getPointY(""))));
}
}
{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.gameCode.GDpijlObjects3.length !== 0 ? gdjs.gameCode.GDpijlObjects3[0] : null), (gdjs.gameCode.GDPlayerObjects3.length !== 0 ? gdjs.gameCode.GDPlayerObjects3[0] : null));
}
{for(var i = 0, len = gdjs.gameCode.GDpijlObjects3.length ;i < len;++i) {
    gdjs.gameCode.GDpijlObjects3[i].setX(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 + Math.cos(gdjs.toRad((gdjs.gameCode.GDpijlObjects3[i].getAngle()))) * (gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 - (gdjs.gameCode.GDpijlObjects3[i].getWidth())));
}
}
{for(var i = 0, len = gdjs.gameCode.GDpijlObjects3.length ;i < len;++i) {
    gdjs.gameCode.GDpijlObjects3[i].setY(gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2 + Math.sin(gdjs.toRad((gdjs.gameCode.GDpijlObjects3[i].getAngle()))) * (gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2 - (gdjs.gameCode.GDpijlObjects3[i].getHeight())));
}
}
{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("BigEnemy"), gdjs.gameCode.GDBigEnemyObjects1);

for (gdjs.gameCode.forEachIndex2 = 0;gdjs.gameCode.forEachIndex2 < gdjs.gameCode.GDBigEnemyObjects1.length;++gdjs.gameCode.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects2);
gdjs.copyArray(gdjs.gameCode.GDpijlObjects1, gdjs.gameCode.GDpijlObjects2);

gdjs.gameCode.GDBigEnemyObjects2.length = 0;


gdjs.gameCode.forEachTemporary2 = gdjs.gameCode.GDBigEnemyObjects1[gdjs.gameCode.forEachIndex2];
gdjs.gameCode.GDBigEnemyObjects2.push(gdjs.gameCode.forEachTemporary2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.gameCode.GDBigEnemyObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.gameCode.GDBigEnemyObjects2, gdjs.gameCode.GDBigEnemyObjects3);

for (var i = 0, k = 0, l = gdjs.gameCode.GDBigEnemyObjects3.length;i<l;++i) {
    if ( gdjs.gameCode.GDBigEnemyObjects3[i].getAABBRight() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDBigEnemyObjects3[k] = gdjs.gameCode.GDBigEnemyObjects3[i];
        ++k;
    }
}
gdjs.gameCode.GDBigEnemyObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDBigEnemyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDBigEnemyObjects2_1final.indexOf(gdjs.gameCode.GDBigEnemyObjects3[j]) === -1 )
            gdjs.gameCode.GDBigEnemyObjects2_1final.push(gdjs.gameCode.GDBigEnemyObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDBigEnemyObjects2, gdjs.gameCode.GDBigEnemyObjects3);

for (var i = 0, k = 0, l = gdjs.gameCode.GDBigEnemyObjects3.length;i<l;++i) {
    if ( gdjs.gameCode.GDBigEnemyObjects3[i].getAABBLeft() > gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDBigEnemyObjects3[k] = gdjs.gameCode.GDBigEnemyObjects3[i];
        ++k;
    }
}
gdjs.gameCode.GDBigEnemyObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDBigEnemyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDBigEnemyObjects2_1final.indexOf(gdjs.gameCode.GDBigEnemyObjects3[j]) === -1 )
            gdjs.gameCode.GDBigEnemyObjects2_1final.push(gdjs.gameCode.GDBigEnemyObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDBigEnemyObjects2, gdjs.gameCode.GDBigEnemyObjects3);

for (var i = 0, k = 0, l = gdjs.gameCode.GDBigEnemyObjects3.length;i<l;++i) {
    if ( gdjs.gameCode.GDBigEnemyObjects3[i].getAABBBottom() < gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraHeight(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDBigEnemyObjects3[k] = gdjs.gameCode.GDBigEnemyObjects3[i];
        ++k;
    }
}
gdjs.gameCode.GDBigEnemyObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDBigEnemyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDBigEnemyObjects2_1final.indexOf(gdjs.gameCode.GDBigEnemyObjects3[j]) === -1 )
            gdjs.gameCode.GDBigEnemyObjects2_1final.push(gdjs.gameCode.GDBigEnemyObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDBigEnemyObjects2, gdjs.gameCode.GDBigEnemyObjects3);

for (var i = 0, k = 0, l = gdjs.gameCode.GDBigEnemyObjects3.length;i<l;++i) {
    if ( gdjs.gameCode.GDBigEnemyObjects3[i].getAABBTop() > gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraHeight(runtimeScene, "", 0) / 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDBigEnemyObjects3[k] = gdjs.gameCode.GDBigEnemyObjects3[i];
        ++k;
    }
}
gdjs.gameCode.GDBigEnemyObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDBigEnemyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDBigEnemyObjects2_1final.indexOf(gdjs.gameCode.GDBigEnemyObjects3[j]) === -1 )
            gdjs.gameCode.GDBigEnemyObjects2_1final.push(gdjs.gameCode.GDBigEnemyObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDBigEnemyObjects2_1final, gdjs.gameCode.GDBigEnemyObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !(runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() >= 10);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpijlObjects2Objects, 0, 0, "offScreenEnemyIndicator");
}
{for(var i = 0, len = gdjs.gameCode.GDpijlObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDpijlObjects2[i].setAngle(gdjs.evtTools.common.angleBetweenPositions((( gdjs.gameCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects2[0].getPointX("")), (( gdjs.gameCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects2[0].getPointY("")), (( gdjs.gameCode.GDBigEnemyObjects2.length === 0 ) ? 0 :gdjs.gameCode.GDBigEnemyObjects2[0].getPointX("")), (( gdjs.gameCode.GDBigEnemyObjects2.length === 0 ) ? 0 :gdjs.gameCode.GDBigEnemyObjects2[0].getPointY(""))));
}
}
{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.gameCode.GDpijlObjects2.length !== 0 ? gdjs.gameCode.GDpijlObjects2[0] : null), (gdjs.gameCode.GDPlayerObjects2.length !== 0 ? gdjs.gameCode.GDPlayerObjects2[0] : null));
}
{for(var i = 0, len = gdjs.gameCode.GDpijlObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDpijlObjects2[i].setX(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 + Math.cos(gdjs.toRad((gdjs.gameCode.GDpijlObjects2[i].getAngle()))) * (gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 - (gdjs.gameCode.GDpijlObjects2[i].getWidth())));
}
}
{for(var i = 0, len = gdjs.gameCode.GDpijlObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDpijlObjects2[i].setY(gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2 + Math.sin(gdjs.toRad((gdjs.gameCode.GDpijlObjects2[i].getAngle()))) * (gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2 - (gdjs.gameCode.GDpijlObjects2[i].getHeight())));
}
}
}
}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.gameCode.GDEnemyObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDsmallEnemyObjects1Objects = Hashtable.newFrom({"smallEnemy": gdjs.gameCode.GDsmallEnemyObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBigEnemyObjects1Objects = Hashtable.newFrom({"BigEnemy": gdjs.gameCode.GDBigEnemyObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDSniperEnemyObjects1Objects = Hashtable.newFrom({"SniperEnemy": gdjs.gameCode.GDSniperEnemyObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDschotEnemyObjects1Objects = Hashtable.newFrom({"schotEnemy": gdjs.gameCode.GDschotEnemyObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.gameCode.GDbulletObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDHealthUPObjects1Objects = Hashtable.newFrom({"HealthUP": gdjs.gameCode.GDHealthUPObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoinObjects1Objects = Hashtable.newFrom({"Coin": gdjs.gameCode.GDCoinObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet2Objects1Objects = Hashtable.newFrom({"bullet2": gdjs.gameCode.GDbullet2Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.gameCode.GDPlayerObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet4Objects1Objects = Hashtable.newFrom({"bullet4": gdjs.gameCode.GDbullet4Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.gameCode.GDPlayerObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.gameCode.GDPlayerObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpeople1Objects1Objects = Hashtable.newFrom({"people1": gdjs.gameCode.GDpeople1Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.gameCode.GDPlayerObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin4Objects1Objects = Hashtable.newFrom({"Coin4": gdjs.gameCode.GDCoin4Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.gameCode.GDPlayerObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin2Objects1Objects = Hashtable.newFrom({"Coin2": gdjs.gameCode.GDCoin2Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.gameCode.GDPlayerObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin3Objects1Objects = Hashtable.newFrom({"Coin3": gdjs.gameCode.GDCoin3Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerBulletObjects1Objects = Hashtable.newFrom({"PlayerBullet": gdjs.gameCode.GDPlayerBulletObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerBulletObjects1Objects = Hashtable.newFrom({"PlayerBullet": gdjs.gameCode.GDPlayerBulletObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerBulletObjects1Objects = Hashtable.newFrom({"PlayerBullet": gdjs.gameCode.GDPlayerBulletObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDLargeDebrisParticleObjects2Objects = Hashtable.newFrom({"LargeDebrisParticle": gdjs.gameCode.GDLargeDebrisParticleObjects2});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDArmorUPObjects3Objects = Hashtable.newFrom({"ArmorUP": gdjs.gameCode.GDArmorUPObjects3});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbulletObjects3Objects = Hashtable.newFrom({"bullet": gdjs.gameCode.GDbulletObjects3});
gdjs.gameCode.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.gameCode.GDEnemyObjects2, gdjs.gameCode.GDEnemyObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.gameCode.GDEnemyObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.gameCode.GDEnemyObjects2, gdjs.gameCode.GDEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDEnemyObjects4[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDEnemyObjects4[k] = gdjs.gameCode.GDEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDEnemyObjects3_1final.indexOf(gdjs.gameCode.GDEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDEnemyObjects3_1final.push(gdjs.gameCode.GDEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDEnemyObjects2, gdjs.gameCode.GDEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDEnemyObjects4[i].getVariables().getFromIndex(1)) == 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDEnemyObjects4[k] = gdjs.gameCode.GDEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDEnemyObjects3_1final.indexOf(gdjs.gameCode.GDEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDEnemyObjects3_1final.push(gdjs.gameCode.GDEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDEnemyObjects3_1final, gdjs.gameCode.GDEnemyObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24709444);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDEnemyObjects3 */
gdjs.gameCode.GDArmorUPObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDArmorUPObjects3Objects, (( gdjs.gameCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects3[0].getCenterXInScene()), (( gdjs.gameCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects3[0].getCenterYInScene()), "");
}
}

}


{

gdjs.copyArray(gdjs.gameCode.GDEnemyObjects2, gdjs.gameCode.GDEnemyObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.gameCode.GDEnemyObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.gameCode.GDEnemyObjects2, gdjs.gameCode.GDEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDEnemyObjects4[i].getVariables().getFromIndex(1)) == 3 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDEnemyObjects4[k] = gdjs.gameCode.GDEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDEnemyObjects3_1final.indexOf(gdjs.gameCode.GDEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDEnemyObjects3_1final.push(gdjs.gameCode.GDEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDEnemyObjects2, gdjs.gameCode.GDEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDEnemyObjects4[i].getVariables().getFromIndex(1)) == 4 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDEnemyObjects4[k] = gdjs.gameCode.GDEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDEnemyObjects3_1final.indexOf(gdjs.gameCode.GDEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDEnemyObjects3_1final.push(gdjs.gameCode.GDEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDEnemyObjects2, gdjs.gameCode.GDEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDEnemyObjects4[i].getVariables().getFromIndex(1)) == 5 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDEnemyObjects4[k] = gdjs.gameCode.GDEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDEnemyObjects3_1final.indexOf(gdjs.gameCode.GDEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDEnemyObjects3_1final.push(gdjs.gameCode.GDEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDEnemyObjects2, gdjs.gameCode.GDEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDEnemyObjects4[i].getVariables().getFromIndex(1)) == 6 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDEnemyObjects4[k] = gdjs.gameCode.GDEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDEnemyObjects3_1final.indexOf(gdjs.gameCode.GDEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDEnemyObjects3_1final.push(gdjs.gameCode.GDEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDEnemyObjects2, gdjs.gameCode.GDEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDEnemyObjects4[i].getVariables().getFromIndex(1)) == 7 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDEnemyObjects4[k] = gdjs.gameCode.GDEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDEnemyObjects3_1final.indexOf(gdjs.gameCode.GDEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDEnemyObjects3_1final.push(gdjs.gameCode.GDEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDEnemyObjects3_1final, gdjs.gameCode.GDEnemyObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24711340);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDEnemyObjects3 */
gdjs.gameCode.GDbulletObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbulletObjects3Objects, (( gdjs.gameCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects3[0].getCenterXInScene()), (( gdjs.gameCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects3[0].getCenterYInScene()), "");
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.gameCode.GDEnemyObjects2, gdjs.gameCode.GDEnemyObjects3);

{for(var i = 0, len = gdjs.gameCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.gameCode.GDEnemyObjects3[i].deleteFromScene(runtimeScene);
}
}
}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDLargeDebrisParticleObjects2Objects = Hashtable.newFrom({"LargeDebrisParticle": gdjs.gameCode.GDLargeDebrisParticleObjects2});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbulletObjects3Objects = Hashtable.newFrom({"bullet": gdjs.gameCode.GDbulletObjects3});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoinObjects3Objects = Hashtable.newFrom({"Coin": gdjs.gameCode.GDCoinObjects3});
gdjs.gameCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.gameCode.GDschotEnemyObjects2, gdjs.gameCode.GDschotEnemyObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.gameCode.GDschotEnemyObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.gameCode.GDschotEnemyObjects2, gdjs.gameCode.GDschotEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDschotEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDschotEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDschotEnemyObjects4[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDschotEnemyObjects4[k] = gdjs.gameCode.GDschotEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDschotEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDschotEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDschotEnemyObjects3_1final.indexOf(gdjs.gameCode.GDschotEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDschotEnemyObjects3_1final.push(gdjs.gameCode.GDschotEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDschotEnemyObjects2, gdjs.gameCode.GDschotEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDschotEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDschotEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDschotEnemyObjects4[i].getVariables().getFromIndex(1)) == 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDschotEnemyObjects4[k] = gdjs.gameCode.GDschotEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDschotEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDschotEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDschotEnemyObjects3_1final.indexOf(gdjs.gameCode.GDschotEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDschotEnemyObjects3_1final.push(gdjs.gameCode.GDschotEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDschotEnemyObjects2, gdjs.gameCode.GDschotEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDschotEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDschotEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDschotEnemyObjects4[i].getVariables().getFromIndex(1)) == 3 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDschotEnemyObjects4[k] = gdjs.gameCode.GDschotEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDschotEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDschotEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDschotEnemyObjects3_1final.indexOf(gdjs.gameCode.GDschotEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDschotEnemyObjects3_1final.push(gdjs.gameCode.GDschotEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDschotEnemyObjects2, gdjs.gameCode.GDschotEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDschotEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDschotEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDschotEnemyObjects4[i].getVariables().getFromIndex(1)) == 4 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDschotEnemyObjects4[k] = gdjs.gameCode.GDschotEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDschotEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDschotEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDschotEnemyObjects3_1final.indexOf(gdjs.gameCode.GDschotEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDschotEnemyObjects3_1final.push(gdjs.gameCode.GDschotEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDschotEnemyObjects2, gdjs.gameCode.GDschotEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDschotEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDschotEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDschotEnemyObjects4[i].getVariables().getFromIndex(1)) == 5 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDschotEnemyObjects4[k] = gdjs.gameCode.GDschotEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDschotEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDschotEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDschotEnemyObjects3_1final.indexOf(gdjs.gameCode.GDschotEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDschotEnemyObjects3_1final.push(gdjs.gameCode.GDschotEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDschotEnemyObjects3_1final, gdjs.gameCode.GDschotEnemyObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24714716);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDschotEnemyObjects3 */
gdjs.gameCode.GDCoinObjects3.length = 0;

gdjs.gameCode.GDbulletObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbulletObjects3Objects, (( gdjs.gameCode.GDschotEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDschotEnemyObjects3[0].getCenterXInScene()), (( gdjs.gameCode.GDschotEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDschotEnemyObjects3[0].getCenterYInScene()), "");
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoinObjects3Objects, (( gdjs.gameCode.GDschotEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDschotEnemyObjects3[0].getCenterXInScene()), (( gdjs.gameCode.GDschotEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDschotEnemyObjects3[0].getCenterYInScene()), "");
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.gameCode.GDschotEnemyObjects2, gdjs.gameCode.GDschotEnemyObjects3);

{for(var i = 0, len = gdjs.gameCode.GDschotEnemyObjects3.length ;i < len;++i) {
    gdjs.gameCode.GDschotEnemyObjects3[i].deleteFromScene(runtimeScene);
}
}
}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDLargeDebrisParticleObjects2Objects = Hashtable.newFrom({"LargeDebrisParticle": gdjs.gameCode.GDLargeDebrisParticleObjects2});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDArmorUPObjects3Objects = Hashtable.newFrom({"ArmorUP": gdjs.gameCode.GDArmorUPObjects3});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbulletObjects3Objects = Hashtable.newFrom({"bullet": gdjs.gameCode.GDbulletObjects3});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoinObjects3Objects = Hashtable.newFrom({"Coin": gdjs.gameCode.GDCoinObjects3});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDHealthUPObjects3Objects = Hashtable.newFrom({"HealthUP": gdjs.gameCode.GDHealthUPObjects3});
gdjs.gameCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.gameCode.GDsmallEnemyObjects2, gdjs.gameCode.GDsmallEnemyObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.gameCode.GDsmallEnemyObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.gameCode.GDsmallEnemyObjects2, gdjs.gameCode.GDsmallEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDsmallEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDsmallEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDsmallEnemyObjects4[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDsmallEnemyObjects4[k] = gdjs.gameCode.GDsmallEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDsmallEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDsmallEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDsmallEnemyObjects3_1final.indexOf(gdjs.gameCode.GDsmallEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDsmallEnemyObjects3_1final.push(gdjs.gameCode.GDsmallEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDsmallEnemyObjects2, gdjs.gameCode.GDsmallEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDsmallEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDsmallEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDsmallEnemyObjects4[i].getVariables().getFromIndex(1)) == 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDsmallEnemyObjects4[k] = gdjs.gameCode.GDsmallEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDsmallEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDsmallEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDsmallEnemyObjects3_1final.indexOf(gdjs.gameCode.GDsmallEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDsmallEnemyObjects3_1final.push(gdjs.gameCode.GDsmallEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDsmallEnemyObjects3_1final, gdjs.gameCode.GDsmallEnemyObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24719340);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.gameCode.GDEnemyObjects2, gdjs.gameCode.GDEnemyObjects3);

gdjs.gameCode.GDArmorUPObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDArmorUPObjects3Objects, (( gdjs.gameCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects3[0].getCenterXInScene()), (( gdjs.gameCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects3[0].getCenterYInScene()), "");
}
}

}


{

gdjs.copyArray(gdjs.gameCode.GDsmallEnemyObjects2, gdjs.gameCode.GDsmallEnemyObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.gameCode.GDsmallEnemyObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.gameCode.GDsmallEnemyObjects2, gdjs.gameCode.GDsmallEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDsmallEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDsmallEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDsmallEnemyObjects4[i].getVariables().getFromIndex(1)) == 4 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDsmallEnemyObjects4[k] = gdjs.gameCode.GDsmallEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDsmallEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDsmallEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDsmallEnemyObjects3_1final.indexOf(gdjs.gameCode.GDsmallEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDsmallEnemyObjects3_1final.push(gdjs.gameCode.GDsmallEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDsmallEnemyObjects2, gdjs.gameCode.GDsmallEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDsmallEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDsmallEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDsmallEnemyObjects4[i].getVariables().getFromIndex(1)) == 5 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDsmallEnemyObjects4[k] = gdjs.gameCode.GDsmallEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDsmallEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDsmallEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDsmallEnemyObjects3_1final.indexOf(gdjs.gameCode.GDsmallEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDsmallEnemyObjects3_1final.push(gdjs.gameCode.GDsmallEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDsmallEnemyObjects2, gdjs.gameCode.GDsmallEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDsmallEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDsmallEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDsmallEnemyObjects4[i].getVariables().getFromIndex(1)) == 6 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDsmallEnemyObjects4[k] = gdjs.gameCode.GDsmallEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDsmallEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDsmallEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDsmallEnemyObjects3_1final.indexOf(gdjs.gameCode.GDsmallEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDsmallEnemyObjects3_1final.push(gdjs.gameCode.GDsmallEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDsmallEnemyObjects3_1final, gdjs.gameCode.GDsmallEnemyObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24720948);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.gameCode.GDEnemyObjects2, gdjs.gameCode.GDEnemyObjects3);

gdjs.gameCode.GDCoinObjects3.length = 0;

gdjs.gameCode.GDbulletObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbulletObjects3Objects, (( gdjs.gameCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects3[0].getCenterXInScene()), (( gdjs.gameCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects3[0].getCenterYInScene()), "");
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoinObjects3Objects, (( gdjs.gameCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects3[0].getCenterXInScene()), (( gdjs.gameCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects3[0].getCenterYInScene()), "");
}
}

}


{

gdjs.copyArray(gdjs.gameCode.GDsmallEnemyObjects2, gdjs.gameCode.GDsmallEnemyObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.gameCode.GDsmallEnemyObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.gameCode.GDsmallEnemyObjects2, gdjs.gameCode.GDsmallEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDsmallEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDsmallEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDsmallEnemyObjects4[i].getVariables().getFromIndex(1)) == 7 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDsmallEnemyObjects4[k] = gdjs.gameCode.GDsmallEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDsmallEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDsmallEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDsmallEnemyObjects3_1final.indexOf(gdjs.gameCode.GDsmallEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDsmallEnemyObjects3_1final.push(gdjs.gameCode.GDsmallEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDsmallEnemyObjects3_1final, gdjs.gameCode.GDsmallEnemyObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24722852);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.gameCode.GDEnemyObjects2, gdjs.gameCode.GDEnemyObjects3);

gdjs.gameCode.GDHealthUPObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDHealthUPObjects3Objects, (( gdjs.gameCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects3[0].getCenterXInScene()), (( gdjs.gameCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects3[0].getCenterYInScene()), "");
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.gameCode.GDsmallEnemyObjects2, gdjs.gameCode.GDsmallEnemyObjects3);

{for(var i = 0, len = gdjs.gameCode.GDsmallEnemyObjects3.length ;i < len;++i) {
    gdjs.gameCode.GDsmallEnemyObjects3[i].deleteFromScene(runtimeScene);
}
}
}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDLargeDebrisParticleObjects2Objects = Hashtable.newFrom({"LargeDebrisParticle": gdjs.gameCode.GDLargeDebrisParticleObjects2});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbulletObjects3Objects = Hashtable.newFrom({"bullet": gdjs.gameCode.GDbulletObjects3});
gdjs.gameCode.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.gameCode.GDBigEnemyObjects2, gdjs.gameCode.GDBigEnemyObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.gameCode.GDBigEnemyObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.gameCode.GDBigEnemyObjects2, gdjs.gameCode.GDBigEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDBigEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDBigEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDBigEnemyObjects4[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDBigEnemyObjects4[k] = gdjs.gameCode.GDBigEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDBigEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDBigEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDBigEnemyObjects3_1final.indexOf(gdjs.gameCode.GDBigEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDBigEnemyObjects3_1final.push(gdjs.gameCode.GDBigEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDBigEnemyObjects2, gdjs.gameCode.GDBigEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDBigEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDBigEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDBigEnemyObjects4[i].getVariables().getFromIndex(1)) == 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDBigEnemyObjects4[k] = gdjs.gameCode.GDBigEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDBigEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDBigEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDBigEnemyObjects3_1final.indexOf(gdjs.gameCode.GDBigEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDBigEnemyObjects3_1final.push(gdjs.gameCode.GDBigEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDBigEnemyObjects2, gdjs.gameCode.GDBigEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDBigEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDBigEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDBigEnemyObjects4[i].getVariables().getFromIndex(1)) == 3 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDBigEnemyObjects4[k] = gdjs.gameCode.GDBigEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDBigEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDBigEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDBigEnemyObjects3_1final.indexOf(gdjs.gameCode.GDBigEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDBigEnemyObjects3_1final.push(gdjs.gameCode.GDBigEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDBigEnemyObjects2, gdjs.gameCode.GDBigEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDBigEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDBigEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDBigEnemyObjects4[i].getVariables().getFromIndex(1)) == 4 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDBigEnemyObjects4[k] = gdjs.gameCode.GDBigEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDBigEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDBigEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDBigEnemyObjects3_1final.indexOf(gdjs.gameCode.GDBigEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDBigEnemyObjects3_1final.push(gdjs.gameCode.GDBigEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDBigEnemyObjects2, gdjs.gameCode.GDBigEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDBigEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDBigEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDBigEnemyObjects4[i].getVariables().getFromIndex(1)) == 5 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDBigEnemyObjects4[k] = gdjs.gameCode.GDBigEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDBigEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDBigEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDBigEnemyObjects3_1final.indexOf(gdjs.gameCode.GDBigEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDBigEnemyObjects3_1final.push(gdjs.gameCode.GDBigEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDBigEnemyObjects3_1final, gdjs.gameCode.GDBigEnemyObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24726084);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.gameCode.GDEnemyObjects2, gdjs.gameCode.GDEnemyObjects3);

gdjs.gameCode.GDbulletObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbulletObjects3Objects, (( gdjs.gameCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects3[0].getCenterXInScene()), (( gdjs.gameCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects3[0].getCenterYInScene()), "");
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.gameCode.GDBigEnemyObjects2, gdjs.gameCode.GDBigEnemyObjects3);

{for(var i = 0, len = gdjs.gameCode.GDBigEnemyObjects3.length ;i < len;++i) {
    gdjs.gameCode.GDBigEnemyObjects3[i].deleteFromScene(runtimeScene);
}
}
}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDLargeDebrisParticleObjects2Objects = Hashtable.newFrom({"LargeDebrisParticle": gdjs.gameCode.GDLargeDebrisParticleObjects2});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDHealthUPObjects3Objects = Hashtable.newFrom({"HealthUP": gdjs.gameCode.GDHealthUPObjects3});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbulletObjects3Objects = Hashtable.newFrom({"bullet": gdjs.gameCode.GDbulletObjects3});
gdjs.gameCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.gameCode.GDSniperEnemyObjects2, gdjs.gameCode.GDSniperEnemyObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.gameCode.GDSniperEnemyObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.gameCode.GDSniperEnemyObjects2, gdjs.gameCode.GDSniperEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDSniperEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDSniperEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDSniperEnemyObjects4[i].getVariables().getFromIndex(1)) == 6 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDSniperEnemyObjects4[k] = gdjs.gameCode.GDSniperEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDSniperEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDSniperEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDSniperEnemyObjects3_1final.indexOf(gdjs.gameCode.GDSniperEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDSniperEnemyObjects3_1final.push(gdjs.gameCode.GDSniperEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDSniperEnemyObjects2, gdjs.gameCode.GDSniperEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDSniperEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDSniperEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDSniperEnemyObjects4[i].getVariables().getFromIndex(1)) == 7 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDSniperEnemyObjects4[k] = gdjs.gameCode.GDSniperEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDSniperEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDSniperEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDSniperEnemyObjects3_1final.indexOf(gdjs.gameCode.GDSniperEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDSniperEnemyObjects3_1final.push(gdjs.gameCode.GDSniperEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDSniperEnemyObjects3_1final, gdjs.gameCode.GDSniperEnemyObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24729756);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.gameCode.GDEnemyObjects2, gdjs.gameCode.GDEnemyObjects3);

gdjs.gameCode.GDHealthUPObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDHealthUPObjects3Objects, (( gdjs.gameCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects3[0].getCenterXInScene()), (( gdjs.gameCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects3[0].getCenterYInScene()), "");
}
}

}


{

gdjs.copyArray(gdjs.gameCode.GDSniperEnemyObjects2, gdjs.gameCode.GDSniperEnemyObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.gameCode.GDSniperEnemyObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.gameCode.GDSniperEnemyObjects2, gdjs.gameCode.GDSniperEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDSniperEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDSniperEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDSniperEnemyObjects4[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDSniperEnemyObjects4[k] = gdjs.gameCode.GDSniperEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDSniperEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDSniperEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDSniperEnemyObjects3_1final.indexOf(gdjs.gameCode.GDSniperEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDSniperEnemyObjects3_1final.push(gdjs.gameCode.GDSniperEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDSniperEnemyObjects2, gdjs.gameCode.GDSniperEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDSniperEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDSniperEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDSniperEnemyObjects4[i].getVariables().getFromIndex(1)) == 2 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDSniperEnemyObjects4[k] = gdjs.gameCode.GDSniperEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDSniperEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDSniperEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDSniperEnemyObjects3_1final.indexOf(gdjs.gameCode.GDSniperEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDSniperEnemyObjects3_1final.push(gdjs.gameCode.GDSniperEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDSniperEnemyObjects2, gdjs.gameCode.GDSniperEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDSniperEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDSniperEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDSniperEnemyObjects4[i].getVariables().getFromIndex(1)) == 3 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDSniperEnemyObjects4[k] = gdjs.gameCode.GDSniperEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDSniperEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDSniperEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDSniperEnemyObjects3_1final.indexOf(gdjs.gameCode.GDSniperEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDSniperEnemyObjects3_1final.push(gdjs.gameCode.GDSniperEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDSniperEnemyObjects2, gdjs.gameCode.GDSniperEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDSniperEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDSniperEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDSniperEnemyObjects4[i].getVariables().getFromIndex(1)) == 4 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDSniperEnemyObjects4[k] = gdjs.gameCode.GDSniperEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDSniperEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDSniperEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDSniperEnemyObjects3_1final.indexOf(gdjs.gameCode.GDSniperEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDSniperEnemyObjects3_1final.push(gdjs.gameCode.GDSniperEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDSniperEnemyObjects2, gdjs.gameCode.GDSniperEnemyObjects4);

for (var i = 0, k = 0, l = gdjs.gameCode.GDSniperEnemyObjects4.length;i<l;++i) {
    if ( gdjs.gameCode.GDSniperEnemyObjects4[i].getVariableNumber(gdjs.gameCode.GDSniperEnemyObjects4[i].getVariables().getFromIndex(1)) == 5 ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDSniperEnemyObjects4[k] = gdjs.gameCode.GDSniperEnemyObjects4[i];
        ++k;
    }
}
gdjs.gameCode.GDSniperEnemyObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDSniperEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDSniperEnemyObjects3_1final.indexOf(gdjs.gameCode.GDSniperEnemyObjects4[j]) === -1 )
            gdjs.gameCode.GDSniperEnemyObjects3_1final.push(gdjs.gameCode.GDSniperEnemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDSniperEnemyObjects3_1final, gdjs.gameCode.GDSniperEnemyObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24731604);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.gameCode.GDEnemyObjects2, gdjs.gameCode.GDEnemyObjects3);

gdjs.gameCode.GDbulletObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbulletObjects3Objects, (( gdjs.gameCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects3[0].getCenterXInScene()), (( gdjs.gameCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects3[0].getCenterYInScene()), "");
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.gameCode.GDSniperEnemyObjects2, gdjs.gameCode.GDSniperEnemyObjects3);

{for(var i = 0, len = gdjs.gameCode.GDSniperEnemyObjects3.length ;i < len;++i) {
    gdjs.gameCode.GDSniperEnemyObjects3[i].deleteFromScene(runtimeScene);
}
}
}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.gameCode.GDPlayerObjects2});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDEnemyObjects2Objects = Hashtable.newFrom({"Enemy": gdjs.gameCode.GDEnemyObjects2});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.gameCode.GDPlayerObjects2});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDsmallEnemyObjects2Objects = Hashtable.newFrom({"smallEnemy": gdjs.gameCode.GDsmallEnemyObjects2});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.gameCode.GDPlayerObjects2});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBigEnemyObjects2Objects = Hashtable.newFrom({"BigEnemy": gdjs.gameCode.GDBigEnemyObjects2});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDLargeDebrisParticleObjects1Objects = Hashtable.newFrom({"LargeDebrisParticle": gdjs.gameCode.GDLargeDebrisParticleObjects1});
gdjs.gameCode.asyncCallback24735660 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameCode.localVariables);
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}
gdjs.gameCode.localVariables.length = 0;
}
gdjs.gameCode.idToCallbackMap.set(24735660, gdjs.gameCode.asyncCallback24735660);
gdjs.gameCode.eventsList13 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.15), (runtimeScene) => (gdjs.gameCode.asyncCallback24735660(runtimeScene, asyncObjectsList)), 24735660, asyncObjectsList);
}
}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.gameCode.GDPlayerObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet3Objects1Objects = Hashtable.newFrom({"bullet3": gdjs.gameCode.GDbullet3Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDLargeDebrisParticleObjects1Objects = Hashtable.newFrom({"LargeDebrisParticle": gdjs.gameCode.GDLargeDebrisParticleObjects1});
gdjs.gameCode.asyncCallback24739316 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameCode.localVariables);
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}
gdjs.gameCode.localVariables.length = 0;
}
gdjs.gameCode.idToCallbackMap.set(24739316, gdjs.gameCode.asyncCallback24739316);
gdjs.gameCode.eventsList14 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.15), (runtimeScene) => (gdjs.gameCode.asyncCallback24739316(runtimeScene, asyncObjectsList)), 24739316, asyncObjectsList);
}
}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.gameCode.GDPlayerObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet2Objects1Objects = Hashtable.newFrom({"bullet2": gdjs.gameCode.GDbullet2Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDLargeDebrisParticleObjects1Objects = Hashtable.newFrom({"LargeDebrisParticle": gdjs.gameCode.GDLargeDebrisParticleObjects1});
gdjs.gameCode.asyncCallback24740788 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameCode.localVariables);
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}
gdjs.gameCode.localVariables.length = 0;
}
gdjs.gameCode.idToCallbackMap.set(24740788, gdjs.gameCode.asyncCallback24740788);
gdjs.gameCode.eventsList15 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.15), (runtimeScene) => (gdjs.gameCode.asyncCallback24740788(runtimeScene, asyncObjectsList)), 24740788, asyncObjectsList);
}
}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.gameCode.GDPlayerObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet4Objects1Objects = Hashtable.newFrom({"bullet4": gdjs.gameCode.GDbullet4Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDLargeDebrisParticleObjects1Objects = Hashtable.newFrom({"LargeDebrisParticle": gdjs.gameCode.GDLargeDebrisParticleObjects1});
gdjs.gameCode.asyncCallback24744604 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameCode.localVariables);
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}
gdjs.gameCode.localVariables.length = 0;
}
gdjs.gameCode.idToCallbackMap.set(24744604, gdjs.gameCode.asyncCallback24744604);
gdjs.gameCode.eventsList16 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.15), (runtimeScene) => (gdjs.gameCode.asyncCallback24744604(runtimeScene, asyncObjectsList)), 24744604, asyncObjectsList);
}
}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerBulletObjects1Objects = Hashtable.newFrom({"PlayerBullet": gdjs.gameCode.GDPlayerBulletObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.gameCode.GDEnemyObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDDebrisParticleObjects1Objects = Hashtable.newFrom({"DebrisParticle": gdjs.gameCode.GDDebrisParticleObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.gameCode.GDExplosionObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin2Objects1Objects = Hashtable.newFrom({"Coin2": gdjs.gameCode.GDCoin2Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.gameCode.GDExplosionObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.gameCode.GDEnemyObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDDebrisParticleObjects1Objects = Hashtable.newFrom({"DebrisParticle": gdjs.gameCode.GDDebrisParticleObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin2Objects1Objects = Hashtable.newFrom({"Coin2": gdjs.gameCode.GDCoin2Objects1});
gdjs.gameCode.asyncCallback24750644 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Enemy"), gdjs.gameCode.GDEnemyObjects2);

{for(var i = 0, len = gdjs.gameCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDEnemyObjects2[i].clearForces();
}
}
gdjs.gameCode.localVariables.length = 0;
}
gdjs.gameCode.idToCallbackMap.set(24750644, gdjs.gameCode.asyncCallback24750644);
gdjs.gameCode.eventsList17 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameCode.localVariables);
for (const obj of gdjs.gameCode.GDEnemyObjects1) asyncObjectsList.addObject("Enemy", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(runtimeScene.getGame().getVariables().getFromIndex(13).getAsNumber()), (runtimeScene) => (gdjs.gameCode.asyncCallback24750644(runtimeScene, asyncObjectsList)), 24750644, asyncObjectsList);
}
}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerBulletObjects1Objects = Hashtable.newFrom({"PlayerBullet": gdjs.gameCode.GDPlayerBulletObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDschotEnemyObjects1Objects = Hashtable.newFrom({"schotEnemy": gdjs.gameCode.GDschotEnemyObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDDebrisParticleObjects1Objects = Hashtable.newFrom({"DebrisParticle": gdjs.gameCode.GDDebrisParticleObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.gameCode.GDExplosionObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin2Objects1Objects = Hashtable.newFrom({"Coin2": gdjs.gameCode.GDCoin2Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.gameCode.GDExplosionObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDschotEnemyObjects1Objects = Hashtable.newFrom({"schotEnemy": gdjs.gameCode.GDschotEnemyObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDDebrisParticleObjects1Objects = Hashtable.newFrom({"DebrisParticle": gdjs.gameCode.GDDebrisParticleObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin2Objects1Objects = Hashtable.newFrom({"Coin2": gdjs.gameCode.GDCoin2Objects1});
gdjs.gameCode.asyncCallback24756420 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("schotEnemy"), gdjs.gameCode.GDschotEnemyObjects2);

{for(var i = 0, len = gdjs.gameCode.GDschotEnemyObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDschotEnemyObjects2[i].clearForces();
}
}
gdjs.gameCode.localVariables.length = 0;
}
gdjs.gameCode.idToCallbackMap.set(24756420, gdjs.gameCode.asyncCallback24756420);
gdjs.gameCode.eventsList18 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameCode.localVariables);
for (const obj of gdjs.gameCode.GDschotEnemyObjects1) asyncObjectsList.addObject("schotEnemy", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(runtimeScene.getGame().getVariables().getFromIndex(13).getAsNumber()), (runtimeScene) => (gdjs.gameCode.asyncCallback24756420(runtimeScene, asyncObjectsList)), 24756420, asyncObjectsList);
}
}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerBulletObjects1Objects = Hashtable.newFrom({"PlayerBullet": gdjs.gameCode.GDPlayerBulletObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDsmallEnemyObjects1Objects = Hashtable.newFrom({"smallEnemy": gdjs.gameCode.GDsmallEnemyObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDDebrisParticleObjects1Objects = Hashtable.newFrom({"DebrisParticle": gdjs.gameCode.GDDebrisParticleObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.gameCode.GDExplosionObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin3Objects1Objects = Hashtable.newFrom({"Coin3": gdjs.gameCode.GDCoin3Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.gameCode.GDExplosionObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDsmallEnemyObjects1Objects = Hashtable.newFrom({"smallEnemy": gdjs.gameCode.GDsmallEnemyObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDDebrisParticleObjects1Objects = Hashtable.newFrom({"DebrisParticle": gdjs.gameCode.GDDebrisParticleObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin3Objects1Objects = Hashtable.newFrom({"Coin3": gdjs.gameCode.GDCoin3Objects1});
gdjs.gameCode.asyncCallback24762404 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("smallEnemy"), gdjs.gameCode.GDsmallEnemyObjects2);

{for(var i = 0, len = gdjs.gameCode.GDsmallEnemyObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDsmallEnemyObjects2[i].clearForces();
}
}
gdjs.gameCode.localVariables.length = 0;
}
gdjs.gameCode.idToCallbackMap.set(24762404, gdjs.gameCode.asyncCallback24762404);
gdjs.gameCode.eventsList19 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameCode.localVariables);
for (const obj of gdjs.gameCode.GDsmallEnemyObjects1) asyncObjectsList.addObject("smallEnemy", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(runtimeScene.getGame().getVariables().getFromIndex(13).getAsNumber()), (runtimeScene) => (gdjs.gameCode.asyncCallback24762404(runtimeScene, asyncObjectsList)), 24762404, asyncObjectsList);
}
}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerBulletObjects1Objects = Hashtable.newFrom({"PlayerBullet": gdjs.gameCode.GDPlayerBulletObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBigEnemyObjects1Objects = Hashtable.newFrom({"BigEnemy": gdjs.gameCode.GDBigEnemyObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDDebrisParticleObjects1Objects = Hashtable.newFrom({"DebrisParticle": gdjs.gameCode.GDDebrisParticleObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.gameCode.GDExplosionObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin4Objects1Objects = Hashtable.newFrom({"Coin4": gdjs.gameCode.GDCoin4Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.gameCode.GDExplosionObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBigEnemyObjects1Objects = Hashtable.newFrom({"BigEnemy": gdjs.gameCode.GDBigEnemyObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDDebrisParticleObjects1Objects = Hashtable.newFrom({"DebrisParticle": gdjs.gameCode.GDDebrisParticleObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin4Objects1Objects = Hashtable.newFrom({"Coin4": gdjs.gameCode.GDCoin4Objects1});
gdjs.gameCode.asyncCallback24768524 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("BigEnemy"), gdjs.gameCode.GDBigEnemyObjects2);

{for(var i = 0, len = gdjs.gameCode.GDBigEnemyObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDBigEnemyObjects2[i].clearForces();
}
}
gdjs.gameCode.localVariables.length = 0;
}
gdjs.gameCode.idToCallbackMap.set(24768524, gdjs.gameCode.asyncCallback24768524);
gdjs.gameCode.eventsList20 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameCode.localVariables);
for (const obj of gdjs.gameCode.GDBigEnemyObjects1) asyncObjectsList.addObject("BigEnemy", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(runtimeScene.getGame().getVariables().getFromIndex(13).getAsNumber()), (runtimeScene) => (gdjs.gameCode.asyncCallback24768524(runtimeScene, asyncObjectsList)), 24768524, asyncObjectsList);
}
}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerBulletObjects1Objects = Hashtable.newFrom({"PlayerBullet": gdjs.gameCode.GDPlayerBulletObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDSniperEnemyObjects1Objects = Hashtable.newFrom({"SniperEnemy": gdjs.gameCode.GDSniperEnemyObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDDebrisParticleObjects1Objects = Hashtable.newFrom({"DebrisParticle": gdjs.gameCode.GDDebrisParticleObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.gameCode.GDExplosionObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin4Objects1Objects = Hashtable.newFrom({"Coin4": gdjs.gameCode.GDCoin4Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin2Objects1Objects = Hashtable.newFrom({"Coin2": gdjs.gameCode.GDCoin2Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin2Objects1Objects = Hashtable.newFrom({"Coin2": gdjs.gameCode.GDCoin2Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.gameCode.GDExplosionObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDSniperEnemyObjects1Objects = Hashtable.newFrom({"SniperEnemy": gdjs.gameCode.GDSniperEnemyObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDDebrisParticleObjects1Objects = Hashtable.newFrom({"DebrisParticle": gdjs.gameCode.GDDebrisParticleObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin4Objects1Objects = Hashtable.newFrom({"Coin4": gdjs.gameCode.GDCoin4Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin2Objects1Objects = Hashtable.newFrom({"Coin2": gdjs.gameCode.GDCoin2Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin2Objects1Objects = Hashtable.newFrom({"Coin2": gdjs.gameCode.GDCoin2Objects1});
gdjs.gameCode.asyncCallback24774844 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("SniperEnemy"), gdjs.gameCode.GDSniperEnemyObjects2);

{for(var i = 0, len = gdjs.gameCode.GDSniperEnemyObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDSniperEnemyObjects2[i].clearForces();
}
}
gdjs.gameCode.localVariables.length = 0;
}
gdjs.gameCode.idToCallbackMap.set(24774844, gdjs.gameCode.asyncCallback24774844);
gdjs.gameCode.eventsList21 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameCode.localVariables);
for (const obj of gdjs.gameCode.GDSniperEnemyObjects1) asyncObjectsList.addObject("SniperEnemy", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(runtimeScene.getGame().getVariables().getFromIndex(13).getAsNumber()), (runtimeScene) => (gdjs.gameCode.asyncCallback24774844(runtimeScene, asyncObjectsList)), 24774844, asyncObjectsList);
}
}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.gameCode.GDPlayerObjects2});
gdjs.gameCode.asyncCallback24776212 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("Base"), gdjs.gameCode.GDBaseObjects2);
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.gameCode.GDPlayerObjects2);

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects2Objects, (( gdjs.gameCode.GDBaseObjects2.length === 0 ) ? 0 :gdjs.gameCode.GDBaseObjects2[0].getCenterXInScene()), (( gdjs.gameCode.GDBaseObjects2.length === 0 ) ? 0 :gdjs.gameCode.GDBaseObjects2[0].getCenterYInScene()), "");
}
gdjs.gameCode.localVariables.length = 0;
}
gdjs.gameCode.idToCallbackMap.set(24776212, gdjs.gameCode.asyncCallback24776212);
gdjs.gameCode.eventsList22 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameCode.localVariables);
for (const obj of gdjs.gameCode.GDPlayerObjects1) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.gameCode.asyncCallback24776212(runtimeScene, asyncObjectsList)), 24776212, asyncObjectsList);
}
}

}


};gdjs.gameCode.asyncCallback24780484 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameCode.localVariables);
{runtimeScene.getGame().getVariables().getFromIndex(19).setBoolean(false);
}
gdjs.gameCode.localVariables.length = 0;
}
gdjs.gameCode.idToCallbackMap.set(24780484, gdjs.gameCode.asyncCallback24780484);
gdjs.gameCode.eventsList23 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.gameCode.asyncCallback24780484(runtimeScene, asyncObjectsList)), 24780484, asyncObjectsList);
}
}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.gameCode.GDPlayerObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.gameCode.GDbulletObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.gameCode.GDPlayerObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDHealthUPObjects1Objects = Hashtable.newFrom({"HealthUP": gdjs.gameCode.GDHealthUPObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.gameCode.GDPlayerObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDArmorUPObjects1Objects = Hashtable.newFrom({"ArmorUP": gdjs.gameCode.GDArmorUPObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.gameCode.GDPlayerObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoinObjects1Objects = Hashtable.newFrom({"Coin": gdjs.gameCode.GDCoinObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.gameCode.GDPlayerObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpeople1Objects1Objects = Hashtable.newFrom({"people1": gdjs.gameCode.GDpeople1Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerBulletObjects1Objects = Hashtable.newFrom({"PlayerBullet": gdjs.gameCode.GDPlayerBulletObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet2Objects1Objects = Hashtable.newFrom({"bullet2": gdjs.gameCode.GDbullet2Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDSparksObjects1Objects = Hashtable.newFrom({"Sparks": gdjs.gameCode.GDSparksObjects1});
gdjs.gameCode.asyncCallback24791460 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Sparks"), gdjs.gameCode.GDSparksObjects2);

{for(var i = 0, len = gdjs.gameCode.GDSparksObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDSparksObjects2[i].deleteFromScene(runtimeScene);
}
}
gdjs.gameCode.localVariables.length = 0;
}
gdjs.gameCode.idToCallbackMap.set(24791460, gdjs.gameCode.asyncCallback24791460);
gdjs.gameCode.eventsList24 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameCode.localVariables);
for (const obj of gdjs.gameCode.GDSparksObjects1) asyncObjectsList.addObject("Sparks", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.gameCode.asyncCallback24791460(runtimeScene, asyncObjectsList)), 24791460, asyncObjectsList);
}
}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerBulletObjects1Objects = Hashtable.newFrom({"PlayerBullet": gdjs.gameCode.GDPlayerBulletObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet3Objects1Objects = Hashtable.newFrom({"bullet3": gdjs.gameCode.GDbullet3Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDSparksObjects1Objects = Hashtable.newFrom({"Sparks": gdjs.gameCode.GDSparksObjects1});
gdjs.gameCode.asyncCallback24793964 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Sparks"), gdjs.gameCode.GDSparksObjects2);

{for(var i = 0, len = gdjs.gameCode.GDSparksObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDSparksObjects2[i].deleteFromScene(runtimeScene);
}
}
gdjs.gameCode.localVariables.length = 0;
}
gdjs.gameCode.idToCallbackMap.set(24793964, gdjs.gameCode.asyncCallback24793964);
gdjs.gameCode.eventsList25 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameCode.localVariables);
for (const obj of gdjs.gameCode.GDSparksObjects1) asyncObjectsList.addObject("Sparks", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.gameCode.asyncCallback24793964(runtimeScene, asyncObjectsList)), 24793964, asyncObjectsList);
}
}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerBulletObjects1Objects = Hashtable.newFrom({"PlayerBullet": gdjs.gameCode.GDPlayerBulletObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet4Objects1Objects = Hashtable.newFrom({"bullet4": gdjs.gameCode.GDbullet4Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDSparksObjects1Objects = Hashtable.newFrom({"Sparks": gdjs.gameCode.GDSparksObjects1});
gdjs.gameCode.asyncCallback24794284 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Sparks"), gdjs.gameCode.GDSparksObjects2);

{for(var i = 0, len = gdjs.gameCode.GDSparksObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDSparksObjects2[i].deleteFromScene(runtimeScene);
}
}
gdjs.gameCode.localVariables.length = 0;
}
gdjs.gameCode.idToCallbackMap.set(24794284, gdjs.gameCode.asyncCallback24794284);
gdjs.gameCode.eventsList26 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameCode.localVariables);
for (const obj of gdjs.gameCode.GDSparksObjects1) asyncObjectsList.addObject("Sparks", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.gameCode.asyncCallback24794284(runtimeScene, asyncObjectsList)), 24794284, asyncObjectsList);
}
}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpeople1Objects1Objects = Hashtable.newFrom({"people1": gdjs.gameCode.GDpeople1Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpeople1Objects1Objects = Hashtable.newFrom({"people1": gdjs.gameCode.GDpeople1Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.gameCode.GDEnemyObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpeople1Objects1Objects = Hashtable.newFrom({"people1": gdjs.gameCode.GDpeople1Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDschotEnemyObjects1Objects = Hashtable.newFrom({"schotEnemy": gdjs.gameCode.GDschotEnemyObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpeople1Objects1Objects = Hashtable.newFrom({"people1": gdjs.gameCode.GDpeople1Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDSniperEnemyObjects1Objects = Hashtable.newFrom({"SniperEnemy": gdjs.gameCode.GDSniperEnemyObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpeople1Objects1Objects = Hashtable.newFrom({"people1": gdjs.gameCode.GDpeople1Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBigEnemyObjects1Objects = Hashtable.newFrom({"BigEnemy": gdjs.gameCode.GDBigEnemyObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpeople1Objects1Objects = Hashtable.newFrom({"people1": gdjs.gameCode.GDpeople1Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDsmallEnemyObjects1Objects = Hashtable.newFrom({"smallEnemy": gdjs.gameCode.GDsmallEnemyObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpeople1Objects1Objects = Hashtable.newFrom({"people1": gdjs.gameCode.GDpeople1Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet4Objects1Objects = Hashtable.newFrom({"bullet4": gdjs.gameCode.GDbullet4Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpeople1Objects1Objects = Hashtable.newFrom({"people1": gdjs.gameCode.GDpeople1Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet2Objects1Objects = Hashtable.newFrom({"bullet2": gdjs.gameCode.GDbullet2Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpeople1Objects1Objects = Hashtable.newFrom({"people1": gdjs.gameCode.GDpeople1Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet3Objects1Objects = Hashtable.newFrom({"bullet3": gdjs.gameCode.GDbullet3Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpeople1Objects1Objects = Hashtable.newFrom({"people1": gdjs.gameCode.GDpeople1Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.gameCode.GDExplosionObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBaseObjects1Objects = Hashtable.newFrom({"Base": gdjs.gameCode.GDBaseObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.gameCode.GDEnemyObjects1});
gdjs.gameCode.asyncCallback24807548 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Enemy"), gdjs.gameCode.GDEnemyObjects2);

{for(var i = 0, len = gdjs.gameCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDEnemyObjects2[i].clearForces();
}
}
gdjs.gameCode.localVariables.length = 0;
}
gdjs.gameCode.idToCallbackMap.set(24807548, gdjs.gameCode.asyncCallback24807548);
gdjs.gameCode.eventsList27 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameCode.localVariables);
for (const obj of gdjs.gameCode.GDEnemyObjects1) asyncObjectsList.addObject("Enemy", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.gameCode.asyncCallback24807548(runtimeScene, asyncObjectsList)), 24807548, asyncObjectsList);
}
}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBaseObjects1Objects = Hashtable.newFrom({"Base": gdjs.gameCode.GDBaseObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDsmallEnemyObjects1Objects = Hashtable.newFrom({"smallEnemy": gdjs.gameCode.GDsmallEnemyObjects1});
gdjs.gameCode.asyncCallback24808604 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("smallEnemy"), gdjs.gameCode.GDsmallEnemyObjects2);

{for(var i = 0, len = gdjs.gameCode.GDsmallEnemyObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDsmallEnemyObjects2[i].clearForces();
}
}
gdjs.gameCode.localVariables.length = 0;
}
gdjs.gameCode.idToCallbackMap.set(24808604, gdjs.gameCode.asyncCallback24808604);
gdjs.gameCode.eventsList28 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameCode.localVariables);
for (const obj of gdjs.gameCode.GDsmallEnemyObjects1) asyncObjectsList.addObject("smallEnemy", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.gameCode.asyncCallback24808604(runtimeScene, asyncObjectsList)), 24808604, asyncObjectsList);
}
}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBaseObjects1Objects = Hashtable.newFrom({"Base": gdjs.gameCode.GDBaseObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBigEnemyObjects1Objects = Hashtable.newFrom({"BigEnemy": gdjs.gameCode.GDBigEnemyObjects1});
gdjs.gameCode.asyncCallback24810644 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("BigEnemy"), gdjs.gameCode.GDBigEnemyObjects2);

{for(var i = 0, len = gdjs.gameCode.GDBigEnemyObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDBigEnemyObjects2[i].clearForces();
}
}
gdjs.gameCode.localVariables.length = 0;
}
gdjs.gameCode.idToCallbackMap.set(24810644, gdjs.gameCode.asyncCallback24810644);
gdjs.gameCode.eventsList29 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameCode.localVariables);
for (const obj of gdjs.gameCode.GDBigEnemyObjects1) asyncObjectsList.addObject("BigEnemy", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.gameCode.asyncCallback24810644(runtimeScene, asyncObjectsList)), 24810644, asyncObjectsList);
}
}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBaseObjects1Objects = Hashtable.newFrom({"Base": gdjs.gameCode.GDBaseObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDSniperEnemyObjects1Objects = Hashtable.newFrom({"SniperEnemy": gdjs.gameCode.GDSniperEnemyObjects1});
gdjs.gameCode.asyncCallback24812180 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("SniperEnemy"), gdjs.gameCode.GDSniperEnemyObjects2);

{for(var i = 0, len = gdjs.gameCode.GDSniperEnemyObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDSniperEnemyObjects2[i].clearForces();
}
}
gdjs.gameCode.localVariables.length = 0;
}
gdjs.gameCode.idToCallbackMap.set(24812180, gdjs.gameCode.asyncCallback24812180);
gdjs.gameCode.eventsList30 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameCode.localVariables);
for (const obj of gdjs.gameCode.GDSniperEnemyObjects1) asyncObjectsList.addObject("SniperEnemy", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.gameCode.asyncCallback24812180(runtimeScene, asyncObjectsList)), 24812180, asyncObjectsList);
}
}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBaseObjects1Objects = Hashtable.newFrom({"Base": gdjs.gameCode.GDBaseObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDschotEnemyObjects1Objects = Hashtable.newFrom({"schotEnemy": gdjs.gameCode.GDschotEnemyObjects1});
gdjs.gameCode.asyncCallback24813820 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("schotEnemy"), gdjs.gameCode.GDschotEnemyObjects2);

{for(var i = 0, len = gdjs.gameCode.GDschotEnemyObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDschotEnemyObjects2[i].clearForces();
}
}
gdjs.gameCode.localVariables.length = 0;
}
gdjs.gameCode.idToCallbackMap.set(24813820, gdjs.gameCode.asyncCallback24813820);
gdjs.gameCode.eventsList31 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameCode.localVariables);
for (const obj of gdjs.gameCode.GDschotEnemyObjects1) asyncObjectsList.addObject("schotEnemy", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.gameCode.asyncCallback24813820(runtimeScene, asyncObjectsList)), 24813820, asyncObjectsList);
}
}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBaseObjects1Objects = Hashtable.newFrom({"Base": gdjs.gameCode.GDBaseObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet2Objects1Objects = Hashtable.newFrom({"bullet2": gdjs.gameCode.GDbullet2Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBaseObjects1Objects = Hashtable.newFrom({"Base": gdjs.gameCode.GDBaseObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet3Objects1Objects = Hashtable.newFrom({"bullet3": gdjs.gameCode.GDbullet3Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBaseObjects1Objects = Hashtable.newFrom({"Base": gdjs.gameCode.GDBaseObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet4Objects1Objects = Hashtable.newFrom({"bullet4": gdjs.gameCode.GDbullet4Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.gameCode.GDPlayerObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin2Objects1Objects = Hashtable.newFrom({"Coin2": gdjs.gameCode.GDCoin2Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.gameCode.GDPlayerObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin3Objects1Objects = Hashtable.newFrom({"Coin3": gdjs.gameCode.GDCoin3Objects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.gameCode.GDPlayerObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin4Objects1Objects = Hashtable.newFrom({"Coin4": gdjs.gameCode.GDCoin4Objects1});
gdjs.gameCode.eventsList32 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("brand"), gdjs.gameCode.GDbrandObjects1);
gdjs.copyArray(runtimeScene.getObjects("pijl"), gdjs.gameCode.GDpijlObjects1);
gdjs.copyArray(runtimeScene.getObjects("pijl2"), gdjs.gameCode.GDpijl2Objects1);
gdjs.copyArray(runtimeScene.getObjects("pijl3"), gdjs.gameCode.GDpijl3Objects1);
gdjs.gameCode.GDBaseObjects1.length = 0;

{gdjs.saveState.restoreGameSaveStateFromStorage(runtimeScene, "Space Game Save", "default", false);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "EnemySpawn");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "EnemySpawn2");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "EnemySpawn3");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "EnemySpawn4");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "EnemySpawn5");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "dropSpawn");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "dropSpawn2");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "dropSpawn3");
}
{runtimeScene.getGame().getVariables().getFromIndex(7).getChild("sound").setNumber(50);
}
{runtimeScene.getGame().getVariables().getFromIndex(7).getChild("music").setNumber(50);
}
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "Gamesong.mp3", 1, true, runtimeScene.getGame().getVariables().getFromIndex(7).getChild("music").getAsNumber(), 1);
}
{for(var i = 0, len = gdjs.gameCode.GDpijlObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDpijlObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.gameCode.GDpijl2Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDpijl2Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.gameCode.GDpijl3Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDpijl3Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.gameCode.GDbrandObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDbrandObjects1[i].hide();
}
}
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2));
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBaseObjects1Objects, (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointX("")) + (gdjs.randomWithStep(-1, 1, 2) * gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2), (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointY("")) + (gdjs.randomWithStep(-1, 1, 2) * gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2), "");
}
{for(var i = 0, len = gdjs.gameCode.GDBaseObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDBaseObjects1[i].setZOrder(0);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("pijl"), gdjs.gameCode.GDpijlObjects1);
gdjs.copyArray(runtimeScene.getObjects("pijl2"), gdjs.gameCode.GDpijl2Objects1);
gdjs.copyArray(runtimeScene.getObjects("pijl3"), gdjs.gameCode.GDpijl3Objects1);
{for(var i = 0, len = gdjs.gameCode.GDpijlObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDpijlObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.gameCode.GDpijl3Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDpijl3Objects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.gameCode.GDpijl2Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDpijl2Objects1[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getGame().getVariables().getFromIndex(3).sub(1);
}

{ //Subevents
gdjs.gameCode.eventsList7(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AimJoystick"), gdjs.gameCode.GDAimJoystickObjects1);
gdjs.copyArray(runtimeScene.getObjects("MoveJoystick"), gdjs.gameCode.GDMoveJoystickObjects1);
{for(var i = 0, len = gdjs.gameCode.GDAimJoystickObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDAimJoystickObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.gameCode.GDMoveJoystickObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDMoveJoystickObjects1[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("RepeatingBackground"), gdjs.gameCode.GDRepeatingBackgroundObjects1);
{for(var i = 0, len = gdjs.gameCode.GDRepeatingBackgroundObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDRepeatingBackgroundObjects1[i].setYOffset(gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0));
}
}
{for(var i = 0, len = gdjs.gameCode.GDRepeatingBackgroundObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDRepeatingBackgroundObjects1[i].setXOffset(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0));
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "EnemySpawn") >= 3;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
gdjs.gameCode.GDEnemyObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDEnemyObjects1Objects, (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointX("")) + (gdjs.randomWithStep(-1, 1, 2) * gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 * 3), (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointY("")) + (gdjs.randomWithStep(-1, 1, 2) * gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2 * 3), "");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "EnemySpawn");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "EnemySpawn2") >= 8 + runtimeScene.getGame().getVariables().getFromIndex(10).getAsNumber() / 1000;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
gdjs.gameCode.GDsmallEnemyObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDsmallEnemyObjects1Objects, (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointX("")) + (gdjs.randomWithStep(-1, 1, 2) * gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 3), (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointY("")) + (gdjs.randomWithStep(-1, 1, 2) * gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 3), "");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "EnemySpawn2");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "EnemySpawn3") >= 20 + runtimeScene.getGame().getVariables().getFromIndex(10).getAsNumber() / 1000;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
gdjs.gameCode.GDBigEnemyObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBigEnemyObjects1Objects, (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointX("")) + (gdjs.randomWithStep(-1, 1, 2) * gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 * 3), (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointY("")) + (gdjs.randomWithStep(-1, 1, 2) * gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2 * 3), "");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "EnemySpawn3");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "EnemySpawn4") >= 10 + runtimeScene.getGame().getVariables().getFromIndex(10).getAsNumber() / 1000;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
gdjs.gameCode.GDSniperEnemyObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDSniperEnemyObjects1Objects, (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointX("")) + (gdjs.randomWithStep(-1, 1, 2) * gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 * 3), (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointY("")) + (gdjs.randomWithStep(-1, 1, 2) * gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2 * 3), "");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "EnemySpawn4");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "EnemySpawn5") >= 15 + runtimeScene.getGame().getVariables().getFromIndex(10).getAsNumber() / 1000;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
gdjs.gameCode.GDschotEnemyObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDschotEnemyObjects1Objects, (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointX("")) + (gdjs.randomWithStep(-1, 1, 2) * gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 * 3), (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointY("")) + (gdjs.randomWithStep(-1, 1, 2) * gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2 * 3), "");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "EnemySpawn5");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "dropSpawn") >= 10;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
gdjs.gameCode.GDbulletObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbulletObjects1Objects, (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointX("")) + (gdjs.randomWithStep(-1, 1, 2) * gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2), (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointY("")) + (gdjs.randomWithStep(-1, 1, 2) * gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2), "");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "dropSpawn");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "dropSpawn2") >= 30;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
gdjs.gameCode.GDHealthUPObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDHealthUPObjects1Objects, (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointX("")) + (gdjs.randomWithStep(-1, 1, 2) * gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2), (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointY("")) + (gdjs.randomWithStep(-1, 1, 2) * gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2), "");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "dropSpawn2");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "dropSpawn3") >= 20;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
gdjs.gameCode.GDCoinObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoinObjects1Objects, (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointX("")) + (gdjs.randomWithStep(-1, 1, 2) * gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2), (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointY("")) + (gdjs.randomWithStep(-1, 1, 2) * gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2), "");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "dropSpawn3");
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Base"), gdjs.gameCode.GDBaseObjects1);
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.gameCode.GDEnemyObjects1);
{for(var i = 0, len = gdjs.gameCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDEnemyObjects1[i].addForceTowardObject((gdjs.gameCode.GDBaseObjects1.length !== 0 ? gdjs.gameCode.GDBaseObjects1[0] : null), 100, 0);
}
}
{for(var i = 0, len = gdjs.gameCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDEnemyObjects1[i].rotateTowardPosition((( gdjs.gameCode.GDBaseObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDBaseObjects1[0].getCenterXInScene()), (( gdjs.gameCode.GDBaseObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDBaseObjects1[0].getCenterYInScene()), 0, runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Base"), gdjs.gameCode.GDBaseObjects1);
gdjs.copyArray(runtimeScene.getObjects("smallEnemy"), gdjs.gameCode.GDsmallEnemyObjects1);
{for(var i = 0, len = gdjs.gameCode.GDsmallEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDsmallEnemyObjects1[i].addForceTowardObject((gdjs.gameCode.GDBaseObjects1.length !== 0 ? gdjs.gameCode.GDBaseObjects1[0] : null), 200, 0);
}
}
{for(var i = 0, len = gdjs.gameCode.GDsmallEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDsmallEnemyObjects1[i].rotateTowardPosition((( gdjs.gameCode.GDBaseObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDBaseObjects1[0].getCenterXInScene()), (( gdjs.gameCode.GDBaseObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDBaseObjects1[0].getCenterYInScene()), 0, runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Base"), gdjs.gameCode.GDBaseObjects1);
gdjs.copyArray(runtimeScene.getObjects("BigEnemy"), gdjs.gameCode.GDBigEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
gdjs.gameCode.GDbullet2Objects1.length = 0;

{for(var i = 0, len = gdjs.gameCode.GDBigEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDBigEnemyObjects1[i].addForceTowardObject((gdjs.gameCode.GDBaseObjects1.length !== 0 ? gdjs.gameCode.GDBaseObjects1[0] : null), 60, 0);
}
}
{for(var i = 0, len = gdjs.gameCode.GDBigEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDBigEnemyObjects1[i].rotateTowardPosition((( gdjs.gameCode.GDBaseObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDBaseObjects1[0].getCenterXInScene()), (( gdjs.gameCode.GDBaseObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDBaseObjects1[0].getCenterYInScene()), 0, runtimeScene);
}
}
{for(var i = 0, len = gdjs.gameCode.GDBigEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDBigEnemyObjects1[i].getBehavior("FireBullet").FireTowardObject((gdjs.gameCode.GDBigEnemyObjects1[i].getPointX("Gun")), (gdjs.gameCode.GDBigEnemyObjects1[i].getPointY("Gun")), gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet2Objects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects, 400, null);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Base"), gdjs.gameCode.GDBaseObjects1);
gdjs.copyArray(runtimeScene.getObjects("SniperEnemy"), gdjs.gameCode.GDSniperEnemyObjects1);
{for(var i = 0, len = gdjs.gameCode.GDSniperEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDSniperEnemyObjects1[i].addForceTowardObject((gdjs.gameCode.GDBaseObjects1.length !== 0 ? gdjs.gameCode.GDBaseObjects1[0] : null), 100, 0);
}
}
{for(var i = 0, len = gdjs.gameCode.GDSniperEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDSniperEnemyObjects1[i].rotateTowardPosition((( gdjs.gameCode.GDBaseObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDBaseObjects1[0].getCenterXInScene()), (( gdjs.gameCode.GDBaseObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDBaseObjects1[0].getCenterYInScene()), 0, runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Base"), gdjs.gameCode.GDBaseObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("schotEnemy"), gdjs.gameCode.GDschotEnemyObjects1);
gdjs.gameCode.GDbullet4Objects1.length = 0;

{for(var i = 0, len = gdjs.gameCode.GDschotEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDschotEnemyObjects1[i].addForceTowardObject((gdjs.gameCode.GDBaseObjects1.length !== 0 ? gdjs.gameCode.GDBaseObjects1[0] : null), 100, 0);
}
}
{for(var i = 0, len = gdjs.gameCode.GDschotEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDschotEnemyObjects1[i].rotateTowardPosition((( gdjs.gameCode.GDBaseObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDBaseObjects1[0].getCenterXInScene()), (( gdjs.gameCode.GDBaseObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDBaseObjects1[0].getCenterYInScene()), 0, runtimeScene);
}
}
{for(var i = 0, len = gdjs.gameCode.GDschotEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDschotEnemyObjects1[i].getBehavior("FireBullet").FireTowardObject((gdjs.gameCode.GDschotEnemyObjects1[i].getPointX("")), (gdjs.gameCode.GDschotEnemyObjects1[i].getPointY("")), gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet4Objects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects, 400, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("people1"), gdjs.gameCode.GDpeople1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpeople1Objects1Objects, 300, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDPlayerObjects1 */
/* Reuse gdjs.gameCode.GDpeople1Objects1 */
{for(var i = 0, len = gdjs.gameCode.GDpeople1Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDpeople1Objects1[i].addForceTowardObject((gdjs.gameCode.GDPlayerObjects1.length !== 0 ? gdjs.gameCode.GDPlayerObjects1[0] : null), 100, 0);
}
}
{for(var i = 0, len = gdjs.gameCode.GDpeople1Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDpeople1Objects1[i].getBehavior("Animation").setAnimationName("Walk Down");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coin4"), gdjs.gameCode.GDCoin4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin4Objects1Objects, 400, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDCoin4Objects1 */
/* Reuse gdjs.gameCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.gameCode.GDCoin4Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDCoin4Objects1[i].addForceTowardObject((gdjs.gameCode.GDPlayerObjects1.length !== 0 ? gdjs.gameCode.GDPlayerObjects1[0] : null), 400, 0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coin2"), gdjs.gameCode.GDCoin2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin2Objects1Objects, 400, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDCoin2Objects1 */
/* Reuse gdjs.gameCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.gameCode.GDCoin2Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDCoin2Objects1[i].addForceTowardObject((gdjs.gameCode.GDPlayerObjects1.length !== 0 ? gdjs.gameCode.GDPlayerObjects1[0] : null), 400, 0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coin3"), gdjs.gameCode.GDCoin3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin3Objects1Objects, 400, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDCoin3Objects1 */
/* Reuse gdjs.gameCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.gameCode.GDCoin3Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDCoin3Objects1[i].addForceTowardObject((gdjs.gameCode.GDPlayerObjects1.length !== 0 ? gdjs.gameCode.GDPlayerObjects1[0] : null), 400, 0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("AimJoystick"), gdjs.gameCode.GDAimJoystickObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.gameCode.GDAimJoystickObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDAimJoystickObjects1[i].IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.gameCode.GDAimJoystickObjects1[k] = gdjs.gameCode.GDAimJoystickObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDAimJoystickObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].rotateTowardAngle(gdjs.evtsExt__SpriteMultitouchJoystick__StickAngle.func(runtimeScene, 2, "Secondary", null), 0, runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(2).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("knop"), gdjs.gameCode.GDknopObjects1);
gdjs.gameCode.GDPlayerBulletObjects1.length = 0;

{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("FireBullet").Fire((gdjs.gameCode.GDPlayerObjects1[i].getPointX("gun")), (gdjs.gameCode.GDPlayerObjects1[i].getPointY("gun")), gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerBulletObjects1Objects, (gdjs.gameCode.GDPlayerObjects1[i].getAngle()), 400, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDknopObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDknopObjects1[i].getBehavior("Animation").setAnimationName("ingedrukt");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(2).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("knop"), gdjs.gameCode.GDknopObjects1);
{for(var i = 0, len = gdjs.gameCode.GDknopObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDknopObjects1[i].getBehavior("Animation").setAnimationName("niet ingedrukt");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("knop"), gdjs.gameCode.GDknopObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.gameCode.GDknopObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDknopObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.gameCode.GDknopObjects1[k] = gdjs.gameCode.GDknopObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDknopObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2));
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Button_pressed.func(runtimeScene, 1, "LT", null);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
gdjs.gameCode.GDPlayerBulletObjects1.length = 0;

{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].rotateTowardAngle(gdjs.evtsExt__Gamepads__StickAngle.func(runtimeScene, 1, "Right", null), 0, runtimeScene);
}
}
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("FireBullet").Fire((gdjs.gameCode.GDPlayerObjects1[i].getPointX("gun")), (gdjs.gameCode.GDPlayerObjects1[i].getPointY("gun")), gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerBulletObjects1Objects, (gdjs.gameCode.GDPlayerObjects1[i].getAngle()), 400, null);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Axis_pushed.func(runtimeScene, 1, "Left", "Up", null);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").simulateUpKey();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Axis_pushed.func(runtimeScene, 1, "Left", "Down", null);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").simulateDownKey();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Axis_pushed.func(runtimeScene, 1, "Left", "Left", null);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").simulateLeftKey();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Axis_pushed.func(runtimeScene, 1, "Left", "Right", null);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").simulateRightKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("AimJoystick"), gdjs.gameCode.GDAimJoystickObjects1);
gdjs.copyArray(runtimeScene.getObjects("MoveJoystick"), gdjs.gameCode.GDMoveJoystickObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.gameCode.GDMoveJoystickObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDMoveJoystickObjects1[i].IsPressed(null) ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDMoveJoystickObjects1[k] = gdjs.gameCode.GDMoveJoystickObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDMoveJoystickObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.gameCode.GDAimJoystickObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDAimJoystickObjects1[i].IsPressed(null) ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDAimJoystickObjects1[k] = gdjs.gameCode.GDAimJoystickObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDAimJoystickObjects1.length = k;
isConditionTrue_0 = !isConditionTrue_1;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
gdjs.gameCode.GDPlayerBulletObjects1.length = 0;

{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].rotateTowardPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), 0, runtimeScene);
}
}
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("FireBullet").Fire((gdjs.gameCode.GDPlayerObjects1[i].getPointX("gun")), (gdjs.gameCode.GDPlayerObjects1[i].getPointY("gun")), gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerBulletObjects1Objects, (gdjs.gameCode.GDPlayerObjects1[i].getAngle()), 400, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("AimJoystick"), gdjs.gameCode.GDAimJoystickObjects1);
gdjs.copyArray(runtimeScene.getObjects("MoveJoystick"), gdjs.gameCode.GDMoveJoystickObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.gameCode.GDMoveJoystickObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDMoveJoystickObjects1[i].IsPressed(null) ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDMoveJoystickObjects1[k] = gdjs.gameCode.GDMoveJoystickObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDMoveJoystickObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.gameCode.GDAimJoystickObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDAimJoystickObjects1[i].IsPressed(null) ) {
        isConditionTrue_1 = true;
        gdjs.gameCode.GDAimJoystickObjects1[k] = gdjs.gameCode.GDAimJoystickObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDAimJoystickObjects1.length = k;
isConditionTrue_0 = !isConditionTrue_1;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].rotateTowardPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), 0, runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").simulateRightKey();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").simulateLeftKey();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").simulateDownKey();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").simulateUpKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.gameCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDPlayerObjects1[i].getBehavior("FireBullet").HasJustFired(null) ) {
        isConditionTrue_0 = true;
        gdjs.gameCode.GDPlayerObjects1[k] = gdjs.gameCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/starting_bulletfire.wav", false, runtimeScene.getGame().getVariables().getFromIndex(7).getChild("sound").getAsNumber(), gdjs.randomWithStep(0.9, 1.2, 0.05));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.gameCode.GDEnemyObjects1);

for (gdjs.gameCode.forEachIndex2 = 0;gdjs.gameCode.forEachIndex2 < gdjs.gameCode.GDEnemyObjects1.length;++gdjs.gameCode.forEachIndex2) {
gdjs.gameCode.GDLargeDebrisParticleObjects2.length = 0;

gdjs.gameCode.GDEnemyObjects2.length = 0;


gdjs.gameCode.forEachTemporary2 = gdjs.gameCode.GDEnemyObjects1[gdjs.gameCode.forEachIndex2];
gdjs.gameCode.GDEnemyObjects2.push(gdjs.gameCode.forEachTemporary2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.gameCode.GDEnemyObjects2.length;i<l;++i) {
    if ( gdjs.gameCode.GDEnemyObjects2[i].getVariableNumber(gdjs.gameCode.GDEnemyObjects2[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.gameCode.GDEnemyObjects2[k] = gdjs.gameCode.GDEnemyObjects2[i];
        ++k;
    }
}
gdjs.gameCode.GDEnemyObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDLargeDebrisParticleObjects2Objects, (( gdjs.gameCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects2[0].getCenterXInScene()), (( gdjs.gameCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects2[0].getCenterYInScene()), "");
}
{for(var i = 0, len = gdjs.gameCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDEnemyObjects2[i].returnVariable(gdjs.gameCode.GDEnemyObjects2[i].getVariables().getFromIndex(1)).setNumber(gdjs.randomInRange(0, 10));
}
}

{ //Subevents: 
gdjs.gameCode.eventsList8(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("schotEnemy"), gdjs.gameCode.GDschotEnemyObjects1);

for (gdjs.gameCode.forEachIndex2 = 0;gdjs.gameCode.forEachIndex2 < gdjs.gameCode.GDschotEnemyObjects1.length;++gdjs.gameCode.forEachIndex2) {
gdjs.gameCode.GDLargeDebrisParticleObjects2.length = 0;

gdjs.gameCode.GDschotEnemyObjects2.length = 0;


gdjs.gameCode.forEachTemporary2 = gdjs.gameCode.GDschotEnemyObjects1[gdjs.gameCode.forEachIndex2];
gdjs.gameCode.GDschotEnemyObjects2.push(gdjs.gameCode.forEachTemporary2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.gameCode.GDschotEnemyObjects2.length;i<l;++i) {
    if ( gdjs.gameCode.GDschotEnemyObjects2[i].getVariableNumber(gdjs.gameCode.GDschotEnemyObjects2[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.gameCode.GDschotEnemyObjects2[k] = gdjs.gameCode.GDschotEnemyObjects2[i];
        ++k;
    }
}
gdjs.gameCode.GDschotEnemyObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDLargeDebrisParticleObjects2Objects, (( gdjs.gameCode.GDschotEnemyObjects2.length === 0 ) ? 0 :gdjs.gameCode.GDschotEnemyObjects2[0].getCenterXInScene()), (( gdjs.gameCode.GDschotEnemyObjects2.length === 0 ) ? 0 :gdjs.gameCode.GDschotEnemyObjects2[0].getCenterYInScene()), "");
}
{for(var i = 0, len = gdjs.gameCode.GDschotEnemyObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDschotEnemyObjects2[i].returnVariable(gdjs.gameCode.GDschotEnemyObjects2[i].getVariables().getFromIndex(1)).setNumber(gdjs.randomInRange(0, 10));
}
}

{ //Subevents: 
gdjs.gameCode.eventsList9(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("smallEnemy"), gdjs.gameCode.GDsmallEnemyObjects1);

for (gdjs.gameCode.forEachIndex2 = 0;gdjs.gameCode.forEachIndex2 < gdjs.gameCode.GDsmallEnemyObjects1.length;++gdjs.gameCode.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.gameCode.GDEnemyObjects2);
gdjs.gameCode.GDLargeDebrisParticleObjects2.length = 0;

gdjs.gameCode.GDsmallEnemyObjects2.length = 0;


gdjs.gameCode.forEachTemporary2 = gdjs.gameCode.GDsmallEnemyObjects1[gdjs.gameCode.forEachIndex2];
gdjs.gameCode.GDsmallEnemyObjects2.push(gdjs.gameCode.forEachTemporary2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.gameCode.GDsmallEnemyObjects2.length;i<l;++i) {
    if ( gdjs.gameCode.GDsmallEnemyObjects2[i].getVariableNumber(gdjs.gameCode.GDsmallEnemyObjects2[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.gameCode.GDsmallEnemyObjects2[k] = gdjs.gameCode.GDsmallEnemyObjects2[i];
        ++k;
    }
}
gdjs.gameCode.GDsmallEnemyObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDLargeDebrisParticleObjects2Objects, (( gdjs.gameCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects2[0].getCenterXInScene()), (( gdjs.gameCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects2[0].getCenterYInScene()), "");
}
{for(var i = 0, len = gdjs.gameCode.GDsmallEnemyObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDsmallEnemyObjects2[i].returnVariable(gdjs.gameCode.GDsmallEnemyObjects2[i].getVariables().getFromIndex(1)).setNumber(gdjs.randomInRange(0, 10));
}
}

{ //Subevents: 
gdjs.gameCode.eventsList10(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("BigEnemy"), gdjs.gameCode.GDBigEnemyObjects1);

for (gdjs.gameCode.forEachIndex2 = 0;gdjs.gameCode.forEachIndex2 < gdjs.gameCode.GDBigEnemyObjects1.length;++gdjs.gameCode.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.gameCode.GDEnemyObjects2);
gdjs.gameCode.GDLargeDebrisParticleObjects2.length = 0;

gdjs.gameCode.GDBigEnemyObjects2.length = 0;


gdjs.gameCode.forEachTemporary2 = gdjs.gameCode.GDBigEnemyObjects1[gdjs.gameCode.forEachIndex2];
gdjs.gameCode.GDBigEnemyObjects2.push(gdjs.gameCode.forEachTemporary2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.gameCode.GDBigEnemyObjects2.length;i<l;++i) {
    if ( gdjs.gameCode.GDBigEnemyObjects2[i].getVariableNumber(gdjs.gameCode.GDBigEnemyObjects2[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.gameCode.GDBigEnemyObjects2[k] = gdjs.gameCode.GDBigEnemyObjects2[i];
        ++k;
    }
}
gdjs.gameCode.GDBigEnemyObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDLargeDebrisParticleObjects2Objects, (( gdjs.gameCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects2[0].getCenterXInScene()), (( gdjs.gameCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects2[0].getCenterYInScene()), "");
}
{for(var i = 0, len = gdjs.gameCode.GDBigEnemyObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDBigEnemyObjects2[i].returnVariable(gdjs.gameCode.GDBigEnemyObjects2[i].getVariables().getFromIndex(1)).setNumber(gdjs.randomInRange(0, 10));
}
}

{ //Subevents: 
gdjs.gameCode.eventsList11(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("SniperEnemy"), gdjs.gameCode.GDSniperEnemyObjects1);

for (gdjs.gameCode.forEachIndex2 = 0;gdjs.gameCode.forEachIndex2 < gdjs.gameCode.GDSniperEnemyObjects1.length;++gdjs.gameCode.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.gameCode.GDEnemyObjects2);
gdjs.gameCode.GDLargeDebrisParticleObjects2.length = 0;

gdjs.gameCode.GDSniperEnemyObjects2.length = 0;


gdjs.gameCode.forEachTemporary2 = gdjs.gameCode.GDSniperEnemyObjects1[gdjs.gameCode.forEachIndex2];
gdjs.gameCode.GDSniperEnemyObjects2.push(gdjs.gameCode.forEachTemporary2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.gameCode.GDSniperEnemyObjects2.length;i<l;++i) {
    if ( gdjs.gameCode.GDSniperEnemyObjects2[i].getVariableNumber(gdjs.gameCode.GDSniperEnemyObjects2[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.gameCode.GDSniperEnemyObjects2[k] = gdjs.gameCode.GDSniperEnemyObjects2[i];
        ++k;
    }
}
gdjs.gameCode.GDSniperEnemyObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDLargeDebrisParticleObjects2Objects, (( gdjs.gameCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects2[0].getCenterXInScene()), (( gdjs.gameCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects2[0].getCenterYInScene()), "");
}
{for(var i = 0, len = gdjs.gameCode.GDSniperEnemyObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDSniperEnemyObjects2[i].returnVariable(gdjs.gameCode.GDSniperEnemyObjects2[i].getVariables().getFromIndex(1)).setNumber(gdjs.randomInRange(0, 10));
}
}

{ //Subevents: 
gdjs.gameCode.eventsList12(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.gameCode.GDBigEnemyObjects1.length = 0;

gdjs.gameCode.GDEnemyObjects1.length = 0;

gdjs.gameCode.GDPlayerObjects1.length = 0;

gdjs.gameCode.GDsmallEnemyObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.gameCode.GDBigEnemyObjects1_1final.length = 0;
gdjs.gameCode.GDEnemyObjects1_1final.length = 0;
gdjs.gameCode.GDPlayerObjects1_1final.length = 0;
gdjs.gameCode.GDsmallEnemyObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.gameCode.GDEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects2Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDEnemyObjects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDEnemyObjects2.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDEnemyObjects1_1final.indexOf(gdjs.gameCode.GDEnemyObjects2[j]) === -1 )
            gdjs.gameCode.GDEnemyObjects1_1final.push(gdjs.gameCode.GDEnemyObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.gameCode.GDPlayerObjects2.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDPlayerObjects1_1final.indexOf(gdjs.gameCode.GDPlayerObjects2[j]) === -1 )
            gdjs.gameCode.GDPlayerObjects1_1final.push(gdjs.gameCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("smallEnemy"), gdjs.gameCode.GDsmallEnemyObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects2Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDsmallEnemyObjects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDPlayerObjects2.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDPlayerObjects1_1final.indexOf(gdjs.gameCode.GDPlayerObjects2[j]) === -1 )
            gdjs.gameCode.GDPlayerObjects1_1final.push(gdjs.gameCode.GDPlayerObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.gameCode.GDsmallEnemyObjects2.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDsmallEnemyObjects1_1final.indexOf(gdjs.gameCode.GDsmallEnemyObjects2[j]) === -1 )
            gdjs.gameCode.GDsmallEnemyObjects1_1final.push(gdjs.gameCode.GDsmallEnemyObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("BigEnemy"), gdjs.gameCode.GDBigEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects2Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBigEnemyObjects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameCode.GDBigEnemyObjects2.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDBigEnemyObjects1_1final.indexOf(gdjs.gameCode.GDBigEnemyObjects2[j]) === -1 )
            gdjs.gameCode.GDBigEnemyObjects1_1final.push(gdjs.gameCode.GDBigEnemyObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.gameCode.GDPlayerObjects2.length; j < jLen ; ++j) {
        if ( gdjs.gameCode.GDPlayerObjects1_1final.indexOf(gdjs.gameCode.GDPlayerObjects2[j]) === -1 )
            gdjs.gameCode.GDPlayerObjects1_1final.push(gdjs.gameCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameCode.GDBigEnemyObjects1_1final, gdjs.gameCode.GDBigEnemyObjects1);
gdjs.copyArray(gdjs.gameCode.GDEnemyObjects1_1final, gdjs.gameCode.GDEnemyObjects1);
gdjs.copyArray(gdjs.gameCode.GDPlayerObjects1_1final, gdjs.gameCode.GDPlayerObjects1);
gdjs.copyArray(gdjs.gameCode.GDsmallEnemyObjects1_1final, gdjs.gameCode.GDsmallEnemyObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24734796);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDPlayerObjects1 */
gdjs.gameCode.GDLargeDebrisParticleObjects1.length = 0;

{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.2, gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), 0.05, false, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("Health").Hit(3, true, true, null);
}
}
{gdjs.deviceVibration.startVibration(0.8);
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDLargeDebrisParticleObjects1Objects, (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getCenterXInScene()), (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getCenterYInScene()), "");
}
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/Collision.wav", false, runtimeScene.getGame().getVariables().getFromIndex(7).getChild("sound").getAsNumber(), gdjs.randomFloatInRange(0.7, 0.9));
}
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0.15);
}

{ //Subevents
gdjs.gameCode.eventsList13(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("bullet3"), gdjs.gameCode.GDbullet3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet3Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24737116);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDPlayerObjects1 */
gdjs.gameCode.GDLargeDebrisParticleObjects1.length = 0;

{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.2, gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), 0.05, false, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("Health").Hit(2, true, true, null);
}
}
{gdjs.deviceVibration.startVibration(0.8);
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDLargeDebrisParticleObjects1Objects, (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getCenterXInScene()), (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getCenterYInScene()), "");
}
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/Collision.wav", false, runtimeScene.getGame().getVariables().getFromIndex(7).getChild("sound").getAsNumber(), gdjs.randomFloatInRange(0.7, 0.9));
}
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0.15);
}

{ //Subevents
gdjs.gameCode.eventsList14(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("bullet2"), gdjs.gameCode.GDbullet2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24740020);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDPlayerObjects1 */
gdjs.gameCode.GDLargeDebrisParticleObjects1.length = 0;

{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.2, gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), 0.05, false, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("Health").Hit(1.5, true, true, null);
}
}
{gdjs.deviceVibration.startVibration(0.8);
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDLargeDebrisParticleObjects1Objects, (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getCenterXInScene()), (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getCenterYInScene()), "");
}
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/Collision.wav", false, runtimeScene.getGame().getVariables().getFromIndex(7).getChild("sound").getAsNumber(), gdjs.randomFloatInRange(0.7, 0.9));
}
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0.15);
}

{ //Subevents
gdjs.gameCode.eventsList15(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("bullet4"), gdjs.gameCode.GDbullet4Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet4Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24742404);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDPlayerObjects1 */
gdjs.gameCode.GDLargeDebrisParticleObjects1.length = 0;

{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.2, gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), 0.05, false, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("Health").Hit(1.5, true, true, null);
}
}
{gdjs.deviceVibration.startVibration(0.8);
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDLargeDebrisParticleObjects1Objects, (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getCenterXInScene()), (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getCenterYInScene()), "");
}
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/Collision.wav", false, runtimeScene.getGame().getVariables().getFromIndex(7).getChild("sound").getAsNumber(), gdjs.randomFloatInRange(0.7, 0.9));
}
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0.15);
}

{ //Subevents
gdjs.gameCode.eventsList16(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.gameCode.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerBullet"), gdjs.gameCode.GDPlayerBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerBulletObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDEnemyObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDEnemyObjects1 */
/* Reuse gdjs.gameCode.GDPlayerBulletObjects1 */
gdjs.gameCode.GDCoin2Objects1.length = 0;

gdjs.gameCode.GDDebrisParticleObjects1.length = 0;

gdjs.gameCode.GDExplosionObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDDebrisParticleObjects1Objects, (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterXInScene()), (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterYInScene()), "");
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDExplosionObjects1Objects, (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterXInScene()), (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterYInScene()), "");
}
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/Collision.wav", false, runtimeScene.getGame().getVariables().getFromIndex(7).getChild("sound").getAsNumber(), gdjs.randomWithStep(0.9, 1.1, 0.05));
}
{for(var i = 0, len = gdjs.gameCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDEnemyObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.2, gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), 0.05, false, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDEnemyObjects1[i].returnVariable(gdjs.gameCode.GDEnemyObjects1[i].getVariables().getFromIndex(0)).sub(runtimeScene.getGame().getVariables().getFromIndex(9).getAsNumber());
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin2Objects1Objects, (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointX("")), (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointY("")), "");
}
{runtimeScene.getGame().getVariables().getFromIndex(10).sub(1);
}
{for(var i = 0, len = gdjs.gameCode.GDPlayerBulletObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerBulletObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.gameCode.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Explosion"), gdjs.gameCode.GDExplosionObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDExplosionObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDEnemyObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(8).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24748412);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDEnemyObjects1 */
gdjs.copyArray(runtimeScene.getObjects("PlayerBullet"), gdjs.gameCode.GDPlayerBulletObjects1);
gdjs.gameCode.GDCoin2Objects1.length = 0;

gdjs.gameCode.GDDebrisParticleObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDDebrisParticleObjects1Objects, (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterXInScene()), (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterYInScene()), "");
}
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/Collision.wav", false, runtimeScene.getGame().getVariables().getFromIndex(7).getChild("sound").getAsNumber(), gdjs.randomWithStep(0.9, 1.1, 0.05));
}
{for(var i = 0, len = gdjs.gameCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDEnemyObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.2, gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), 0.05, false, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDEnemyObjects1[i].returnVariable(gdjs.gameCode.GDEnemyObjects1[i].getVariables().getFromIndex(0)).sub(runtimeScene.getGame().getVariables().getFromIndex(13).getAsNumber());
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin2Objects1Objects, (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointX("")), (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointY("")), "");
}
{runtimeScene.getGame().getVariables().getFromIndex(10).sub(1);
}
{for(var i = 0, len = gdjs.gameCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDEnemyObjects1[i].addForce((gdjs.gameCode.GDEnemyObjects1[i].getAngle()), (gdjs.gameCode.GDEnemyObjects1[i].getAngle()), 1);
}
}

{ //Subevents
gdjs.gameCode.eventsList17(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerBullet"), gdjs.gameCode.GDPlayerBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("schotEnemy"), gdjs.gameCode.GDschotEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerBulletObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDschotEnemyObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.gameCode.GDEnemyObjects1);
/* Reuse gdjs.gameCode.GDPlayerBulletObjects1 */
/* Reuse gdjs.gameCode.GDschotEnemyObjects1 */
gdjs.gameCode.GDCoin2Objects1.length = 0;

gdjs.gameCode.GDDebrisParticleObjects1.length = 0;

gdjs.gameCode.GDExplosionObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDDebrisParticleObjects1Objects, (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterXInScene()), (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterYInScene()), "");
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDExplosionObjects1Objects, (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterXInScene()), (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterYInScene()), "");
}
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/Collision.wav", false, runtimeScene.getGame().getVariables().getFromIndex(7).getChild("sound").getAsNumber(), gdjs.randomWithStep(0.9, 1.1, 0.05));
}
{for(var i = 0, len = gdjs.gameCode.GDschotEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDschotEnemyObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.2, gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), 0.05, false, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDschotEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDschotEnemyObjects1[i].returnVariable(gdjs.gameCode.GDschotEnemyObjects1[i].getVariables().getFromIndex(0)).sub(runtimeScene.getGame().getVariables().getFromIndex(9).getAsNumber());
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin2Objects1Objects, (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointX("")), (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointY("")), "");
}
{runtimeScene.getGame().getVariables().getFromIndex(10).sub(1);
}
{for(var i = 0, len = gdjs.gameCode.GDPlayerBulletObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerBulletObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Explosion"), gdjs.gameCode.GDExplosionObjects1);
gdjs.copyArray(runtimeScene.getObjects("schotEnemy"), gdjs.gameCode.GDschotEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDExplosionObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDschotEnemyObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(8).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24754372);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.gameCode.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerBullet"), gdjs.gameCode.GDPlayerBulletObjects1);
/* Reuse gdjs.gameCode.GDschotEnemyObjects1 */
gdjs.gameCode.GDCoin2Objects1.length = 0;

gdjs.gameCode.GDDebrisParticleObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDDebrisParticleObjects1Objects, (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterXInScene()), (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterYInScene()), "");
}
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/Collision.wav", false, runtimeScene.getGame().getVariables().getFromIndex(7).getChild("sound").getAsNumber(), gdjs.randomWithStep(0.9, 1.1, 0.05));
}
{for(var i = 0, len = gdjs.gameCode.GDschotEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDschotEnemyObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.2, gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), 0.05, false, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDschotEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDschotEnemyObjects1[i].returnVariable(gdjs.gameCode.GDschotEnemyObjects1[i].getVariables().getFromIndex(0)).sub(runtimeScene.getGame().getVariables().getFromIndex(13).getAsNumber());
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin2Objects1Objects, (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointX("")), (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointY("")), "");
}
{runtimeScene.getGame().getVariables().getFromIndex(10).sub(1);
}
{for(var i = 0, len = gdjs.gameCode.GDschotEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDschotEnemyObjects1[i].addForce((gdjs.gameCode.GDschotEnemyObjects1[i].getAngle()), (gdjs.gameCode.GDschotEnemyObjects1[i].getAngle()), 1);
}
}

{ //Subevents
gdjs.gameCode.eventsList18(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerBullet"), gdjs.gameCode.GDPlayerBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("smallEnemy"), gdjs.gameCode.GDsmallEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerBulletObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDsmallEnemyObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.gameCode.GDEnemyObjects1);
/* Reuse gdjs.gameCode.GDPlayerBulletObjects1 */
/* Reuse gdjs.gameCode.GDsmallEnemyObjects1 */
gdjs.gameCode.GDCoin3Objects1.length = 0;

gdjs.gameCode.GDDebrisParticleObjects1.length = 0;

gdjs.gameCode.GDExplosionObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDDebrisParticleObjects1Objects, (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterXInScene()), (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterYInScene()), "");
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDExplosionObjects1Objects, (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterXInScene()), (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterYInScene()), "");
}
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/Collision.wav", false, runtimeScene.getGame().getVariables().getFromIndex(7).getChild("sound").getAsNumber(), gdjs.randomWithStep(0.9, 1.1, 0.05));
}
{for(var i = 0, len = gdjs.gameCode.GDsmallEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDsmallEnemyObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.2, gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), 0.05, false, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDsmallEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDsmallEnemyObjects1[i].returnVariable(gdjs.gameCode.GDsmallEnemyObjects1[i].getVariables().getFromIndex(0)).sub(runtimeScene.getGame().getVariables().getFromIndex(9).getAsNumber());
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin3Objects1Objects, (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointX("")), (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointY("")), "");
}
{runtimeScene.getGame().getVariables().getFromIndex(10).sub(1);
}
{for(var i = 0, len = gdjs.gameCode.GDPlayerBulletObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerBulletObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Explosion"), gdjs.gameCode.GDExplosionObjects1);
gdjs.copyArray(runtimeScene.getObjects("smallEnemy"), gdjs.gameCode.GDsmallEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDExplosionObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDsmallEnemyObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(8).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24760356);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.gameCode.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerBullet"), gdjs.gameCode.GDPlayerBulletObjects1);
/* Reuse gdjs.gameCode.GDsmallEnemyObjects1 */
gdjs.gameCode.GDCoin3Objects1.length = 0;

gdjs.gameCode.GDDebrisParticleObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDDebrisParticleObjects1Objects, (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterXInScene()), (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterYInScene()), "");
}
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/Collision.wav", false, runtimeScene.getGame().getVariables().getFromIndex(7).getChild("sound").getAsNumber(), gdjs.randomWithStep(0.9, 1.1, 0.05));
}
{for(var i = 0, len = gdjs.gameCode.GDsmallEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDsmallEnemyObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.2, gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), 0.05, false, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDsmallEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDsmallEnemyObjects1[i].returnVariable(gdjs.gameCode.GDsmallEnemyObjects1[i].getVariables().getFromIndex(0)).sub(runtimeScene.getGame().getVariables().getFromIndex(13).getAsNumber());
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin3Objects1Objects, (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointX("")), (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointY("")), "");
}
{runtimeScene.getGame().getVariables().getFromIndex(10).sub(1);
}
{for(var i = 0, len = gdjs.gameCode.GDsmallEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDsmallEnemyObjects1[i].addForce((gdjs.gameCode.GDsmallEnemyObjects1[i].getAngle()), (gdjs.gameCode.GDsmallEnemyObjects1[i].getAngle()), 1);
}
}

{ //Subevents
gdjs.gameCode.eventsList19(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("BigEnemy"), gdjs.gameCode.GDBigEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerBullet"), gdjs.gameCode.GDPlayerBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerBulletObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBigEnemyObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDBigEnemyObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.gameCode.GDEnemyObjects1);
/* Reuse gdjs.gameCode.GDPlayerBulletObjects1 */
gdjs.gameCode.GDCoin4Objects1.length = 0;

gdjs.gameCode.GDDebrisParticleObjects1.length = 0;

gdjs.gameCode.GDExplosionObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDDebrisParticleObjects1Objects, (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterXInScene()), (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterYInScene()), "");
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDExplosionObjects1Objects, (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterXInScene()), (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterYInScene()), "");
}
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/Collision.wav", false, runtimeScene.getGame().getVariables().getFromIndex(7).getChild("sound").getAsNumber(), gdjs.randomWithStep(0.9, 1.1, 0.05));
}
{for(var i = 0, len = gdjs.gameCode.GDBigEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDBigEnemyObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.2, gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), 0.05, false, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDBigEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDBigEnemyObjects1[i].returnVariable(gdjs.gameCode.GDBigEnemyObjects1[i].getVariables().getFromIndex(0)).sub(runtimeScene.getGame().getVariables().getFromIndex(9).getAsNumber());
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin4Objects1Objects, (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointX("")), (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointY("")), "");
}
{runtimeScene.getGame().getVariables().getFromIndex(10).sub(1);
}
{for(var i = 0, len = gdjs.gameCode.GDPlayerBulletObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerBulletObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("BigEnemy"), gdjs.gameCode.GDBigEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Explosion"), gdjs.gameCode.GDExplosionObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDExplosionObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBigEnemyObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(8).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24766340);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDBigEnemyObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.gameCode.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerBullet"), gdjs.gameCode.GDPlayerBulletObjects1);
gdjs.gameCode.GDCoin4Objects1.length = 0;

gdjs.gameCode.GDDebrisParticleObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDDebrisParticleObjects1Objects, (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterXInScene()), (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterYInScene()), "");
}
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/Collision.wav", false, runtimeScene.getGame().getVariables().getFromIndex(7).getChild("sound").getAsNumber(), gdjs.randomWithStep(0.9, 1.1, 0.05));
}
{for(var i = 0, len = gdjs.gameCode.GDBigEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDBigEnemyObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.2, gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), 0.05, false, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDBigEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDBigEnemyObjects1[i].returnVariable(gdjs.gameCode.GDBigEnemyObjects1[i].getVariables().getFromIndex(0)).sub(runtimeScene.getGame().getVariables().getFromIndex(13).getAsNumber());
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin4Objects1Objects, (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointX("")), (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointY("")), "");
}
{runtimeScene.getGame().getVariables().getFromIndex(10).sub(1);
}
{for(var i = 0, len = gdjs.gameCode.GDBigEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDBigEnemyObjects1[i].addForce(100, 100, 1);
}
}

{ //Subevents
gdjs.gameCode.eventsList20(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerBullet"), gdjs.gameCode.GDPlayerBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("SniperEnemy"), gdjs.gameCode.GDSniperEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerBulletObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDSniperEnemyObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.gameCode.GDEnemyObjects1);
/* Reuse gdjs.gameCode.GDPlayerBulletObjects1 */
/* Reuse gdjs.gameCode.GDSniperEnemyObjects1 */
gdjs.gameCode.GDCoin2Objects1.length = 0;

gdjs.gameCode.GDCoin4Objects1.length = 0;

gdjs.gameCode.GDDebrisParticleObjects1.length = 0;

gdjs.gameCode.GDExplosionObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDDebrisParticleObjects1Objects, (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterXInScene()), (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterYInScene()), "");
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDExplosionObjects1Objects, (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterXInScene()), (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterYInScene()), "");
}
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/Collision.wav", false, runtimeScene.getGame().getVariables().getFromIndex(7).getChild("sound").getAsNumber(), gdjs.randomWithStep(0.9, 1.1, 0.05));
}
{for(var i = 0, len = gdjs.gameCode.GDSniperEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDSniperEnemyObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.2, gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), 0.05, false, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDSniperEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDSniperEnemyObjects1[i].returnVariable(gdjs.gameCode.GDSniperEnemyObjects1[i].getVariables().getFromIndex(0)).sub(runtimeScene.getGame().getVariables().getFromIndex(9).getAsNumber());
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin4Objects1Objects, (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointX("")), (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointY("")), "");
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin2Objects1Objects, (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointX("")), (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointY("")), "");
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin2Objects1Objects, (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointX("")), (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointY("")), "");
}
{runtimeScene.getGame().getVariables().getFromIndex(10).sub(1);
}
{for(var i = 0, len = gdjs.gameCode.GDPlayerBulletObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerBulletObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Explosion"), gdjs.gameCode.GDExplosionObjects1);
gdjs.copyArray(runtimeScene.getObjects("SniperEnemy"), gdjs.gameCode.GDSniperEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDExplosionObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDSniperEnemyObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(8).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24772780);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.gameCode.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerBullet"), gdjs.gameCode.GDPlayerBulletObjects1);
/* Reuse gdjs.gameCode.GDSniperEnemyObjects1 */
gdjs.gameCode.GDCoin2Objects1.length = 0;

gdjs.gameCode.GDCoin4Objects1.length = 0;

gdjs.gameCode.GDDebrisParticleObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDDebrisParticleObjects1Objects, (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterXInScene()), (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getCenterYInScene()), "");
}
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/Collision.wav", false, runtimeScene.getGame().getVariables().getFromIndex(7).getChild("sound").getAsNumber(), gdjs.randomWithStep(0.9, 1.1, 0.05));
}
{for(var i = 0, len = gdjs.gameCode.GDSniperEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDSniperEnemyObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.2, gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), gdjs.randomWithStep(-5, 5, 10), 0.05, false, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDSniperEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDSniperEnemyObjects1[i].returnVariable(gdjs.gameCode.GDSniperEnemyObjects1[i].getVariables().getFromIndex(0)).sub(runtimeScene.getGame().getVariables().getFromIndex(13).getAsNumber());
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin4Objects1Objects, (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointX("")), (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointY("")), "");
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin2Objects1Objects, (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointX("")), (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointY("")), "");
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin2Objects1Objects, (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointX("")), (( gdjs.gameCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDEnemyObjects1[0].getPointY("")), "");
}
{runtimeScene.getGame().getVariables().getFromIndex(10).sub(1);
}
{for(var i = 0, len = gdjs.gameCode.GDSniperEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDSniperEnemyObjects1[i].addForce(100, 100, 1);
}
}

{ //Subevents
gdjs.gameCode.eventsList21(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.gameCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDPlayerObjects1[i].getBehavior("Health").IsDead(null) ) {
        isConditionTrue_0 = true;
        gdjs.gameCode.GDPlayerObjects1[k] = gdjs.gameCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].deleteFromScene(runtimeScene);
}
}

{ //Subevents
gdjs.gameCode.eventsList22(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Base"), gdjs.gameCode.GDBaseObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.gameCode.GDBaseObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDBaseObjects1[i].getBehavior("Health").IsDead(null) ) {
        isConditionTrue_0 = true;
        gdjs.gameCode.GDBaseObjects1[k] = gdjs.gameCode.GDBaseObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDBaseObjects1.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(10).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(0);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game Over", false);
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HeartScrollBar"), gdjs.gameCode.GDHeartScrollBarObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.gameCode.GDHeartScrollBarObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDHeartScrollBarObjects1[i].SetValue((( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getBehavior("Health").Health(null)), null);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("ThickPixelRoundBulletAmmo"), gdjs.gameCode.GDThickPixelRoundBulletAmmoObjects1);
{for(var i = 0, len = gdjs.gameCode.GDThickPixelRoundBulletAmmoObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDThickPixelRoundBulletAmmoObjects1[i].SetValue((( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getBehavior("FireBullet").AmmoQuantity(null)), null);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(19).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("FireBullet").SetBulletQuantityOp(runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber(), null);
}
}

{ //Subevents
gdjs.gameCode.eventsList23(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.gameCode.GDbulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbulletObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDPlayerObjects1 */
/* Reuse gdjs.gameCode.GDbulletObjects1 */
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("FireBullet").IncreaseAmmo(gdjs.randomInRange(0, runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber()), null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDbulletObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDbulletObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("HealthUP"), gdjs.gameCode.GDHealthUPObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDHealthUPObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Base"), gdjs.gameCode.GDBaseObjects1);
/* Reuse gdjs.gameCode.GDHealthUPObjects1 */
/* Reuse gdjs.gameCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("Health").SetMaxHealthOp(gdjs.gameCode.GDPlayerObjects1[i].getBehavior("Health").MaxHealth(null) + (runtimeScene.getGame().getVariables().getFromIndex(5).getAsNumber()), null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDBaseObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDBaseObjects1[i].getBehavior("Health").SetMaxHealthOp(gdjs.gameCode.GDBaseObjects1[i].getBehavior("Health").MaxHealth(null) + (10), null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("Health").Heal(3, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDBaseObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDBaseObjects1[i].getBehavior("Health").Heal(3, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDHealthUPObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDHealthUPObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ArmorUP"), gdjs.gameCode.GDArmorUPObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDArmorUPObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDArmorUPObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Base"), gdjs.gameCode.GDBaseObjects1);
/* Reuse gdjs.gameCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("Health").SetPercentDamageReductionOp(runtimeScene.getGame().getVariables().getFromIndex(5).getAsNumber() + 0.1, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDBaseObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDBaseObjects1[i].getBehavior("Health").SetPercentDamageReductionOp(runtimeScene.getGame().getVariables().getFromIndex(5).getAsNumber() + 0.2, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDArmorUPObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDArmorUPObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.gameCode.GDCoinObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoinObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDCoinObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(6).add(1000);
}
{for(var i = 0, len = gdjs.gameCode.GDCoinObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDCoinObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("people1"), gdjs.gameCode.GDpeople1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpeople1Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDPlayerObjects1 */
/* Reuse gdjs.gameCode.GDpeople1Objects1 */
{runtimeScene.getGame().getVariables().getFromIndex(6).add(5000);
}
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("Scale").setScale(1.3);
}
}
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("Tween").addObjectScaleTween3("stappin", 1, "bouncePast", 0.3, false, true);
}
}
{for(var i = 0, len = gdjs.gameCode.GDpeople1Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDpeople1Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("Health").SetHealthRegenDelayOp(runtimeScene.getGame().getVariables().getFromIndex(17).getAsNumber(), null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].getBehavior("Health").Heal(runtimeScene.getGame().getVariables().getFromIndex(18).getAsNumber(), null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.gameCode.GDMenuObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.gameCode.GDMenuObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDMenuObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.gameCode.GDMenuObjects1[k] = gdjs.gameCode.GDMenuObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDMenuObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "MainMenu");
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtsExt__CursorType__ChangeCursorType.func(runtimeScene, "crosshair", null);
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Money_Bag_Pixel"), gdjs.gameCode.GDMoney_9595Bag_9595PixelObjects1);
{for(var i = 0, len = gdjs.gameCode.GDMoney_9595Bag_9595PixelObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDMoney_9595Bag_9595PixelObjects1[i].SetScore(runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber(), null);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Base"), gdjs.gameCode.GDBaseObjects1);
gdjs.copyArray(runtimeScene.getObjects("MetalRedBar"), gdjs.gameCode.GDMetalRedBarObjects1);
{for(var i = 0, len = gdjs.gameCode.GDMetalRedBarObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDMetalRedBarObjects1[i].SetValue((( gdjs.gameCode.GDBaseObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDBaseObjects1[0].getBehavior("Health").Health(null)), null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerBullet"), gdjs.gameCode.GDPlayerBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("bullet2"), gdjs.gameCode.GDbullet2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerBulletObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDPlayerBulletObjects1 */
/* Reuse gdjs.gameCode.GDbullet2Objects1 */
gdjs.gameCode.GDSparksObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDSparksObjects1Objects, (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getPointX("")), (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.gameCode.GDPlayerBulletObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerBulletObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.gameCode.GDbullet2Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDbullet2Objects1[i].deleteFromScene(runtimeScene);
}
}

{ //Subevents
gdjs.gameCode.eventsList24(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerBullet"), gdjs.gameCode.GDPlayerBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("bullet3"), gdjs.gameCode.GDbullet3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerBulletObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet3Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDPlayerBulletObjects1 */
/* Reuse gdjs.gameCode.GDbullet3Objects1 */
gdjs.gameCode.GDSparksObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDSparksObjects1Objects, (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getPointX("")), (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.gameCode.GDbullet3Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDbullet3Objects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.gameCode.GDPlayerBulletObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerBulletObjects1[i].deleteFromScene(runtimeScene);
}
}

{ //Subevents
gdjs.gameCode.eventsList25(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerBullet"), gdjs.gameCode.GDPlayerBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("bullet4"), gdjs.gameCode.GDbullet4Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerBulletObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet4Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDPlayerBulletObjects1 */
/* Reuse gdjs.gameCode.GDbullet4Objects1 */
gdjs.gameCode.GDSparksObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDSparksObjects1Objects, (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getPointX("")), (( gdjs.gameCode.GDPlayerBulletObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerBulletObjects1[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.gameCode.GDPlayerBulletObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerBulletObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.gameCode.GDbullet4Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDbullet4Objects1[i].deleteFromScene(runtimeScene);
}
}

{ //Subevents
gdjs.gameCode.eventsList26(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shop"), gdjs.gameCode.GDShopObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.gameCode.GDShopObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDShopObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.gameCode.GDShopObjects1[k] = gdjs.gameCode.GDShopObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDShopObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Shop");
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("brand"), gdjs.gameCode.GDbrandObjects1);
{for(var i = 0, len = gdjs.gameCode.GDbrandObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDbrandObjects1[i].setPosition((( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointX("uitlaat")),(( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointY("uitlaat")));
}
}
{for(var i = 0, len = gdjs.gameCode.GDbrandObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDbrandObjects1[i].setAngle((( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getAngle()) - 180);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.gameCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.gameCode.GDPlayerObjects1[k] = gdjs.gameCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("brand"), gdjs.gameCode.GDbrandObjects1);
{for(var i = 0, len = gdjs.gameCode.GDbrandObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDbrandObjects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.gameCode.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.gameCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.gameCode.GDPlayerObjects1[k] = gdjs.gameCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("brand"), gdjs.gameCode.GDbrandObjects1);
{for(var i = 0, len = gdjs.gameCode.GDbrandObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDbrandObjects1[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "dropSpawn4") >= 5;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);
gdjs.gameCode.GDpeople1Objects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpeople1Objects1Objects, (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointX("")) + (gdjs.randomWithStep(-1, 1, 2) * gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2), (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointY("")) + (gdjs.randomWithStep(-1, 1, 2) * gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2), "");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "dropSpawn4");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.gameCode.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("people1"), gdjs.gameCode.GDpeople1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpeople1Objects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDEnemyObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDpeople1Objects1 */
{for(var i = 0, len = gdjs.gameCode.GDpeople1Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDpeople1Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("people1"), gdjs.gameCode.GDpeople1Objects1);
gdjs.copyArray(runtimeScene.getObjects("schotEnemy"), gdjs.gameCode.GDschotEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpeople1Objects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDschotEnemyObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDpeople1Objects1 */
{for(var i = 0, len = gdjs.gameCode.GDpeople1Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDpeople1Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("SniperEnemy"), gdjs.gameCode.GDSniperEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("people1"), gdjs.gameCode.GDpeople1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpeople1Objects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDSniperEnemyObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDpeople1Objects1 */
{for(var i = 0, len = gdjs.gameCode.GDpeople1Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDpeople1Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("BigEnemy"), gdjs.gameCode.GDBigEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("people1"), gdjs.gameCode.GDpeople1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpeople1Objects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBigEnemyObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDpeople1Objects1 */
{for(var i = 0, len = gdjs.gameCode.GDpeople1Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDpeople1Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("people1"), gdjs.gameCode.GDpeople1Objects1);
gdjs.copyArray(runtimeScene.getObjects("smallEnemy"), gdjs.gameCode.GDsmallEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpeople1Objects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDsmallEnemyObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDpeople1Objects1 */
{for(var i = 0, len = gdjs.gameCode.GDpeople1Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDpeople1Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("bullet4"), gdjs.gameCode.GDbullet4Objects1);
gdjs.copyArray(runtimeScene.getObjects("people1"), gdjs.gameCode.GDpeople1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpeople1Objects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet4Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDpeople1Objects1 */
{for(var i = 0, len = gdjs.gameCode.GDpeople1Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDpeople1Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("bullet2"), gdjs.gameCode.GDbullet2Objects1);
gdjs.copyArray(runtimeScene.getObjects("people1"), gdjs.gameCode.GDpeople1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpeople1Objects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDpeople1Objects1 */
{for(var i = 0, len = gdjs.gameCode.GDpeople1Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDpeople1Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("bullet3"), gdjs.gameCode.GDbullet3Objects1);
gdjs.copyArray(runtimeScene.getObjects("people1"), gdjs.gameCode.GDpeople1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpeople1Objects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet3Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDpeople1Objects1 */
{for(var i = 0, len = gdjs.gameCode.GDpeople1Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDpeople1Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Explosion"), gdjs.gameCode.GDExplosionObjects1);
gdjs.copyArray(runtimeScene.getObjects("people1"), gdjs.gameCode.GDpeople1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDpeople1Objects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDExplosionObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDpeople1Objects1 */
{for(var i = 0, len = gdjs.gameCode.GDpeople1Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDpeople1Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Base"), gdjs.gameCode.GDBaseObjects1);
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.gameCode.GDEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBaseObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDEnemyObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDBaseObjects1 */
/* Reuse gdjs.gameCode.GDEnemyObjects1 */
{for(var i = 0, len = gdjs.gameCode.GDBaseObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDBaseObjects1[i].getBehavior("Health").Hit(10, true, true, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDEnemyObjects1[i].returnVariable(gdjs.gameCode.GDEnemyObjects1[i].getVariables().getFromIndex(0)).sub(1);
}
}
{for(var i = 0, len = gdjs.gameCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDEnemyObjects1[i].addForce((gdjs.gameCode.GDEnemyObjects1[i].getAngle()), (gdjs.gameCode.GDEnemyObjects1[i].getAngle()), 1);
}
}

{ //Subevents
gdjs.gameCode.eventsList27(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Base"), gdjs.gameCode.GDBaseObjects1);
gdjs.copyArray(runtimeScene.getObjects("smallEnemy"), gdjs.gameCode.GDsmallEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBaseObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDsmallEnemyObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDBaseObjects1 */
/* Reuse gdjs.gameCode.GDsmallEnemyObjects1 */
{for(var i = 0, len = gdjs.gameCode.GDBaseObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDBaseObjects1[i].getBehavior("Health").Hit(10, true, true, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDsmallEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDsmallEnemyObjects1[i].returnVariable(gdjs.gameCode.GDsmallEnemyObjects1[i].getVariables().getFromIndex(0)).sub(1);
}
}
{for(var i = 0, len = gdjs.gameCode.GDsmallEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDsmallEnemyObjects1[i].addForce((gdjs.gameCode.GDsmallEnemyObjects1[i].getAngle()), (gdjs.gameCode.GDsmallEnemyObjects1[i].getAngle()), 1);
}
}

{ //Subevents
gdjs.gameCode.eventsList28(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Base"), gdjs.gameCode.GDBaseObjects1);
gdjs.copyArray(runtimeScene.getObjects("BigEnemy"), gdjs.gameCode.GDBigEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBaseObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBigEnemyObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDBaseObjects1 */
/* Reuse gdjs.gameCode.GDBigEnemyObjects1 */
{for(var i = 0, len = gdjs.gameCode.GDBaseObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDBaseObjects1[i].getBehavior("Health").Hit(10, true, true, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDBigEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDBigEnemyObjects1[i].returnVariable(gdjs.gameCode.GDBigEnemyObjects1[i].getVariables().getFromIndex(0)).sub(1);
}
}
{for(var i = 0, len = gdjs.gameCode.GDBigEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDBigEnemyObjects1[i].addForce((gdjs.gameCode.GDBigEnemyObjects1[i].getAngle()), (gdjs.gameCode.GDBigEnemyObjects1[i].getAngle()), 1);
}
}

{ //Subevents
gdjs.gameCode.eventsList29(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Base"), gdjs.gameCode.GDBaseObjects1);
gdjs.copyArray(runtimeScene.getObjects("SniperEnemy"), gdjs.gameCode.GDSniperEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBaseObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDSniperEnemyObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDBaseObjects1 */
/* Reuse gdjs.gameCode.GDSniperEnemyObjects1 */
{for(var i = 0, len = gdjs.gameCode.GDBaseObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDBaseObjects1[i].getBehavior("Health").Hit(10, true, true, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDSniperEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDSniperEnemyObjects1[i].returnVariable(gdjs.gameCode.GDSniperEnemyObjects1[i].getVariables().getFromIndex(0)).sub(1);
}
}
{for(var i = 0, len = gdjs.gameCode.GDSniperEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDSniperEnemyObjects1[i].addForce((gdjs.gameCode.GDSniperEnemyObjects1[i].getAngle()), (gdjs.gameCode.GDSniperEnemyObjects1[i].getAngle()), 1);
}
}

{ //Subevents
gdjs.gameCode.eventsList30(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Base"), gdjs.gameCode.GDBaseObjects1);
gdjs.copyArray(runtimeScene.getObjects("schotEnemy"), gdjs.gameCode.GDschotEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBaseObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDschotEnemyObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDBaseObjects1 */
/* Reuse gdjs.gameCode.GDschotEnemyObjects1 */
{for(var i = 0, len = gdjs.gameCode.GDBaseObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDBaseObjects1[i].getBehavior("Health").Hit(10, true, true, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDschotEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDschotEnemyObjects1[i].returnVariable(gdjs.gameCode.GDschotEnemyObjects1[i].getVariables().getFromIndex(0)).sub(1);
}
}
{for(var i = 0, len = gdjs.gameCode.GDschotEnemyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDschotEnemyObjects1[i].addForce((gdjs.gameCode.GDschotEnemyObjects1[i].getAngle()), (gdjs.gameCode.GDschotEnemyObjects1[i].getAngle()), 1);
}
}

{ //Subevents
gdjs.gameCode.eventsList31(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Base"), gdjs.gameCode.GDBaseObjects1);
gdjs.copyArray(runtimeScene.getObjects("bullet2"), gdjs.gameCode.GDbullet2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBaseObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDBaseObjects1 */
/* Reuse gdjs.gameCode.GDbullet2Objects1 */
{for(var i = 0, len = gdjs.gameCode.GDBaseObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDBaseObjects1[i].getBehavior("Health").Hit(15, true, true, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDbullet2Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDbullet2Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Base"), gdjs.gameCode.GDBaseObjects1);
gdjs.copyArray(runtimeScene.getObjects("bullet3"), gdjs.gameCode.GDbullet3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBaseObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet3Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDBaseObjects1 */
/* Reuse gdjs.gameCode.GDbullet3Objects1 */
{for(var i = 0, len = gdjs.gameCode.GDBaseObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDBaseObjects1[i].getBehavior("Health").Hit(15, true, true, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDbullet3Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDbullet3Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Base"), gdjs.gameCode.GDBaseObjects1);
gdjs.copyArray(runtimeScene.getObjects("bullet4"), gdjs.gameCode.GDbullet4Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDBaseObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDbullet4Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDBaseObjects1 */
/* Reuse gdjs.gameCode.GDbullet4Objects1 */
{for(var i = 0, len = gdjs.gameCode.GDBaseObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDBaseObjects1[i].getBehavior("Health").Hit(15, true, true, null);
}
}
{for(var i = 0, len = gdjs.gameCode.GDbullet4Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDbullet4Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coin2"), gdjs.gameCode.GDCoin2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDCoin2Objects1 */
{runtimeScene.getGame().getVariables().getFromIndex(6).add(100);
}
{for(var i = 0, len = gdjs.gameCode.GDCoin2Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDCoin2Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coin3"), gdjs.gameCode.GDCoin3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin3Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDCoin3Objects1 */
{runtimeScene.getGame().getVariables().getFromIndex(6).add(70);
}
{for(var i = 0, len = gdjs.gameCode.GDCoin3Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDCoin3Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coin4"), gdjs.gameCode.GDCoin4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.gameCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPlayerObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDCoin4Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDCoin4Objects1 */
{runtimeScene.getGame().getVariables().getFromIndex(6).add(300);
}
{for(var i = 0, len = gdjs.gameCode.GDCoin4Objects1.length ;i < len;++i) {
    gdjs.gameCode.GDCoin4Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


};

gdjs.gameCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.gameCode.GDPlayerObjects1.length = 0;
gdjs.gameCode.GDPlayerObjects2.length = 0;
gdjs.gameCode.GDPlayerObjects3.length = 0;
gdjs.gameCode.GDPlayerObjects4.length = 0;
gdjs.gameCode.GDMoveJoystickObjects1.length = 0;
gdjs.gameCode.GDMoveJoystickObjects2.length = 0;
gdjs.gameCode.GDMoveJoystickObjects3.length = 0;
gdjs.gameCode.GDMoveJoystickObjects4.length = 0;
gdjs.gameCode.GDRepeatingBackgroundObjects1.length = 0;
gdjs.gameCode.GDRepeatingBackgroundObjects2.length = 0;
gdjs.gameCode.GDRepeatingBackgroundObjects3.length = 0;
gdjs.gameCode.GDRepeatingBackgroundObjects4.length = 0;
gdjs.gameCode.GDEnemyObjects1.length = 0;
gdjs.gameCode.GDEnemyObjects2.length = 0;
gdjs.gameCode.GDEnemyObjects3.length = 0;
gdjs.gameCode.GDEnemyObjects4.length = 0;
gdjs.gameCode.GDPlayerBulletObjects1.length = 0;
gdjs.gameCode.GDPlayerBulletObjects2.length = 0;
gdjs.gameCode.GDPlayerBulletObjects3.length = 0;
gdjs.gameCode.GDPlayerBulletObjects4.length = 0;
gdjs.gameCode.GDAimJoystickObjects1.length = 0;
gdjs.gameCode.GDAimJoystickObjects2.length = 0;
gdjs.gameCode.GDAimJoystickObjects3.length = 0;
gdjs.gameCode.GDAimJoystickObjects4.length = 0;
gdjs.gameCode.GDDebrisParticleObjects1.length = 0;
gdjs.gameCode.GDDebrisParticleObjects2.length = 0;
gdjs.gameCode.GDDebrisParticleObjects3.length = 0;
gdjs.gameCode.GDDebrisParticleObjects4.length = 0;
gdjs.gameCode.GDLargeDebrisParticleObjects1.length = 0;
gdjs.gameCode.GDLargeDebrisParticleObjects2.length = 0;
gdjs.gameCode.GDLargeDebrisParticleObjects3.length = 0;
gdjs.gameCode.GDLargeDebrisParticleObjects4.length = 0;
gdjs.gameCode.GDHeartScrollBarObjects1.length = 0;
gdjs.gameCode.GDHeartScrollBarObjects2.length = 0;
gdjs.gameCode.GDHeartScrollBarObjects3.length = 0;
gdjs.gameCode.GDHeartScrollBarObjects4.length = 0;
gdjs.gameCode.GDThickPixelRoundBulletAmmoObjects1.length = 0;
gdjs.gameCode.GDThickPixelRoundBulletAmmoObjects2.length = 0;
gdjs.gameCode.GDThickPixelRoundBulletAmmoObjects3.length = 0;
gdjs.gameCode.GDThickPixelRoundBulletAmmoObjects4.length = 0;
gdjs.gameCode.GDbulletObjects1.length = 0;
gdjs.gameCode.GDbulletObjects2.length = 0;
gdjs.gameCode.GDbulletObjects3.length = 0;
gdjs.gameCode.GDbulletObjects4.length = 0;
gdjs.gameCode.GDMenuObjects1.length = 0;
gdjs.gameCode.GDMenuObjects2.length = 0;
gdjs.gameCode.GDMenuObjects3.length = 0;
gdjs.gameCode.GDMenuObjects4.length = 0;
gdjs.gameCode.GDsmallEnemyObjects1.length = 0;
gdjs.gameCode.GDsmallEnemyObjects2.length = 0;
gdjs.gameCode.GDsmallEnemyObjects3.length = 0;
gdjs.gameCode.GDsmallEnemyObjects4.length = 0;
gdjs.gameCode.GDBigEnemyObjects1.length = 0;
gdjs.gameCode.GDBigEnemyObjects2.length = 0;
gdjs.gameCode.GDBigEnemyObjects3.length = 0;
gdjs.gameCode.GDBigEnemyObjects4.length = 0;
gdjs.gameCode.GDbullet2Objects1.length = 0;
gdjs.gameCode.GDbullet2Objects2.length = 0;
gdjs.gameCode.GDbullet2Objects3.length = 0;
gdjs.gameCode.GDbullet2Objects4.length = 0;
gdjs.gameCode.GDSniperEnemyObjects1.length = 0;
gdjs.gameCode.GDSniperEnemyObjects2.length = 0;
gdjs.gameCode.GDSniperEnemyObjects3.length = 0;
gdjs.gameCode.GDSniperEnemyObjects4.length = 0;
gdjs.gameCode.GDbullet3Objects1.length = 0;
gdjs.gameCode.GDbullet3Objects2.length = 0;
gdjs.gameCode.GDbullet3Objects3.length = 0;
gdjs.gameCode.GDbullet3Objects4.length = 0;
gdjs.gameCode.GDbrandObjects1.length = 0;
gdjs.gameCode.GDbrandObjects2.length = 0;
gdjs.gameCode.GDbrandObjects3.length = 0;
gdjs.gameCode.GDbrandObjects4.length = 0;
gdjs.gameCode.GDMoney_9595Bag_9595PixelObjects1.length = 0;
gdjs.gameCode.GDMoney_9595Bag_9595PixelObjects2.length = 0;
gdjs.gameCode.GDMoney_9595Bag_9595PixelObjects3.length = 0;
gdjs.gameCode.GDMoney_9595Bag_9595PixelObjects4.length = 0;
gdjs.gameCode.GDschotEnemyObjects1.length = 0;
gdjs.gameCode.GDschotEnemyObjects2.length = 0;
gdjs.gameCode.GDschotEnemyObjects3.length = 0;
gdjs.gameCode.GDschotEnemyObjects4.length = 0;
gdjs.gameCode.GDbullet4Objects1.length = 0;
gdjs.gameCode.GDbullet4Objects2.length = 0;
gdjs.gameCode.GDbullet4Objects3.length = 0;
gdjs.gameCode.GDbullet4Objects4.length = 0;
gdjs.gameCode.GDHealthUPObjects1.length = 0;
gdjs.gameCode.GDHealthUPObjects2.length = 0;
gdjs.gameCode.GDHealthUPObjects3.length = 0;
gdjs.gameCode.GDHealthUPObjects4.length = 0;
gdjs.gameCode.GDArmorUPObjects1.length = 0;
gdjs.gameCode.GDArmorUPObjects2.length = 0;
gdjs.gameCode.GDArmorUPObjects3.length = 0;
gdjs.gameCode.GDArmorUPObjects4.length = 0;
gdjs.gameCode.GDShopObjects1.length = 0;
gdjs.gameCode.GDShopObjects2.length = 0;
gdjs.gameCode.GDShopObjects3.length = 0;
gdjs.gameCode.GDShopObjects4.length = 0;
gdjs.gameCode.GDExplosionObjects1.length = 0;
gdjs.gameCode.GDExplosionObjects2.length = 0;
gdjs.gameCode.GDExplosionObjects3.length = 0;
gdjs.gameCode.GDExplosionObjects4.length = 0;
gdjs.gameCode.GDCoinObjects1.length = 0;
gdjs.gameCode.GDCoinObjects2.length = 0;
gdjs.gameCode.GDCoinObjects3.length = 0;
gdjs.gameCode.GDCoinObjects4.length = 0;
gdjs.gameCode.GDpijlObjects1.length = 0;
gdjs.gameCode.GDpijlObjects2.length = 0;
gdjs.gameCode.GDpijlObjects3.length = 0;
gdjs.gameCode.GDpijlObjects4.length = 0;
gdjs.gameCode.GDpeople1Objects1.length = 0;
gdjs.gameCode.GDpeople1Objects2.length = 0;
gdjs.gameCode.GDpeople1Objects3.length = 0;
gdjs.gameCode.GDpeople1Objects4.length = 0;
gdjs.gameCode.GDpijl2Objects1.length = 0;
gdjs.gameCode.GDpijl2Objects2.length = 0;
gdjs.gameCode.GDpijl2Objects3.length = 0;
gdjs.gameCode.GDpijl2Objects4.length = 0;
gdjs.gameCode.GDknopObjects1.length = 0;
gdjs.gameCode.GDknopObjects2.length = 0;
gdjs.gameCode.GDknopObjects3.length = 0;
gdjs.gameCode.GDknopObjects4.length = 0;
gdjs.gameCode.GDMetalRedBarObjects1.length = 0;
gdjs.gameCode.GDMetalRedBarObjects2.length = 0;
gdjs.gameCode.GDMetalRedBarObjects3.length = 0;
gdjs.gameCode.GDMetalRedBarObjects4.length = 0;
gdjs.gameCode.GDBaseTextObjects1.length = 0;
gdjs.gameCode.GDBaseTextObjects2.length = 0;
gdjs.gameCode.GDBaseTextObjects3.length = 0;
gdjs.gameCode.GDBaseTextObjects4.length = 0;
gdjs.gameCode.GDBaseObjects1.length = 0;
gdjs.gameCode.GDBaseObjects2.length = 0;
gdjs.gameCode.GDBaseObjects3.length = 0;
gdjs.gameCode.GDBaseObjects4.length = 0;
gdjs.gameCode.GDpijl3Objects1.length = 0;
gdjs.gameCode.GDpijl3Objects2.length = 0;
gdjs.gameCode.GDpijl3Objects3.length = 0;
gdjs.gameCode.GDpijl3Objects4.length = 0;
gdjs.gameCode.GDExplosion2Objects1.length = 0;
gdjs.gameCode.GDExplosion2Objects2.length = 0;
gdjs.gameCode.GDExplosion2Objects3.length = 0;
gdjs.gameCode.GDExplosion2Objects4.length = 0;
gdjs.gameCode.GDSparksObjects1.length = 0;
gdjs.gameCode.GDSparksObjects2.length = 0;
gdjs.gameCode.GDSparksObjects3.length = 0;
gdjs.gameCode.GDSparksObjects4.length = 0;
gdjs.gameCode.GDCoin4Objects1.length = 0;
gdjs.gameCode.GDCoin4Objects2.length = 0;
gdjs.gameCode.GDCoin4Objects3.length = 0;
gdjs.gameCode.GDCoin4Objects4.length = 0;
gdjs.gameCode.GDCoin3Objects1.length = 0;
gdjs.gameCode.GDCoin3Objects2.length = 0;
gdjs.gameCode.GDCoin3Objects3.length = 0;
gdjs.gameCode.GDCoin3Objects4.length = 0;
gdjs.gameCode.GDCoin2Objects1.length = 0;
gdjs.gameCode.GDCoin2Objects2.length = 0;
gdjs.gameCode.GDCoin2Objects3.length = 0;
gdjs.gameCode.GDCoin2Objects4.length = 0;
gdjs.gameCode.GDSmokeObjects1.length = 0;
gdjs.gameCode.GDSmokeObjects2.length = 0;
gdjs.gameCode.GDSmokeObjects3.length = 0;
gdjs.gameCode.GDSmokeObjects4.length = 0;

gdjs.gameCode.eventsList32(runtimeScene);
gdjs.gameCode.GDPlayerObjects1.length = 0;
gdjs.gameCode.GDPlayerObjects2.length = 0;
gdjs.gameCode.GDPlayerObjects3.length = 0;
gdjs.gameCode.GDPlayerObjects4.length = 0;
gdjs.gameCode.GDMoveJoystickObjects1.length = 0;
gdjs.gameCode.GDMoveJoystickObjects2.length = 0;
gdjs.gameCode.GDMoveJoystickObjects3.length = 0;
gdjs.gameCode.GDMoveJoystickObjects4.length = 0;
gdjs.gameCode.GDRepeatingBackgroundObjects1.length = 0;
gdjs.gameCode.GDRepeatingBackgroundObjects2.length = 0;
gdjs.gameCode.GDRepeatingBackgroundObjects3.length = 0;
gdjs.gameCode.GDRepeatingBackgroundObjects4.length = 0;
gdjs.gameCode.GDEnemyObjects1.length = 0;
gdjs.gameCode.GDEnemyObjects2.length = 0;
gdjs.gameCode.GDEnemyObjects3.length = 0;
gdjs.gameCode.GDEnemyObjects4.length = 0;
gdjs.gameCode.GDPlayerBulletObjects1.length = 0;
gdjs.gameCode.GDPlayerBulletObjects2.length = 0;
gdjs.gameCode.GDPlayerBulletObjects3.length = 0;
gdjs.gameCode.GDPlayerBulletObjects4.length = 0;
gdjs.gameCode.GDAimJoystickObjects1.length = 0;
gdjs.gameCode.GDAimJoystickObjects2.length = 0;
gdjs.gameCode.GDAimJoystickObjects3.length = 0;
gdjs.gameCode.GDAimJoystickObjects4.length = 0;
gdjs.gameCode.GDDebrisParticleObjects1.length = 0;
gdjs.gameCode.GDDebrisParticleObjects2.length = 0;
gdjs.gameCode.GDDebrisParticleObjects3.length = 0;
gdjs.gameCode.GDDebrisParticleObjects4.length = 0;
gdjs.gameCode.GDLargeDebrisParticleObjects1.length = 0;
gdjs.gameCode.GDLargeDebrisParticleObjects2.length = 0;
gdjs.gameCode.GDLargeDebrisParticleObjects3.length = 0;
gdjs.gameCode.GDLargeDebrisParticleObjects4.length = 0;
gdjs.gameCode.GDHeartScrollBarObjects1.length = 0;
gdjs.gameCode.GDHeartScrollBarObjects2.length = 0;
gdjs.gameCode.GDHeartScrollBarObjects3.length = 0;
gdjs.gameCode.GDHeartScrollBarObjects4.length = 0;
gdjs.gameCode.GDThickPixelRoundBulletAmmoObjects1.length = 0;
gdjs.gameCode.GDThickPixelRoundBulletAmmoObjects2.length = 0;
gdjs.gameCode.GDThickPixelRoundBulletAmmoObjects3.length = 0;
gdjs.gameCode.GDThickPixelRoundBulletAmmoObjects4.length = 0;
gdjs.gameCode.GDbulletObjects1.length = 0;
gdjs.gameCode.GDbulletObjects2.length = 0;
gdjs.gameCode.GDbulletObjects3.length = 0;
gdjs.gameCode.GDbulletObjects4.length = 0;
gdjs.gameCode.GDMenuObjects1.length = 0;
gdjs.gameCode.GDMenuObjects2.length = 0;
gdjs.gameCode.GDMenuObjects3.length = 0;
gdjs.gameCode.GDMenuObjects4.length = 0;
gdjs.gameCode.GDsmallEnemyObjects1.length = 0;
gdjs.gameCode.GDsmallEnemyObjects2.length = 0;
gdjs.gameCode.GDsmallEnemyObjects3.length = 0;
gdjs.gameCode.GDsmallEnemyObjects4.length = 0;
gdjs.gameCode.GDBigEnemyObjects1.length = 0;
gdjs.gameCode.GDBigEnemyObjects2.length = 0;
gdjs.gameCode.GDBigEnemyObjects3.length = 0;
gdjs.gameCode.GDBigEnemyObjects4.length = 0;
gdjs.gameCode.GDbullet2Objects1.length = 0;
gdjs.gameCode.GDbullet2Objects2.length = 0;
gdjs.gameCode.GDbullet2Objects3.length = 0;
gdjs.gameCode.GDbullet2Objects4.length = 0;
gdjs.gameCode.GDSniperEnemyObjects1.length = 0;
gdjs.gameCode.GDSniperEnemyObjects2.length = 0;
gdjs.gameCode.GDSniperEnemyObjects3.length = 0;
gdjs.gameCode.GDSniperEnemyObjects4.length = 0;
gdjs.gameCode.GDbullet3Objects1.length = 0;
gdjs.gameCode.GDbullet3Objects2.length = 0;
gdjs.gameCode.GDbullet3Objects3.length = 0;
gdjs.gameCode.GDbullet3Objects4.length = 0;
gdjs.gameCode.GDbrandObjects1.length = 0;
gdjs.gameCode.GDbrandObjects2.length = 0;
gdjs.gameCode.GDbrandObjects3.length = 0;
gdjs.gameCode.GDbrandObjects4.length = 0;
gdjs.gameCode.GDMoney_9595Bag_9595PixelObjects1.length = 0;
gdjs.gameCode.GDMoney_9595Bag_9595PixelObjects2.length = 0;
gdjs.gameCode.GDMoney_9595Bag_9595PixelObjects3.length = 0;
gdjs.gameCode.GDMoney_9595Bag_9595PixelObjects4.length = 0;
gdjs.gameCode.GDschotEnemyObjects1.length = 0;
gdjs.gameCode.GDschotEnemyObjects2.length = 0;
gdjs.gameCode.GDschotEnemyObjects3.length = 0;
gdjs.gameCode.GDschotEnemyObjects4.length = 0;
gdjs.gameCode.GDbullet4Objects1.length = 0;
gdjs.gameCode.GDbullet4Objects2.length = 0;
gdjs.gameCode.GDbullet4Objects3.length = 0;
gdjs.gameCode.GDbullet4Objects4.length = 0;
gdjs.gameCode.GDHealthUPObjects1.length = 0;
gdjs.gameCode.GDHealthUPObjects2.length = 0;
gdjs.gameCode.GDHealthUPObjects3.length = 0;
gdjs.gameCode.GDHealthUPObjects4.length = 0;
gdjs.gameCode.GDArmorUPObjects1.length = 0;
gdjs.gameCode.GDArmorUPObjects2.length = 0;
gdjs.gameCode.GDArmorUPObjects3.length = 0;
gdjs.gameCode.GDArmorUPObjects4.length = 0;
gdjs.gameCode.GDShopObjects1.length = 0;
gdjs.gameCode.GDShopObjects2.length = 0;
gdjs.gameCode.GDShopObjects3.length = 0;
gdjs.gameCode.GDShopObjects4.length = 0;
gdjs.gameCode.GDExplosionObjects1.length = 0;
gdjs.gameCode.GDExplosionObjects2.length = 0;
gdjs.gameCode.GDExplosionObjects3.length = 0;
gdjs.gameCode.GDExplosionObjects4.length = 0;
gdjs.gameCode.GDCoinObjects1.length = 0;
gdjs.gameCode.GDCoinObjects2.length = 0;
gdjs.gameCode.GDCoinObjects3.length = 0;
gdjs.gameCode.GDCoinObjects4.length = 0;
gdjs.gameCode.GDpijlObjects1.length = 0;
gdjs.gameCode.GDpijlObjects2.length = 0;
gdjs.gameCode.GDpijlObjects3.length = 0;
gdjs.gameCode.GDpijlObjects4.length = 0;
gdjs.gameCode.GDpeople1Objects1.length = 0;
gdjs.gameCode.GDpeople1Objects2.length = 0;
gdjs.gameCode.GDpeople1Objects3.length = 0;
gdjs.gameCode.GDpeople1Objects4.length = 0;
gdjs.gameCode.GDpijl2Objects1.length = 0;
gdjs.gameCode.GDpijl2Objects2.length = 0;
gdjs.gameCode.GDpijl2Objects3.length = 0;
gdjs.gameCode.GDpijl2Objects4.length = 0;
gdjs.gameCode.GDknopObjects1.length = 0;
gdjs.gameCode.GDknopObjects2.length = 0;
gdjs.gameCode.GDknopObjects3.length = 0;
gdjs.gameCode.GDknopObjects4.length = 0;
gdjs.gameCode.GDMetalRedBarObjects1.length = 0;
gdjs.gameCode.GDMetalRedBarObjects2.length = 0;
gdjs.gameCode.GDMetalRedBarObjects3.length = 0;
gdjs.gameCode.GDMetalRedBarObjects4.length = 0;
gdjs.gameCode.GDBaseTextObjects1.length = 0;
gdjs.gameCode.GDBaseTextObjects2.length = 0;
gdjs.gameCode.GDBaseTextObjects3.length = 0;
gdjs.gameCode.GDBaseTextObjects4.length = 0;
gdjs.gameCode.GDBaseObjects1.length = 0;
gdjs.gameCode.GDBaseObjects2.length = 0;
gdjs.gameCode.GDBaseObjects3.length = 0;
gdjs.gameCode.GDBaseObjects4.length = 0;
gdjs.gameCode.GDpijl3Objects1.length = 0;
gdjs.gameCode.GDpijl3Objects2.length = 0;
gdjs.gameCode.GDpijl3Objects3.length = 0;
gdjs.gameCode.GDpijl3Objects4.length = 0;
gdjs.gameCode.GDExplosion2Objects1.length = 0;
gdjs.gameCode.GDExplosion2Objects2.length = 0;
gdjs.gameCode.GDExplosion2Objects3.length = 0;
gdjs.gameCode.GDExplosion2Objects4.length = 0;
gdjs.gameCode.GDSparksObjects1.length = 0;
gdjs.gameCode.GDSparksObjects2.length = 0;
gdjs.gameCode.GDSparksObjects3.length = 0;
gdjs.gameCode.GDSparksObjects4.length = 0;
gdjs.gameCode.GDCoin4Objects1.length = 0;
gdjs.gameCode.GDCoin4Objects2.length = 0;
gdjs.gameCode.GDCoin4Objects3.length = 0;
gdjs.gameCode.GDCoin4Objects4.length = 0;
gdjs.gameCode.GDCoin3Objects1.length = 0;
gdjs.gameCode.GDCoin3Objects2.length = 0;
gdjs.gameCode.GDCoin3Objects3.length = 0;
gdjs.gameCode.GDCoin3Objects4.length = 0;
gdjs.gameCode.GDCoin2Objects1.length = 0;
gdjs.gameCode.GDCoin2Objects2.length = 0;
gdjs.gameCode.GDCoin2Objects3.length = 0;
gdjs.gameCode.GDCoin2Objects4.length = 0;
gdjs.gameCode.GDSmokeObjects1.length = 0;
gdjs.gameCode.GDSmokeObjects2.length = 0;
gdjs.gameCode.GDSmokeObjects3.length = 0;
gdjs.gameCode.GDSmokeObjects4.length = 0;


return;

}

gdjs['gameCode'] = gdjs.gameCode;
