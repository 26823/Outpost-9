gdjs.Game_32OverCode = {};
gdjs.Game_32OverCode.localVariables = [];
gdjs.Game_32OverCode.idToCallbackMap = new Map();
gdjs.Game_32OverCode.GDMenuObjects1= [];
gdjs.Game_32OverCode.GDMenuObjects2= [];
gdjs.Game_32OverCode.GDPlayObjects1= [];
gdjs.Game_32OverCode.GDPlayObjects2= [];
gdjs.Game_32OverCode.GDSettingsObjects1= [];
gdjs.Game_32OverCode.GDSettingsObjects2= [];
gdjs.Game_32OverCode.GDQuitObjects1= [];
gdjs.Game_32OverCode.GDQuitObjects2= [];
gdjs.Game_32OverCode.GDMenuslideObjects1= [];
gdjs.Game_32OverCode.GDMenuslideObjects2= [];
gdjs.Game_32OverCode.GDMusicObjects1= [];
gdjs.Game_32OverCode.GDMusicObjects2= [];
gdjs.Game_32OverCode.GDSoundObjects1= [];
gdjs.Game_32OverCode.GDSoundObjects2= [];
gdjs.Game_32OverCode.GDSettingsTitleObjects1= [];
gdjs.Game_32OverCode.GDSettingsTitleObjects2= [];
gdjs.Game_32OverCode.GDsoundObjects1= [];
gdjs.Game_32OverCode.GDsoundObjects2= [];
gdjs.Game_32OverCode.GDmusicObjects1= [];
gdjs.Game_32OverCode.GDmusicObjects2= [];
gdjs.Game_32OverCode.GDScore2Objects1= [];
gdjs.Game_32OverCode.GDScore2Objects2= [];
gdjs.Game_32OverCode.GDSettingsslideObjects1= [];
gdjs.Game_32OverCode.GDSettingsslideObjects2= [];
gdjs.Game_32OverCode.GDTransitionObjects1= [];
gdjs.Game_32OverCode.GDTransitionObjects2= [];


gdjs.Game_32OverCode.asyncCallback25136988 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Game_32OverCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game Scene", false);
}
gdjs.Game_32OverCode.localVariables.length = 0;
}
gdjs.Game_32OverCode.idToCallbackMap.set(25136988, gdjs.Game_32OverCode.asyncCallback25136988);
gdjs.Game_32OverCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Game_32OverCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Game_32OverCode.asyncCallback25136988(runtimeScene, asyncObjectsList)), 25136988, asyncObjectsList);
}
}

}


};gdjs.Game_32OverCode.asyncCallback25138012 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Game_32OverCode.localVariables);
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}
gdjs.Game_32OverCode.localVariables.length = 0;
}
gdjs.Game_32OverCode.idToCallbackMap.set(25138012, gdjs.Game_32OverCode.asyncCallback25138012);
gdjs.Game_32OverCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Game_32OverCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(5), (runtimeScene) => (gdjs.Game_32OverCode.asyncCallback25138012(runtimeScene, asyncObjectsList)), 25138012, asyncObjectsList);
}
}

}


};gdjs.Game_32OverCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Menuslide"), gdjs.Game_32OverCode.GDMenuslideObjects1);
gdjs.copyArray(runtimeScene.getObjects("Settingsslide"), gdjs.Game_32OverCode.GDSettingsslideObjects1);
{for(var i = 0, len = gdjs.Game_32OverCode.GDMenuslideObjects1.length ;i < len;++i) {
    gdjs.Game_32OverCode.GDMenuslideObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32OverCode.GDSettingsslideObjects1.length ;i < len;++i) {
    gdjs.Game_32OverCode.GDSettingsslideObjects1[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Settings"), gdjs.Game_32OverCode.GDSettingsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32OverCode.GDSettingsObjects1.length;i<l;++i) {
    if ( gdjs.Game_32OverCode.GDSettingsObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32OverCode.GDSettingsObjects1[k] = gdjs.Game_32OverCode.GDSettingsObjects1[i];
        ++k;
    }
}
gdjs.Game_32OverCode.GDSettingsObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Settingsslide"), gdjs.Game_32OverCode.GDSettingsslideObjects1);
{gdjs.evtTools.tween.tweenCamera2(runtimeScene, "CameraMove", (( gdjs.Game_32OverCode.GDSettingsslideObjects1.length === 0 ) ? 0 :gdjs.Game_32OverCode.GDSettingsslideObjects1[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", "easeInOutQuad", 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Score2"), gdjs.Game_32OverCode.GDScore2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32OverCode.GDScore2Objects1.length;i<l;++i) {
    if ( gdjs.Game_32OverCode.GDScore2Objects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32OverCode.GDScore2Objects1[k] = gdjs.Game_32OverCode.GDScore2Objects1[i];
        ++k;
    }
}
gdjs.Game_32OverCode.GDScore2Objects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Menuslide"), gdjs.Game_32OverCode.GDMenuslideObjects1);
{gdjs.evtTools.tween.tweenCamera2(runtimeScene, "CameraMove", (( gdjs.Game_32OverCode.GDMenuslideObjects1.length === 0 ) ? 0 :gdjs.Game_32OverCode.GDMenuslideObjects1[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", "easeInOutQuad", 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Play"), gdjs.Game_32OverCode.GDPlayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32OverCode.GDPlayObjects1.length;i<l;++i) {
    if ( gdjs.Game_32OverCode.GDPlayObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32OverCode.GDPlayObjects1[k] = gdjs.Game_32OverCode.GDPlayObjects1[i];
        ++k;
    }
}
gdjs.Game_32OverCode.GDPlayObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Transition"), gdjs.Game_32OverCode.GDTransitionObjects1);
{for(var i = 0, len = gdjs.Game_32OverCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.Game_32OverCode.GDTransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("255;255;255", 1, "Circular", "Forward", 0, null);
}
}

{ //Subevents
gdjs.Game_32OverCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Quit"), gdjs.Game_32OverCode.GDQuitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32OverCode.GDQuitObjects1.length;i<l;++i) {
    if ( gdjs.Game_32OverCode.GDQuitObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32OverCode.GDQuitObjects1[k] = gdjs.Game_32OverCode.GDQuitObjects1[i];
        ++k;
    }
}
gdjs.Game_32OverCode.GDQuitObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.saveState.createGameSaveStateInStorage(runtimeScene, "Space Game Save", "default");
}

{ //Subevents
gdjs.Game_32OverCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("sound"), gdjs.Game_32OverCode.GDsoundObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32OverCode.GDsoundObjects1.length;i<l;++i) {
    if ( gdjs.Game_32OverCode.GDsoundObjects1[i].IsBeingDragged(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32OverCode.GDsoundObjects1[k] = gdjs.Game_32OverCode.GDsoundObjects1[i];
        ++k;
    }
}
gdjs.Game_32OverCode.GDsoundObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32OverCode.GDsoundObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(7).getChild("sound").setNumber((( gdjs.Game_32OverCode.GDsoundObjects1.length === 0 ) ? 0 :gdjs.Game_32OverCode.GDsoundObjects1[0].Value(null)));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("music"), gdjs.Game_32OverCode.GDmusicObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32OverCode.GDmusicObjects1.length;i<l;++i) {
    if ( gdjs.Game_32OverCode.GDmusicObjects1[i].IsBeingDragged(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32OverCode.GDmusicObjects1[k] = gdjs.Game_32OverCode.GDmusicObjects1[i];
        ++k;
    }
}
gdjs.Game_32OverCode.GDmusicObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32OverCode.GDmusicObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(7).getChild("music").setNumber((( gdjs.Game_32OverCode.GDmusicObjects1.length === 0 ) ? 0 :gdjs.Game_32OverCode.GDmusicObjects1[0].Value(null)));
}
{gdjs.evtTools.sound.setMusicOnChannelVolume(runtimeScene, 1, runtimeScene.getGame().getVariables().getFromIndex(7).getChild("music").getAsNumber());
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Score2"), gdjs.Game_32OverCode.GDScore2Objects1);
{for(var i = 0, len = gdjs.Game_32OverCode.GDScore2Objects1.length ;i < len;++i) {
    gdjs.Game_32OverCode.GDScore2Objects1[i].getBehavior("Text").setText("Highscore " + runtimeScene.getGame().getVariables().getFromIndex(6).getAsString());
}
}
}

}


};

gdjs.Game_32OverCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Game_32OverCode.GDMenuObjects1.length = 0;
gdjs.Game_32OverCode.GDMenuObjects2.length = 0;
gdjs.Game_32OverCode.GDPlayObjects1.length = 0;
gdjs.Game_32OverCode.GDPlayObjects2.length = 0;
gdjs.Game_32OverCode.GDSettingsObjects1.length = 0;
gdjs.Game_32OverCode.GDSettingsObjects2.length = 0;
gdjs.Game_32OverCode.GDQuitObjects1.length = 0;
gdjs.Game_32OverCode.GDQuitObjects2.length = 0;
gdjs.Game_32OverCode.GDMenuslideObjects1.length = 0;
gdjs.Game_32OverCode.GDMenuslideObjects2.length = 0;
gdjs.Game_32OverCode.GDMusicObjects1.length = 0;
gdjs.Game_32OverCode.GDMusicObjects2.length = 0;
gdjs.Game_32OverCode.GDSoundObjects1.length = 0;
gdjs.Game_32OverCode.GDSoundObjects2.length = 0;
gdjs.Game_32OverCode.GDSettingsTitleObjects1.length = 0;
gdjs.Game_32OverCode.GDSettingsTitleObjects2.length = 0;
gdjs.Game_32OverCode.GDsoundObjects1.length = 0;
gdjs.Game_32OverCode.GDsoundObjects2.length = 0;
gdjs.Game_32OverCode.GDmusicObjects1.length = 0;
gdjs.Game_32OverCode.GDmusicObjects2.length = 0;
gdjs.Game_32OverCode.GDScore2Objects1.length = 0;
gdjs.Game_32OverCode.GDScore2Objects2.length = 0;
gdjs.Game_32OverCode.GDSettingsslideObjects1.length = 0;
gdjs.Game_32OverCode.GDSettingsslideObjects2.length = 0;
gdjs.Game_32OverCode.GDTransitionObjects1.length = 0;
gdjs.Game_32OverCode.GDTransitionObjects2.length = 0;

gdjs.Game_32OverCode.eventsList2(runtimeScene);
gdjs.Game_32OverCode.GDMenuObjects1.length = 0;
gdjs.Game_32OverCode.GDMenuObjects2.length = 0;
gdjs.Game_32OverCode.GDPlayObjects1.length = 0;
gdjs.Game_32OverCode.GDPlayObjects2.length = 0;
gdjs.Game_32OverCode.GDSettingsObjects1.length = 0;
gdjs.Game_32OverCode.GDSettingsObjects2.length = 0;
gdjs.Game_32OverCode.GDQuitObjects1.length = 0;
gdjs.Game_32OverCode.GDQuitObjects2.length = 0;
gdjs.Game_32OverCode.GDMenuslideObjects1.length = 0;
gdjs.Game_32OverCode.GDMenuslideObjects2.length = 0;
gdjs.Game_32OverCode.GDMusicObjects1.length = 0;
gdjs.Game_32OverCode.GDMusicObjects2.length = 0;
gdjs.Game_32OverCode.GDSoundObjects1.length = 0;
gdjs.Game_32OverCode.GDSoundObjects2.length = 0;
gdjs.Game_32OverCode.GDSettingsTitleObjects1.length = 0;
gdjs.Game_32OverCode.GDSettingsTitleObjects2.length = 0;
gdjs.Game_32OverCode.GDsoundObjects1.length = 0;
gdjs.Game_32OverCode.GDsoundObjects2.length = 0;
gdjs.Game_32OverCode.GDmusicObjects1.length = 0;
gdjs.Game_32OverCode.GDmusicObjects2.length = 0;
gdjs.Game_32OverCode.GDScore2Objects1.length = 0;
gdjs.Game_32OverCode.GDScore2Objects2.length = 0;
gdjs.Game_32OverCode.GDSettingsslideObjects1.length = 0;
gdjs.Game_32OverCode.GDSettingsslideObjects2.length = 0;
gdjs.Game_32OverCode.GDTransitionObjects1.length = 0;
gdjs.Game_32OverCode.GDTransitionObjects2.length = 0;


return;

}

gdjs['Game_32OverCode'] = gdjs.Game_32OverCode;
