gdjs.Game_32SceneCode = {};
gdjs.Game_32SceneCode.localVariables = [];
gdjs.Game_32SceneCode.idToCallbackMap = new Map();
gdjs.Game_32SceneCode.GDMenuObjects1= [];
gdjs.Game_32SceneCode.GDMenuObjects2= [];
gdjs.Game_32SceneCode.GDPlayObjects1= [];
gdjs.Game_32SceneCode.GDPlayObjects2= [];
gdjs.Game_32SceneCode.GDSettingsObjects1= [];
gdjs.Game_32SceneCode.GDSettingsObjects2= [];
gdjs.Game_32SceneCode.GDQuitObjects1= [];
gdjs.Game_32SceneCode.GDQuitObjects2= [];
gdjs.Game_32SceneCode.GDMenuslideObjects1= [];
gdjs.Game_32SceneCode.GDMenuslideObjects2= [];
gdjs.Game_32SceneCode.GDMusicObjects1= [];
gdjs.Game_32SceneCode.GDMusicObjects2= [];
gdjs.Game_32SceneCode.GDSoundObjects1= [];
gdjs.Game_32SceneCode.GDSoundObjects2= [];
gdjs.Game_32SceneCode.GDSettingsTitleObjects1= [];
gdjs.Game_32SceneCode.GDSettingsTitleObjects2= [];
gdjs.Game_32SceneCode.GDsoundObjects1= [];
gdjs.Game_32SceneCode.GDsoundObjects2= [];
gdjs.Game_32SceneCode.GDmusicObjects1= [];
gdjs.Game_32SceneCode.GDmusicObjects2= [];
gdjs.Game_32SceneCode.GDBackObjects1= [];
gdjs.Game_32SceneCode.GDBackObjects2= [];
gdjs.Game_32SceneCode.GDSettingsslideObjects1= [];
gdjs.Game_32SceneCode.GDSettingsslideObjects2= [];
gdjs.Game_32SceneCode.GDTransitionObjects1= [];
gdjs.Game_32SceneCode.GDTransitionObjects2= [];
gdjs.Game_32SceneCode.GDSaveObjects1= [];
gdjs.Game_32SceneCode.GDSaveObjects2= [];


gdjs.Game_32SceneCode.asyncCallback25085740 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Game_32SceneCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "game", false);
}
gdjs.Game_32SceneCode.localVariables.length = 0;
}
gdjs.Game_32SceneCode.idToCallbackMap.set(25085740, gdjs.Game_32SceneCode.asyncCallback25085740);
gdjs.Game_32SceneCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Game_32SceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Game_32SceneCode.asyncCallback25085740(runtimeScene, asyncObjectsList)), 25085740, asyncObjectsList);
}
}

}


};gdjs.Game_32SceneCode.asyncCallback25088036 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Game_32SceneCode.localVariables);
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}
gdjs.Game_32SceneCode.localVariables.length = 0;
}
gdjs.Game_32SceneCode.idToCallbackMap.set(25088036, gdjs.Game_32SceneCode.asyncCallback25088036);
gdjs.Game_32SceneCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Game_32SceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(5), (runtimeScene) => (gdjs.Game_32SceneCode.asyncCallback25088036(runtimeScene, asyncObjectsList)), 25088036, asyncObjectsList);
}
}

}


};gdjs.Game_32SceneCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Menuslide"), gdjs.Game_32SceneCode.GDMenuslideObjects1);
gdjs.copyArray(runtimeScene.getObjects("Settingsslide"), gdjs.Game_32SceneCode.GDSettingsslideObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMenuslideObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMenuslideObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDSettingsslideObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDSettingsslideObjects1[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Settings"), gdjs.Game_32SceneCode.GDSettingsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDSettingsObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDSettingsObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDSettingsObjects1[k] = gdjs.Game_32SceneCode.GDSettingsObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDSettingsObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Settingsslide"), gdjs.Game_32SceneCode.GDSettingsslideObjects1);
{gdjs.evtTools.tween.tweenCamera2(runtimeScene, "CameraMove", (( gdjs.Game_32SceneCode.GDSettingsslideObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDSettingsslideObjects1[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", "easeInOutQuad", 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.Game_32SceneCode.GDBackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDBackObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDBackObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDBackObjects1[k] = gdjs.Game_32SceneCode.GDBackObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDBackObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Menuslide"), gdjs.Game_32SceneCode.GDMenuslideObjects1);
{gdjs.evtTools.tween.tweenCamera2(runtimeScene, "CameraMove", (( gdjs.Game_32SceneCode.GDMenuslideObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDMenuslideObjects1[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", "easeInOutQuad", 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Play"), gdjs.Game_32SceneCode.GDPlayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDPlayObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDPlayObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDPlayObjects1[k] = gdjs.Game_32SceneCode.GDPlayObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDPlayObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Transition"), gdjs.Game_32SceneCode.GDTransitionObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("255;255;255", 1, "Circular", "Forward", 0, null);
}
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Quit"), gdjs.Game_32SceneCode.GDQuitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDQuitObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDQuitObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDQuitObjects1[k] = gdjs.Game_32SceneCode.GDQuitObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDQuitObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.saveState.createGameSaveStateInStorage(runtimeScene, "Space Game Save", "default");
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Save"), gdjs.Game_32SceneCode.GDSaveObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDSaveObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDSaveObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDSaveObjects1[k] = gdjs.Game_32SceneCode.GDSaveObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDSaveObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.saveState.createGameSaveStateInStorage(runtimeScene, "Space Game Save", "default");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("sound"), gdjs.Game_32SceneCode.GDsoundObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDsoundObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDsoundObjects1[i].IsBeingDragged(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDsoundObjects1[k] = gdjs.Game_32SceneCode.GDsoundObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDsoundObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDsoundObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(7).getChild("sound").setNumber((( gdjs.Game_32SceneCode.GDsoundObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDsoundObjects1[0].Value(null)));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("music"), gdjs.Game_32SceneCode.GDmusicObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDmusicObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDmusicObjects1[i].IsBeingDragged(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDmusicObjects1[k] = gdjs.Game_32SceneCode.GDmusicObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDmusicObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDmusicObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(7).getChild("music").setNumber((( gdjs.Game_32SceneCode.GDmusicObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDmusicObjects1[0].Value(null)));
}
{gdjs.evtTools.sound.setMusicOnChannelVolume(runtimeScene, 1, runtimeScene.getGame().getVariables().getFromIndex(7).getChild("music").getAsNumber());
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.Game_32SceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Game_32SceneCode.GDMenuObjects1.length = 0;
gdjs.Game_32SceneCode.GDMenuObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlayObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlayObjects2.length = 0;
gdjs.Game_32SceneCode.GDSettingsObjects1.length = 0;
gdjs.Game_32SceneCode.GDSettingsObjects2.length = 0;
gdjs.Game_32SceneCode.GDQuitObjects1.length = 0;
gdjs.Game_32SceneCode.GDQuitObjects2.length = 0;
gdjs.Game_32SceneCode.GDMenuslideObjects1.length = 0;
gdjs.Game_32SceneCode.GDMenuslideObjects2.length = 0;
gdjs.Game_32SceneCode.GDMusicObjects1.length = 0;
gdjs.Game_32SceneCode.GDMusicObjects2.length = 0;
gdjs.Game_32SceneCode.GDSoundObjects1.length = 0;
gdjs.Game_32SceneCode.GDSoundObjects2.length = 0;
gdjs.Game_32SceneCode.GDSettingsTitleObjects1.length = 0;
gdjs.Game_32SceneCode.GDSettingsTitleObjects2.length = 0;
gdjs.Game_32SceneCode.GDsoundObjects1.length = 0;
gdjs.Game_32SceneCode.GDsoundObjects2.length = 0;
gdjs.Game_32SceneCode.GDmusicObjects1.length = 0;
gdjs.Game_32SceneCode.GDmusicObjects2.length = 0;
gdjs.Game_32SceneCode.GDBackObjects1.length = 0;
gdjs.Game_32SceneCode.GDBackObjects2.length = 0;
gdjs.Game_32SceneCode.GDSettingsslideObjects1.length = 0;
gdjs.Game_32SceneCode.GDSettingsslideObjects2.length = 0;
gdjs.Game_32SceneCode.GDTransitionObjects1.length = 0;
gdjs.Game_32SceneCode.GDTransitionObjects2.length = 0;
gdjs.Game_32SceneCode.GDSaveObjects1.length = 0;
gdjs.Game_32SceneCode.GDSaveObjects2.length = 0;

gdjs.Game_32SceneCode.eventsList2(runtimeScene);
gdjs.Game_32SceneCode.GDMenuObjects1.length = 0;
gdjs.Game_32SceneCode.GDMenuObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlayObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlayObjects2.length = 0;
gdjs.Game_32SceneCode.GDSettingsObjects1.length = 0;
gdjs.Game_32SceneCode.GDSettingsObjects2.length = 0;
gdjs.Game_32SceneCode.GDQuitObjects1.length = 0;
gdjs.Game_32SceneCode.GDQuitObjects2.length = 0;
gdjs.Game_32SceneCode.GDMenuslideObjects1.length = 0;
gdjs.Game_32SceneCode.GDMenuslideObjects2.length = 0;
gdjs.Game_32SceneCode.GDMusicObjects1.length = 0;
gdjs.Game_32SceneCode.GDMusicObjects2.length = 0;
gdjs.Game_32SceneCode.GDSoundObjects1.length = 0;
gdjs.Game_32SceneCode.GDSoundObjects2.length = 0;
gdjs.Game_32SceneCode.GDSettingsTitleObjects1.length = 0;
gdjs.Game_32SceneCode.GDSettingsTitleObjects2.length = 0;
gdjs.Game_32SceneCode.GDsoundObjects1.length = 0;
gdjs.Game_32SceneCode.GDsoundObjects2.length = 0;
gdjs.Game_32SceneCode.GDmusicObjects1.length = 0;
gdjs.Game_32SceneCode.GDmusicObjects2.length = 0;
gdjs.Game_32SceneCode.GDBackObjects1.length = 0;
gdjs.Game_32SceneCode.GDBackObjects2.length = 0;
gdjs.Game_32SceneCode.GDSettingsslideObjects1.length = 0;
gdjs.Game_32SceneCode.GDSettingsslideObjects2.length = 0;
gdjs.Game_32SceneCode.GDTransitionObjects1.length = 0;
gdjs.Game_32SceneCode.GDTransitionObjects2.length = 0;
gdjs.Game_32SceneCode.GDSaveObjects1.length = 0;
gdjs.Game_32SceneCode.GDSaveObjects2.length = 0;


return;

}

gdjs['Game_32SceneCode'] = gdjs.Game_32SceneCode;
