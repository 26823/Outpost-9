gdjs.ShopCode = {};
gdjs.ShopCode.localVariables = [];
gdjs.ShopCode.idToCallbackMap = new Map();
gdjs.ShopCode.GDShopObjects1= [];
gdjs.ShopCode.GDShopObjects2= [];
gdjs.ShopCode.GDBackObjects1= [];
gdjs.ShopCode.GDBackObjects2= [];
gdjs.ShopCode.GDupgrade1Objects1= [];
gdjs.ShopCode.GDupgrade1Objects2= [];
gdjs.ShopCode.GDSettingsTitleObjects1= [];
gdjs.ShopCode.GDSettingsTitleObjects2= [];
gdjs.ShopCode.GDCostObjects1= [];
gdjs.ShopCode.GDCostObjects2= [];
gdjs.ShopCode.GDIconDamageObjects1= [];
gdjs.ShopCode.GDIconDamageObjects2= [];
gdjs.ShopCode.GDInfoDamageObjects1= [];
gdjs.ShopCode.GDInfoDamageObjects2= [];
gdjs.ShopCode.GDBuy1Objects1= [];
gdjs.ShopCode.GDBuy1Objects2= [];
gdjs.ShopCode.GDGeld_9595te_9595weinigObjects1= [];
gdjs.ShopCode.GDGeld_9595te_9595weinigObjects2= [];
gdjs.ShopCode.GDInfoShieldObjects1= [];
gdjs.ShopCode.GDInfoShieldObjects2= [];
gdjs.ShopCode.GDBuy2Objects1= [];
gdjs.ShopCode.GDBuy2Objects2= [];
gdjs.ShopCode.GDGeld_9595te_9595weinig2Objects1= [];
gdjs.ShopCode.GDGeld_9595te_9595weinig2Objects2= [];
gdjs.ShopCode.GDCost2Objects1= [];
gdjs.ShopCode.GDCost2Objects2= [];
gdjs.ShopCode.GDupgrade2Objects1= [];
gdjs.ShopCode.GDupgrade2Objects2= [];
gdjs.ShopCode.GDIconShieldObjects1= [];
gdjs.ShopCode.GDIconShieldObjects2= [];
gdjs.ShopCode.GDPijlObjects1= [];
gdjs.ShopCode.GDPijlObjects2= [];
gdjs.ShopCode.GDIconExplosionObjects1= [];
gdjs.ShopCode.GDIconExplosionObjects2= [];
gdjs.ShopCode.GDInfoExplosionObjects1= [];
gdjs.ShopCode.GDInfoExplosionObjects2= [];
gdjs.ShopCode.GDBuy3Objects1= [];
gdjs.ShopCode.GDBuy3Objects2= [];
gdjs.ShopCode.GDGeld_9595te_9595weinig3Objects1= [];
gdjs.ShopCode.GDGeld_9595te_9595weinig3Objects2= [];
gdjs.ShopCode.GDCosts3Objects1= [];
gdjs.ShopCode.GDCosts3Objects2= [];
gdjs.ShopCode.GDupgrade3Objects1= [];
gdjs.ShopCode.GDupgrade3Objects2= [];
gdjs.ShopCode.GDCosts4Objects1= [];
gdjs.ShopCode.GDCosts4Objects2= [];
gdjs.ShopCode.GDBuy4Objects1= [];
gdjs.ShopCode.GDBuy4Objects2= [];
gdjs.ShopCode.GDGeld_9595te_9595weinig4Objects1= [];
gdjs.ShopCode.GDGeld_9595te_9595weinig4Objects2= [];
gdjs.ShopCode.GDIconMultiShotObjects1= [];
gdjs.ShopCode.GDIconMultiShotObjects2= [];
gdjs.ShopCode.GDInfoMultiShotObjects1= [];
gdjs.ShopCode.GDInfoMultiShotObjects2= [];
gdjs.ShopCode.GDPijl2Objects1= [];
gdjs.ShopCode.GDPijl2Objects2= [];
gdjs.ShopCode.GDupgrade4Objects1= [];
gdjs.ShopCode.GDupgrade4Objects2= [];
gdjs.ShopCode.GDIconHealthObjects1= [];
gdjs.ShopCode.GDIconHealthObjects2= [];
gdjs.ShopCode.GDInfoHealthObjects1= [];
gdjs.ShopCode.GDInfoHealthObjects2= [];
gdjs.ShopCode.GDPijl3Objects1= [];
gdjs.ShopCode.GDPijl3Objects2= [];
gdjs.ShopCode.GDBuy5Objects1= [];
gdjs.ShopCode.GDBuy5Objects2= [];
gdjs.ShopCode.GDGeld_9595te_9595weinig5Objects1= [];
gdjs.ShopCode.GDGeld_9595te_9595weinig5Objects2= [];
gdjs.ShopCode.GDCosts5Objects1= [];
gdjs.ShopCode.GDCosts5Objects2= [];
gdjs.ShopCode.GDupgrade5Objects1= [];
gdjs.ShopCode.GDupgrade5Objects2= [];


gdjs.ShopCode.asyncCallback25202684 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.ShopCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Geld_te_weinig"), gdjs.ShopCode.GDGeld_9595te_9595weinigObjects2);

{for(var i = 0, len = gdjs.ShopCode.GDGeld_9595te_9595weinigObjects2.length ;i < len;++i) {
    gdjs.ShopCode.GDGeld_9595te_9595weinigObjects2[i].hide();
}
}
gdjs.ShopCode.localVariables.length = 0;
}
gdjs.ShopCode.idToCallbackMap.set(25202684, gdjs.ShopCode.asyncCallback25202684);
gdjs.ShopCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.ShopCode.localVariables);
for (const obj of gdjs.ShopCode.GDGeld_9595te_9595weinigObjects1) asyncObjectsList.addObject("Geld_te_weinig", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.ShopCode.asyncCallback25202684(runtimeScene, asyncObjectsList)), 25202684, asyncObjectsList);
}
}

}


};gdjs.ShopCode.asyncCallback25204948 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.ShopCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Geld_te_weinig2"), gdjs.ShopCode.GDGeld_9595te_9595weinig2Objects2);

{for(var i = 0, len = gdjs.ShopCode.GDGeld_9595te_9595weinig2Objects2.length ;i < len;++i) {
    gdjs.ShopCode.GDGeld_9595te_9595weinig2Objects2[i].hide();
}
}
gdjs.ShopCode.localVariables.length = 0;
}
gdjs.ShopCode.idToCallbackMap.set(25204948, gdjs.ShopCode.asyncCallback25204948);
gdjs.ShopCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.ShopCode.localVariables);
for (const obj of gdjs.ShopCode.GDGeld_9595te_9595weinig2Objects1) asyncObjectsList.addObject("Geld_te_weinig2", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.ShopCode.asyncCallback25204948(runtimeScene, asyncObjectsList)), 25204948, asyncObjectsList);
}
}

}


};gdjs.ShopCode.asyncCallback25205428 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.ShopCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Geld_te_weinig3"), gdjs.ShopCode.GDGeld_9595te_9595weinig3Objects2);

{for(var i = 0, len = gdjs.ShopCode.GDGeld_9595te_9595weinig3Objects2.length ;i < len;++i) {
    gdjs.ShopCode.GDGeld_9595te_9595weinig3Objects2[i].hide();
}
}
gdjs.ShopCode.localVariables.length = 0;
}
gdjs.ShopCode.idToCallbackMap.set(25205428, gdjs.ShopCode.asyncCallback25205428);
gdjs.ShopCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.ShopCode.localVariables);
for (const obj of gdjs.ShopCode.GDGeld_9595te_9595weinig3Objects1) asyncObjectsList.addObject("Geld_te_weinig3", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.ShopCode.asyncCallback25205428(runtimeScene, asyncObjectsList)), 25205428, asyncObjectsList);
}
}

}


};gdjs.ShopCode.asyncCallback25207692 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.ShopCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Geld_te_weinig4"), gdjs.ShopCode.GDGeld_9595te_9595weinig4Objects2);

{for(var i = 0, len = gdjs.ShopCode.GDGeld_9595te_9595weinig4Objects2.length ;i < len;++i) {
    gdjs.ShopCode.GDGeld_9595te_9595weinig4Objects2[i].hide();
}
}
gdjs.ShopCode.localVariables.length = 0;
}
gdjs.ShopCode.idToCallbackMap.set(25207692, gdjs.ShopCode.asyncCallback25207692);
gdjs.ShopCode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.ShopCode.localVariables);
for (const obj of gdjs.ShopCode.GDGeld_9595te_9595weinig4Objects1) asyncObjectsList.addObject("Geld_te_weinig4", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.ShopCode.asyncCallback25207692(runtimeScene, asyncObjectsList)), 25207692, asyncObjectsList);
}
}

}


};gdjs.ShopCode.asyncCallback25209020 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.ShopCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Geld_te_weinig5"), gdjs.ShopCode.GDGeld_9595te_9595weinig5Objects2);

{for(var i = 0, len = gdjs.ShopCode.GDGeld_9595te_9595weinig5Objects2.length ;i < len;++i) {
    gdjs.ShopCode.GDGeld_9595te_9595weinig5Objects2[i].hide();
}
}
gdjs.ShopCode.localVariables.length = 0;
}
gdjs.ShopCode.idToCallbackMap.set(25209020, gdjs.ShopCode.asyncCallback25209020);
gdjs.ShopCode.eventsList4 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.ShopCode.localVariables);
for (const obj of gdjs.ShopCode.GDGeld_9595te_9595weinig5Objects1) asyncObjectsList.addObject("Geld_te_weinig5", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.ShopCode.asyncCallback25209020(runtimeScene, asyncObjectsList)), 25209020, asyncObjectsList);
}
}

}


};gdjs.ShopCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Geld_te_weinig"), gdjs.ShopCode.GDGeld_9595te_9595weinigObjects1);
gdjs.copyArray(runtimeScene.getObjects("Geld_te_weinig2"), gdjs.ShopCode.GDGeld_9595te_9595weinig2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Geld_te_weinig3"), gdjs.ShopCode.GDGeld_9595te_9595weinig3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Geld_te_weinig4"), gdjs.ShopCode.GDGeld_9595te_9595weinig4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Geld_te_weinig5"), gdjs.ShopCode.GDGeld_9595te_9595weinig5Objects1);
gdjs.copyArray(runtimeScene.getObjects("IconDamage"), gdjs.ShopCode.GDIconDamageObjects1);
gdjs.copyArray(runtimeScene.getObjects("IconExplosion"), gdjs.ShopCode.GDIconExplosionObjects1);
gdjs.copyArray(runtimeScene.getObjects("IconHealth"), gdjs.ShopCode.GDIconHealthObjects1);
gdjs.copyArray(runtimeScene.getObjects("IconMultiShot"), gdjs.ShopCode.GDIconMultiShotObjects1);
gdjs.copyArray(runtimeScene.getObjects("IconShield"), gdjs.ShopCode.GDIconShieldObjects1);
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "Gamesong.mp3", 1, true, runtimeScene.getGame().getVariables().getFromIndex(7).getChild("music").getAsNumber(), 1);
}
{for(var i = 0, len = gdjs.ShopCode.GDIconDamageObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDIconDamageObjects1[i].returnVariable(gdjs.ShopCode.GDIconDamageObjects1[i].getVariables().getFromIndex(0)).toggle();
}
}
{for(var i = 0, len = gdjs.ShopCode.GDIconShieldObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDIconShieldObjects1[i].returnVariable(gdjs.ShopCode.GDIconShieldObjects1[i].getVariables().getFromIndex(0)).toggle();
}
}
{for(var i = 0, len = gdjs.ShopCode.GDIconExplosionObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDIconExplosionObjects1[i].returnVariable(gdjs.ShopCode.GDIconExplosionObjects1[i].getVariables().getFromIndex(0)).toggle();
}
}
{for(var i = 0, len = gdjs.ShopCode.GDIconMultiShotObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDIconMultiShotObjects1[i].returnVariable(gdjs.ShopCode.GDIconMultiShotObjects1[i].getVariables().getFromIndex(0)).toggle();
}
}
{for(var i = 0, len = gdjs.ShopCode.GDIconHealthObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDIconHealthObjects1[i].returnVariable(gdjs.ShopCode.GDIconHealthObjects1[i].getVariables().getFromIndex(0)).toggle();
}
}
{for(var i = 0, len = gdjs.ShopCode.GDGeld_9595te_9595weinigObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDGeld_9595te_9595weinigObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.ShopCode.GDGeld_9595te_9595weinig2Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDGeld_9595te_9595weinig2Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.ShopCode.GDGeld_9595te_9595weinig3Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDGeld_9595te_9595weinig3Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.ShopCode.GDGeld_9595te_9595weinig4Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDGeld_9595te_9595weinig4Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.ShopCode.GDGeld_9595te_9595weinig5Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDGeld_9595te_9595weinig5Objects1[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.ShopCode.GDBackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDBackObjects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDBackObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDBackObjects1[k] = gdjs.ShopCode.GDBackObjects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDBackObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy1"), gdjs.ShopCode.GDBuy1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDBuy1Objects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDBuy1Objects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDBuy1Objects1[k] = gdjs.ShopCode.GDBuy1Objects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDBuy1Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber() > runtimeScene.getGame().getVariables().getFromIndex(11).getAsNumber());
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(6).sub(runtimeScene.getGame().getVariables().getFromIndex(11).getAsNumber());
}
{runtimeScene.getGame().getVariables().getFromIndex(9).add(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(13).add(0.05);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect3", false, 50, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(11).add(2500);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy2"), gdjs.ShopCode.GDBuy2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDBuy2Objects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDBuy2Objects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDBuy2Objects1[k] = gdjs.ShopCode.GDBuy2Objects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDBuy2Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber() > runtimeScene.getGame().getVariables().getFromIndex(12).getAsNumber());
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(21).getAsNumber() > 0);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(6).sub(runtimeScene.getGame().getVariables().getFromIndex(12).getAsNumber());
}
{runtimeScene.getGame().getVariables().getFromIndex(5).add(0.1);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect3", false, 50, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(12).add(3000);
}
{runtimeScene.getGame().getVariables().getFromIndex(21).sub(1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy4"), gdjs.ShopCode.GDBuy4Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDBuy4Objects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDBuy4Objects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDBuy4Objects1[k] = gdjs.ShopCode.GDBuy4Objects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDBuy4Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber() > runtimeScene.getGame().getVariables().getFromIndex(15).getAsNumber());
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(22).getAsNumber() > 0);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(6).sub(runtimeScene.getGame().getVariables().getFromIndex(15).getAsNumber());
}
{runtimeScene.getGame().getVariables().getFromIndex(19).setBoolean(true);
}
{runtimeScene.getGame().getVariables().getFromIndex(4).add(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect3", false, 50, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(15).add(1000);
}
{runtimeScene.getGame().getVariables().getFromIndex(22).sub(1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy5"), gdjs.ShopCode.GDBuy5Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDBuy5Objects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDBuy5Objects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDBuy5Objects1[k] = gdjs.ShopCode.GDBuy5Objects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDBuy5Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber() > runtimeScene.getGame().getVariables().getFromIndex(16).getAsNumber());
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(23).getAsNumber() > 0);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(6).sub(runtimeScene.getGame().getVariables().getFromIndex(16).getAsNumber());
}
{runtimeScene.getGame().getVariables().getFromIndex(17).sub(0.5);
}
{runtimeScene.getGame().getVariables().getFromIndex(18).add(0.1);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect3", false, 50, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(16).add(5000);
}
{runtimeScene.getGame().getVariables().getFromIndex(23).sub(1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy3"), gdjs.ShopCode.GDBuy3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDBuy3Objects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDBuy3Objects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDBuy3Objects1[k] = gdjs.ShopCode.GDBuy3Objects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDBuy3Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber() > runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber());
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(14).getAsBoolean();
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Geld_te_weinig3"), gdjs.ShopCode.GDGeld_9595te_9595weinig3Objects1);
{runtimeScene.getGame().getVariables().getFromIndex(6).sub(runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber());
}
{runtimeScene.getGame().getVariables().getFromIndex(8).setBoolean(true);
}
{runtimeScene.getGame().getVariables().getFromIndex(13).add(0.05);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect3", false, 50, 1);
}
{for(var i = 0, len = gdjs.ShopCode.GDGeld_9595te_9595weinig3Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDGeld_9595te_9595weinig3Objects1[i].getBehavior("Text").setText("You've already bought it.");
}
}
{for(var i = 0, len = gdjs.ShopCode.GDGeld_9595te_9595weinig3Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDGeld_9595te_9595weinig3Objects1[i].hide(false);
}
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setBoolean(true);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy1"), gdjs.ShopCode.GDBuy1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDBuy1Objects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDBuy1Objects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDBuy1Objects1[k] = gdjs.ShopCode.GDBuy1Objects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDBuy1Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber() < runtimeScene.getGame().getVariables().getFromIndex(11).getAsNumber());
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Geld_te_weinig"), gdjs.ShopCode.GDGeld_9595te_9595weinigObjects1);
{for(var i = 0, len = gdjs.ShopCode.GDGeld_9595te_9595weinigObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDGeld_9595te_9595weinigObjects1[i].hide(false);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect2", false, 50, 1);
}

{ //Subevents
gdjs.ShopCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy2"), gdjs.ShopCode.GDBuy2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDBuy2Objects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDBuy2Objects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDBuy2Objects1[k] = gdjs.ShopCode.GDBuy2Objects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDBuy2Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber() < runtimeScene.getGame().getVariables().getFromIndex(12).getAsNumber());
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Geld_te_weinig2"), gdjs.ShopCode.GDGeld_9595te_9595weinig2Objects1);
{for(var i = 0, len = gdjs.ShopCode.GDGeld_9595te_9595weinig2Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDGeld_9595te_9595weinig2Objects1[i].hide(false);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect2", false, 50, 1);
}

{ //Subevents
gdjs.ShopCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy3"), gdjs.ShopCode.GDBuy3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDBuy3Objects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDBuy3Objects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDBuy3Objects1[k] = gdjs.ShopCode.GDBuy3Objects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDBuy3Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber() < runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber());
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Geld_te_weinig3"), gdjs.ShopCode.GDGeld_9595te_9595weinig3Objects1);
{for(var i = 0, len = gdjs.ShopCode.GDGeld_9595te_9595weinig3Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDGeld_9595te_9595weinig3Objects1[i].hide(false);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect2", false, 50, 1);
}

{ //Subevents
gdjs.ShopCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy4"), gdjs.ShopCode.GDBuy4Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDBuy4Objects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDBuy4Objects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDBuy4Objects1[k] = gdjs.ShopCode.GDBuy4Objects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDBuy4Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber() < runtimeScene.getGame().getVariables().getFromIndex(15).getAsNumber());
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Geld_te_weinig4"), gdjs.ShopCode.GDGeld_9595te_9595weinig4Objects1);
{for(var i = 0, len = gdjs.ShopCode.GDGeld_9595te_9595weinig4Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDGeld_9595te_9595weinig4Objects1[i].hide(false);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect2", false, 50, 1);
}

{ //Subevents
gdjs.ShopCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy5"), gdjs.ShopCode.GDBuy5Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDBuy5Objects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDBuy5Objects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDBuy5Objects1[k] = gdjs.ShopCode.GDBuy5Objects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDBuy5Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber() < runtimeScene.getGame().getVariables().getFromIndex(16).getAsNumber());
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Geld_te_weinig5"), gdjs.ShopCode.GDGeld_9595te_9595weinig5Objects1);
{for(var i = 0, len = gdjs.ShopCode.GDGeld_9595te_9595weinig5Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDGeld_9595te_9595weinig5Objects1[i].hide(false);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect2", false, 50, 1);
}

{ //Subevents
gdjs.ShopCode.eventsList4(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Cost"), gdjs.ShopCode.GDCostObjects1);
{for(var i = 0, len = gdjs.ShopCode.GDCostObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDCostObjects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(11).getAsString());
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Cost2"), gdjs.ShopCode.GDCost2Objects1);
{for(var i = 0, len = gdjs.ShopCode.GDCost2Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDCost2Objects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(12).getAsString());
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Costs3"), gdjs.ShopCode.GDCosts3Objects1);
{for(var i = 0, len = gdjs.ShopCode.GDCosts3Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDCosts3Objects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(1).getAsString());
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Costs4"), gdjs.ShopCode.GDCosts4Objects1);
{for(var i = 0, len = gdjs.ShopCode.GDCosts4Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDCosts4Objects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(15).getAsString());
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Costs5"), gdjs.ShopCode.GDCosts5Objects1);
{for(var i = 0, len = gdjs.ShopCode.GDCosts5Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDCosts5Objects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(16).getAsString());
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("IconDamage"), gdjs.ShopCode.GDIconDamageObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDIconDamageObjects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDIconDamageObjects1[i].getVariableBoolean(gdjs.ShopCode.GDIconDamageObjects1[i].getVariables().getFromIndex(0), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDIconDamageObjects1[k] = gdjs.ShopCode.GDIconDamageObjects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDIconDamageObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cost"), gdjs.ShopCode.GDCostObjects1);
/* Reuse gdjs.ShopCode.GDIconDamageObjects1 */
gdjs.copyArray(runtimeScene.getObjects("InfoDamage"), gdjs.ShopCode.GDInfoDamageObjects1);
gdjs.copyArray(runtimeScene.getObjects("upgrade1"), gdjs.ShopCode.GDupgrade1Objects1);
{for(var i = 0, len = gdjs.ShopCode.GDIconDamageObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDIconDamageObjects1[i].setZOrder(-10);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDInfoDamageObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDInfoDamageObjects1[i].setZOrder(10);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDupgrade1Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDupgrade1Objects1[i].setZOrder(10);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDCostObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDCostObjects1[i].setZOrder(-10);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("IconExplosion"), gdjs.ShopCode.GDIconExplosionObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDIconExplosionObjects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDIconExplosionObjects1[i].getVariableBoolean(gdjs.ShopCode.GDIconExplosionObjects1[i].getVariables().getFromIndex(0), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDIconExplosionObjects1[k] = gdjs.ShopCode.GDIconExplosionObjects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDIconExplosionObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Costs3"), gdjs.ShopCode.GDCosts3Objects1);
/* Reuse gdjs.ShopCode.GDIconExplosionObjects1 */
gdjs.copyArray(runtimeScene.getObjects("InfoExplosion"), gdjs.ShopCode.GDInfoExplosionObjects1);
gdjs.copyArray(runtimeScene.getObjects("upgrade3"), gdjs.ShopCode.GDupgrade3Objects1);
{for(var i = 0, len = gdjs.ShopCode.GDIconExplosionObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDIconExplosionObjects1[i].setZOrder(-10);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDInfoExplosionObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDInfoExplosionObjects1[i].setZOrder(10);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDupgrade3Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDupgrade3Objects1[i].setZOrder(10);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDCosts3Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDCosts3Objects1[i].setZOrder(-10);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("IconMultiShot"), gdjs.ShopCode.GDIconMultiShotObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDIconMultiShotObjects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDIconMultiShotObjects1[i].getVariableBoolean(gdjs.ShopCode.GDIconMultiShotObjects1[i].getVariables().getFromIndex(0), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDIconMultiShotObjects1[k] = gdjs.ShopCode.GDIconMultiShotObjects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDIconMultiShotObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Costs4"), gdjs.ShopCode.GDCosts4Objects1);
/* Reuse gdjs.ShopCode.GDIconMultiShotObjects1 */
gdjs.copyArray(runtimeScene.getObjects("InfoMultiShot"), gdjs.ShopCode.GDInfoMultiShotObjects1);
gdjs.copyArray(runtimeScene.getObjects("Pijl2"), gdjs.ShopCode.GDPijl2Objects1);
gdjs.copyArray(runtimeScene.getObjects("upgrade4"), gdjs.ShopCode.GDupgrade4Objects1);
{for(var i = 0, len = gdjs.ShopCode.GDIconMultiShotObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDIconMultiShotObjects1[i].setZOrder(-10);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDInfoMultiShotObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDInfoMultiShotObjects1[i].setZOrder(10);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDupgrade4Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDupgrade4Objects1[i].setZOrder(10);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDCosts4Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDCosts4Objects1[i].setZOrder(-10);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDPijl2Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDPijl2Objects1[i].setZOrder(-15);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("IconShield"), gdjs.ShopCode.GDIconShieldObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDIconShieldObjects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDIconShieldObjects1[i].getVariableBoolean(gdjs.ShopCode.GDIconShieldObjects1[i].getVariables().getFromIndex(0), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDIconShieldObjects1[k] = gdjs.ShopCode.GDIconShieldObjects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDIconShieldObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cost2"), gdjs.ShopCode.GDCost2Objects1);
/* Reuse gdjs.ShopCode.GDIconShieldObjects1 */
gdjs.copyArray(runtimeScene.getObjects("InfoShield"), gdjs.ShopCode.GDInfoShieldObjects1);
gdjs.copyArray(runtimeScene.getObjects("Pijl"), gdjs.ShopCode.GDPijlObjects1);
gdjs.copyArray(runtimeScene.getObjects("upgrade2"), gdjs.ShopCode.GDupgrade2Objects1);
{for(var i = 0, len = gdjs.ShopCode.GDIconShieldObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDIconShieldObjects1[i].setZOrder(-10);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDPijlObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDPijlObjects1[i].setZOrder(-15);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDInfoShieldObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDInfoShieldObjects1[i].setZOrder(10);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDupgrade2Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDupgrade2Objects1[i].setZOrder(10);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDCost2Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDCost2Objects1[i].setZOrder(-10);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("IconHealth"), gdjs.ShopCode.GDIconHealthObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDIconHealthObjects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDIconHealthObjects1[i].getVariableBoolean(gdjs.ShopCode.GDIconHealthObjects1[i].getVariables().getFromIndex(0), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDIconHealthObjects1[k] = gdjs.ShopCode.GDIconHealthObjects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDIconHealthObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Costs5"), gdjs.ShopCode.GDCosts5Objects1);
/* Reuse gdjs.ShopCode.GDIconHealthObjects1 */
gdjs.copyArray(runtimeScene.getObjects("InfoHealth"), gdjs.ShopCode.GDInfoHealthObjects1);
gdjs.copyArray(runtimeScene.getObjects("Pijl3"), gdjs.ShopCode.GDPijl3Objects1);
gdjs.copyArray(runtimeScene.getObjects("upgrade5"), gdjs.ShopCode.GDupgrade5Objects1);
{for(var i = 0, len = gdjs.ShopCode.GDIconHealthObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDIconHealthObjects1[i].setZOrder(-10);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDPijl3Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDPijl3Objects1[i].setZOrder(-15);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDInfoHealthObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDInfoHealthObjects1[i].setZOrder(10);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDupgrade5Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDupgrade5Objects1[i].setZOrder(10);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDCosts5Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDCosts5Objects1[i].setZOrder(-10);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("IconDamage"), gdjs.ShopCode.GDIconDamageObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDIconDamageObjects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDIconDamageObjects1[i].getVariableBoolean(gdjs.ShopCode.GDIconDamageObjects1[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDIconDamageObjects1[k] = gdjs.ShopCode.GDIconDamageObjects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDIconDamageObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cost"), gdjs.ShopCode.GDCostObjects1);
/* Reuse gdjs.ShopCode.GDIconDamageObjects1 */
gdjs.copyArray(runtimeScene.getObjects("InfoDamage"), gdjs.ShopCode.GDInfoDamageObjects1);
gdjs.copyArray(runtimeScene.getObjects("upgrade1"), gdjs.ShopCode.GDupgrade1Objects1);
{for(var i = 0, len = gdjs.ShopCode.GDIconDamageObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDIconDamageObjects1[i].setZOrder(20);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDInfoDamageObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDInfoDamageObjects1[i].setZOrder(-20);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDupgrade1Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDupgrade1Objects1[i].setZOrder(-20);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDCostObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDCostObjects1[i].setZOrder(40);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("IconExplosion"), gdjs.ShopCode.GDIconExplosionObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDIconExplosionObjects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDIconExplosionObjects1[i].getVariableBoolean(gdjs.ShopCode.GDIconExplosionObjects1[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDIconExplosionObjects1[k] = gdjs.ShopCode.GDIconExplosionObjects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDIconExplosionObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Costs3"), gdjs.ShopCode.GDCosts3Objects1);
/* Reuse gdjs.ShopCode.GDIconExplosionObjects1 */
gdjs.copyArray(runtimeScene.getObjects("InfoExplosion"), gdjs.ShopCode.GDInfoExplosionObjects1);
gdjs.copyArray(runtimeScene.getObjects("upgrade3"), gdjs.ShopCode.GDupgrade3Objects1);
{for(var i = 0, len = gdjs.ShopCode.GDIconExplosionObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDIconExplosionObjects1[i].setZOrder(20);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDInfoExplosionObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDInfoExplosionObjects1[i].setZOrder(-20);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDupgrade3Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDupgrade3Objects1[i].setZOrder(-20);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDCosts3Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDCosts3Objects1[i].setZOrder(40);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("IconMultiShot"), gdjs.ShopCode.GDIconMultiShotObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDIconMultiShotObjects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDIconMultiShotObjects1[i].getVariableBoolean(gdjs.ShopCode.GDIconMultiShotObjects1[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDIconMultiShotObjects1[k] = gdjs.ShopCode.GDIconMultiShotObjects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDIconMultiShotObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Costs4"), gdjs.ShopCode.GDCosts4Objects1);
/* Reuse gdjs.ShopCode.GDIconMultiShotObjects1 */
gdjs.copyArray(runtimeScene.getObjects("InfoMultiShot"), gdjs.ShopCode.GDInfoMultiShotObjects1);
gdjs.copyArray(runtimeScene.getObjects("Pijl2"), gdjs.ShopCode.GDPijl2Objects1);
gdjs.copyArray(runtimeScene.getObjects("upgrade4"), gdjs.ShopCode.GDupgrade4Objects1);
{for(var i = 0, len = gdjs.ShopCode.GDIconMultiShotObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDIconMultiShotObjects1[i].setZOrder(20);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDInfoMultiShotObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDInfoMultiShotObjects1[i].setZOrder(-20);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDupgrade4Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDupgrade4Objects1[i].setZOrder(-20);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDCosts4Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDCosts4Objects1[i].setZOrder(40);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDPijl2Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDPijl2Objects1[i].setZOrder(40);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("IconShield"), gdjs.ShopCode.GDIconShieldObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDIconShieldObjects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDIconShieldObjects1[i].getVariableBoolean(gdjs.ShopCode.GDIconShieldObjects1[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDIconShieldObjects1[k] = gdjs.ShopCode.GDIconShieldObjects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDIconShieldObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cost2"), gdjs.ShopCode.GDCost2Objects1);
/* Reuse gdjs.ShopCode.GDIconShieldObjects1 */
gdjs.copyArray(runtimeScene.getObjects("InfoShield"), gdjs.ShopCode.GDInfoShieldObjects1);
gdjs.copyArray(runtimeScene.getObjects("Pijl"), gdjs.ShopCode.GDPijlObjects1);
gdjs.copyArray(runtimeScene.getObjects("upgrade2"), gdjs.ShopCode.GDupgrade2Objects1);
{for(var i = 0, len = gdjs.ShopCode.GDIconShieldObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDIconShieldObjects1[i].setZOrder(20);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDPijlObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDPijlObjects1[i].setZOrder(30);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDInfoShieldObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDInfoShieldObjects1[i].setZOrder(-20);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDupgrade2Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDupgrade2Objects1[i].setZOrder(-20);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDCost2Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDCost2Objects1[i].setZOrder(40);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("IconHealth"), gdjs.ShopCode.GDIconHealthObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDIconHealthObjects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDIconHealthObjects1[i].getVariableBoolean(gdjs.ShopCode.GDIconHealthObjects1[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDIconHealthObjects1[k] = gdjs.ShopCode.GDIconHealthObjects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDIconHealthObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Costs5"), gdjs.ShopCode.GDCosts5Objects1);
/* Reuse gdjs.ShopCode.GDIconHealthObjects1 */
gdjs.copyArray(runtimeScene.getObjects("InfoHealth"), gdjs.ShopCode.GDInfoHealthObjects1);
gdjs.copyArray(runtimeScene.getObjects("Pijl3"), gdjs.ShopCode.GDPijl3Objects1);
gdjs.copyArray(runtimeScene.getObjects("upgrade5"), gdjs.ShopCode.GDupgrade5Objects1);
{for(var i = 0, len = gdjs.ShopCode.GDIconHealthObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDIconHealthObjects1[i].setZOrder(20);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDPijl3Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDPijl3Objects1[i].setZOrder(30);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDInfoHealthObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDInfoHealthObjects1[i].setZOrder(-20);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDupgrade5Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDupgrade5Objects1[i].setZOrder(-20);
}
}
{for(var i = 0, len = gdjs.ShopCode.GDCosts5Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDCosts5Objects1[i].setZOrder(40);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("IconDamage"), gdjs.ShopCode.GDIconDamageObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDIconDamageObjects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDIconDamageObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDIconDamageObjects1[k] = gdjs.ShopCode.GDIconDamageObjects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDIconDamageObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.ShopCode.GDIconDamageObjects1 */
{for(var i = 0, len = gdjs.ShopCode.GDIconDamageObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDIconDamageObjects1[i].returnVariable(gdjs.ShopCode.GDIconDamageObjects1[i].getVariables().getFromIndex(0)).toggle();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("IconShield"), gdjs.ShopCode.GDIconShieldObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDIconShieldObjects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDIconShieldObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDIconShieldObjects1[k] = gdjs.ShopCode.GDIconShieldObjects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDIconShieldObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.ShopCode.GDIconShieldObjects1 */
{for(var i = 0, len = gdjs.ShopCode.GDIconShieldObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDIconShieldObjects1[i].returnVariable(gdjs.ShopCode.GDIconShieldObjects1[i].getVariables().getFromIndex(0)).toggle();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("IconExplosion"), gdjs.ShopCode.GDIconExplosionObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDIconExplosionObjects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDIconExplosionObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDIconExplosionObjects1[k] = gdjs.ShopCode.GDIconExplosionObjects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDIconExplosionObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.ShopCode.GDIconExplosionObjects1 */
{for(var i = 0, len = gdjs.ShopCode.GDIconExplosionObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDIconExplosionObjects1[i].returnVariable(gdjs.ShopCode.GDIconExplosionObjects1[i].getVariables().getFromIndex(0)).toggle();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("IconMultiShot"), gdjs.ShopCode.GDIconMultiShotObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDIconMultiShotObjects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDIconMultiShotObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDIconMultiShotObjects1[k] = gdjs.ShopCode.GDIconMultiShotObjects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDIconMultiShotObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.ShopCode.GDIconMultiShotObjects1 */
{for(var i = 0, len = gdjs.ShopCode.GDIconMultiShotObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDIconMultiShotObjects1[i].returnVariable(gdjs.ShopCode.GDIconMultiShotObjects1[i].getVariables().getFromIndex(0)).toggle();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("IconHealth"), gdjs.ShopCode.GDIconHealthObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDIconHealthObjects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDIconHealthObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDIconHealthObjects1[k] = gdjs.ShopCode.GDIconHealthObjects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDIconHealthObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.ShopCode.GDIconHealthObjects1 */
{for(var i = 0, len = gdjs.ShopCode.GDIconHealthObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDIconHealthObjects1[i].returnVariable(gdjs.ShopCode.GDIconHealthObjects1[i].getVariables().getFromIndex(0)).toggle();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy3"), gdjs.ShopCode.GDBuy3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(14).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDBuy3Objects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDBuy3Objects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDBuy3Objects1[k] = gdjs.ShopCode.GDBuy3Objects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDBuy3Objects1.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Geld_te_weinig3"), gdjs.ShopCode.GDGeld_9595te_9595weinig3Objects1);
{for(var i = 0, len = gdjs.ShopCode.GDGeld_9595te_9595weinig3Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDGeld_9595te_9595weinig3Objects1[i].getBehavior("Text").setText("You've already bought it.");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(21).getAsNumber() == 0);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Geld_te_weinig2"), gdjs.ShopCode.GDGeld_9595te_9595weinig2Objects1);
{for(var i = 0, len = gdjs.ShopCode.GDGeld_9595te_9595weinig2Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDGeld_9595te_9595weinig2Objects1[i].getBehavior("Text").setText("fully upgraded");
}
}
{for(var i = 0, len = gdjs.ShopCode.GDGeld_9595te_9595weinig2Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDGeld_9595te_9595weinig2Objects1[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(22).getAsNumber() == 0);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Geld_te_weinig4"), gdjs.ShopCode.GDGeld_9595te_9595weinig4Objects1);
{for(var i = 0, len = gdjs.ShopCode.GDGeld_9595te_9595weinig4Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDGeld_9595te_9595weinig4Objects1[i].getBehavior("Text").setText("fully upgraded");
}
}
{for(var i = 0, len = gdjs.ShopCode.GDGeld_9595te_9595weinig4Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDGeld_9595te_9595weinig4Objects1[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(23).getAsNumber() == 0);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Geld_te_weinig5"), gdjs.ShopCode.GDGeld_9595te_9595weinig5Objects1);
{for(var i = 0, len = gdjs.ShopCode.GDGeld_9595te_9595weinig5Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDGeld_9595te_9595weinig5Objects1[i].getBehavior("Text").setText("fully upgraded");
}
}
{for(var i = 0, len = gdjs.ShopCode.GDGeld_9595te_9595weinig5Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDGeld_9595te_9595weinig5Objects1[i].hide(false);
}
}
}

}


};

gdjs.ShopCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.ShopCode.GDShopObjects1.length = 0;
gdjs.ShopCode.GDShopObjects2.length = 0;
gdjs.ShopCode.GDBackObjects1.length = 0;
gdjs.ShopCode.GDBackObjects2.length = 0;
gdjs.ShopCode.GDupgrade1Objects1.length = 0;
gdjs.ShopCode.GDupgrade1Objects2.length = 0;
gdjs.ShopCode.GDSettingsTitleObjects1.length = 0;
gdjs.ShopCode.GDSettingsTitleObjects2.length = 0;
gdjs.ShopCode.GDCostObjects1.length = 0;
gdjs.ShopCode.GDCostObjects2.length = 0;
gdjs.ShopCode.GDIconDamageObjects1.length = 0;
gdjs.ShopCode.GDIconDamageObjects2.length = 0;
gdjs.ShopCode.GDInfoDamageObjects1.length = 0;
gdjs.ShopCode.GDInfoDamageObjects2.length = 0;
gdjs.ShopCode.GDBuy1Objects1.length = 0;
gdjs.ShopCode.GDBuy1Objects2.length = 0;
gdjs.ShopCode.GDGeld_9595te_9595weinigObjects1.length = 0;
gdjs.ShopCode.GDGeld_9595te_9595weinigObjects2.length = 0;
gdjs.ShopCode.GDInfoShieldObjects1.length = 0;
gdjs.ShopCode.GDInfoShieldObjects2.length = 0;
gdjs.ShopCode.GDBuy2Objects1.length = 0;
gdjs.ShopCode.GDBuy2Objects2.length = 0;
gdjs.ShopCode.GDGeld_9595te_9595weinig2Objects1.length = 0;
gdjs.ShopCode.GDGeld_9595te_9595weinig2Objects2.length = 0;
gdjs.ShopCode.GDCost2Objects1.length = 0;
gdjs.ShopCode.GDCost2Objects2.length = 0;
gdjs.ShopCode.GDupgrade2Objects1.length = 0;
gdjs.ShopCode.GDupgrade2Objects2.length = 0;
gdjs.ShopCode.GDIconShieldObjects1.length = 0;
gdjs.ShopCode.GDIconShieldObjects2.length = 0;
gdjs.ShopCode.GDPijlObjects1.length = 0;
gdjs.ShopCode.GDPijlObjects2.length = 0;
gdjs.ShopCode.GDIconExplosionObjects1.length = 0;
gdjs.ShopCode.GDIconExplosionObjects2.length = 0;
gdjs.ShopCode.GDInfoExplosionObjects1.length = 0;
gdjs.ShopCode.GDInfoExplosionObjects2.length = 0;
gdjs.ShopCode.GDBuy3Objects1.length = 0;
gdjs.ShopCode.GDBuy3Objects2.length = 0;
gdjs.ShopCode.GDGeld_9595te_9595weinig3Objects1.length = 0;
gdjs.ShopCode.GDGeld_9595te_9595weinig3Objects2.length = 0;
gdjs.ShopCode.GDCosts3Objects1.length = 0;
gdjs.ShopCode.GDCosts3Objects2.length = 0;
gdjs.ShopCode.GDupgrade3Objects1.length = 0;
gdjs.ShopCode.GDupgrade3Objects2.length = 0;
gdjs.ShopCode.GDCosts4Objects1.length = 0;
gdjs.ShopCode.GDCosts4Objects2.length = 0;
gdjs.ShopCode.GDBuy4Objects1.length = 0;
gdjs.ShopCode.GDBuy4Objects2.length = 0;
gdjs.ShopCode.GDGeld_9595te_9595weinig4Objects1.length = 0;
gdjs.ShopCode.GDGeld_9595te_9595weinig4Objects2.length = 0;
gdjs.ShopCode.GDIconMultiShotObjects1.length = 0;
gdjs.ShopCode.GDIconMultiShotObjects2.length = 0;
gdjs.ShopCode.GDInfoMultiShotObjects1.length = 0;
gdjs.ShopCode.GDInfoMultiShotObjects2.length = 0;
gdjs.ShopCode.GDPijl2Objects1.length = 0;
gdjs.ShopCode.GDPijl2Objects2.length = 0;
gdjs.ShopCode.GDupgrade4Objects1.length = 0;
gdjs.ShopCode.GDupgrade4Objects2.length = 0;
gdjs.ShopCode.GDIconHealthObjects1.length = 0;
gdjs.ShopCode.GDIconHealthObjects2.length = 0;
gdjs.ShopCode.GDInfoHealthObjects1.length = 0;
gdjs.ShopCode.GDInfoHealthObjects2.length = 0;
gdjs.ShopCode.GDPijl3Objects1.length = 0;
gdjs.ShopCode.GDPijl3Objects2.length = 0;
gdjs.ShopCode.GDBuy5Objects1.length = 0;
gdjs.ShopCode.GDBuy5Objects2.length = 0;
gdjs.ShopCode.GDGeld_9595te_9595weinig5Objects1.length = 0;
gdjs.ShopCode.GDGeld_9595te_9595weinig5Objects2.length = 0;
gdjs.ShopCode.GDCosts5Objects1.length = 0;
gdjs.ShopCode.GDCosts5Objects2.length = 0;
gdjs.ShopCode.GDupgrade5Objects1.length = 0;
gdjs.ShopCode.GDupgrade5Objects2.length = 0;

gdjs.ShopCode.eventsList5(runtimeScene);
gdjs.ShopCode.GDShopObjects1.length = 0;
gdjs.ShopCode.GDShopObjects2.length = 0;
gdjs.ShopCode.GDBackObjects1.length = 0;
gdjs.ShopCode.GDBackObjects2.length = 0;
gdjs.ShopCode.GDupgrade1Objects1.length = 0;
gdjs.ShopCode.GDupgrade1Objects2.length = 0;
gdjs.ShopCode.GDSettingsTitleObjects1.length = 0;
gdjs.ShopCode.GDSettingsTitleObjects2.length = 0;
gdjs.ShopCode.GDCostObjects1.length = 0;
gdjs.ShopCode.GDCostObjects2.length = 0;
gdjs.ShopCode.GDIconDamageObjects1.length = 0;
gdjs.ShopCode.GDIconDamageObjects2.length = 0;
gdjs.ShopCode.GDInfoDamageObjects1.length = 0;
gdjs.ShopCode.GDInfoDamageObjects2.length = 0;
gdjs.ShopCode.GDBuy1Objects1.length = 0;
gdjs.ShopCode.GDBuy1Objects2.length = 0;
gdjs.ShopCode.GDGeld_9595te_9595weinigObjects1.length = 0;
gdjs.ShopCode.GDGeld_9595te_9595weinigObjects2.length = 0;
gdjs.ShopCode.GDInfoShieldObjects1.length = 0;
gdjs.ShopCode.GDInfoShieldObjects2.length = 0;
gdjs.ShopCode.GDBuy2Objects1.length = 0;
gdjs.ShopCode.GDBuy2Objects2.length = 0;
gdjs.ShopCode.GDGeld_9595te_9595weinig2Objects1.length = 0;
gdjs.ShopCode.GDGeld_9595te_9595weinig2Objects2.length = 0;
gdjs.ShopCode.GDCost2Objects1.length = 0;
gdjs.ShopCode.GDCost2Objects2.length = 0;
gdjs.ShopCode.GDupgrade2Objects1.length = 0;
gdjs.ShopCode.GDupgrade2Objects2.length = 0;
gdjs.ShopCode.GDIconShieldObjects1.length = 0;
gdjs.ShopCode.GDIconShieldObjects2.length = 0;
gdjs.ShopCode.GDPijlObjects1.length = 0;
gdjs.ShopCode.GDPijlObjects2.length = 0;
gdjs.ShopCode.GDIconExplosionObjects1.length = 0;
gdjs.ShopCode.GDIconExplosionObjects2.length = 0;
gdjs.ShopCode.GDInfoExplosionObjects1.length = 0;
gdjs.ShopCode.GDInfoExplosionObjects2.length = 0;
gdjs.ShopCode.GDBuy3Objects1.length = 0;
gdjs.ShopCode.GDBuy3Objects2.length = 0;
gdjs.ShopCode.GDGeld_9595te_9595weinig3Objects1.length = 0;
gdjs.ShopCode.GDGeld_9595te_9595weinig3Objects2.length = 0;
gdjs.ShopCode.GDCosts3Objects1.length = 0;
gdjs.ShopCode.GDCosts3Objects2.length = 0;
gdjs.ShopCode.GDupgrade3Objects1.length = 0;
gdjs.ShopCode.GDupgrade3Objects2.length = 0;
gdjs.ShopCode.GDCosts4Objects1.length = 0;
gdjs.ShopCode.GDCosts4Objects2.length = 0;
gdjs.ShopCode.GDBuy4Objects1.length = 0;
gdjs.ShopCode.GDBuy4Objects2.length = 0;
gdjs.ShopCode.GDGeld_9595te_9595weinig4Objects1.length = 0;
gdjs.ShopCode.GDGeld_9595te_9595weinig4Objects2.length = 0;
gdjs.ShopCode.GDIconMultiShotObjects1.length = 0;
gdjs.ShopCode.GDIconMultiShotObjects2.length = 0;
gdjs.ShopCode.GDInfoMultiShotObjects1.length = 0;
gdjs.ShopCode.GDInfoMultiShotObjects2.length = 0;
gdjs.ShopCode.GDPijl2Objects1.length = 0;
gdjs.ShopCode.GDPijl2Objects2.length = 0;
gdjs.ShopCode.GDupgrade4Objects1.length = 0;
gdjs.ShopCode.GDupgrade4Objects2.length = 0;
gdjs.ShopCode.GDIconHealthObjects1.length = 0;
gdjs.ShopCode.GDIconHealthObjects2.length = 0;
gdjs.ShopCode.GDInfoHealthObjects1.length = 0;
gdjs.ShopCode.GDInfoHealthObjects2.length = 0;
gdjs.ShopCode.GDPijl3Objects1.length = 0;
gdjs.ShopCode.GDPijl3Objects2.length = 0;
gdjs.ShopCode.GDBuy5Objects1.length = 0;
gdjs.ShopCode.GDBuy5Objects2.length = 0;
gdjs.ShopCode.GDGeld_9595te_9595weinig5Objects1.length = 0;
gdjs.ShopCode.GDGeld_9595te_9595weinig5Objects2.length = 0;
gdjs.ShopCode.GDCosts5Objects1.length = 0;
gdjs.ShopCode.GDCosts5Objects2.length = 0;
gdjs.ShopCode.GDupgrade5Objects1.length = 0;
gdjs.ShopCode.GDupgrade5Objects2.length = 0;


return;

}

gdjs['ShopCode'] = gdjs.ShopCode;
